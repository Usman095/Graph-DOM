var networks = {"HR-1_unique_cyto_input.csv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.2",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "HR-1_unique_cyto_input.csv",
    "name" : "HR-1_unique_cyto_input.csv",
    "SUID" : 36801,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "38229",
        "shared_name" : "C18H11O9",
        "name" : "C18H11O9",
        "SUID" : 38229,
        "selected" : false
      },
      "position" : {
        "x" : -301.8449786591593,
        "y" : 2617.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38222",
        "shared_name" : "C16H7O8",
        "name" : "C16H7O8",
        "SUID" : 38222,
        "selected" : false
      },
      "position" : {
        "x" : -566.9991534638468,
        "y" : 2617.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38215",
        "shared_name" : "C23H27O8",
        "name" : "C23H27O8",
        "SUID" : 38215,
        "selected" : false
      },
      "position" : {
        "x" : 607.1657787871297,
        "y" : 2617.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38214",
        "shared_name" : "C23H29O9",
        "name" : "C23H29O9",
        "SUID" : 38214,
        "selected" : false
      },
      "position" : {
        "x" : 604.1483265471395,
        "y" : 2725.5414844081
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38201",
        "shared_name" : "C17H25O7",
        "name" : "C17H25O7",
        "SUID" : 38201,
        "selected" : false
      },
      "position" : {
        "x" : 1104.4966808867391,
        "y" : -2227.2858471348686
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38165",
        "shared_name" : "C18H21O6",
        "name" : "C18H21O6",
        "SUID" : 38165,
        "selected" : false
      },
      "position" : {
        "x" : 100.89633908986411,
        "y" : 1250.1329570338326
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38159",
        "shared_name" : "C15H15O10",
        "name" : "C15H15O10",
        "SUID" : 38159,
        "selected" : false
      },
      "position" : {
        "x" : 843.2354008269247,
        "y" : 488.9646659419136
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38146",
        "shared_name" : "C16H15O11",
        "name" : "C16H15O11",
        "SUID" : 38146,
        "selected" : false
      },
      "position" : {
        "x" : -630.4153674531046,
        "y" : -874.1200069859428
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38144",
        "shared_name" : "C14H15O8",
        "name" : "C14H15O8",
        "SUID" : 38144,
        "selected" : false
      },
      "position" : {
        "x" : 761.0788933348592,
        "y" : 412.58627849074173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38140",
        "shared_name" : "C16H13O13",
        "name" : "C16H13O13",
        "SUID" : 38140,
        "selected" : false
      },
      "position" : {
        "x" : -1105.7412951874796,
        "y" : 555.276618532856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38138",
        "shared_name" : "C10H7O7",
        "name" : "C10H7O7",
        "SUID" : 38138,
        "selected" : false
      },
      "position" : {
        "x" : 401.13087430714927,
        "y" : 2617.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38137",
        "shared_name" : "C11H7O9",
        "name" : "C11H7O9",
        "SUID" : 38137,
        "selected" : false
      },
      "position" : {
        "x" : 398.11342206715904,
        "y" : 2725.5414844081
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38127",
        "shared_name" : "C13H7O7",
        "name" : "C13H7O7",
        "SUID" : 38127,
        "selected" : false
      },
      "position" : {
        "x" : 298.11342206715904,
        "y" : 2617.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38126",
        "shared_name" : "C13H9O8",
        "name" : "C13H9O8",
        "SUID" : 38126,
        "selected" : false
      },
      "position" : {
        "x" : 295.0959698271688,
        "y" : 2725.5414844081
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38121",
        "shared_name" : "C14H9O11",
        "name" : "C14H9O11",
        "SUID" : 38121,
        "selected" : false
      },
      "position" : {
        "x" : -625.3623889374796,
        "y" : 1115.8231273219185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38108",
        "shared_name" : "C11H9O8",
        "name" : "C11H9O8",
        "SUID" : 38108,
        "selected" : false
      },
      "position" : {
        "x" : 50.938697488301614,
        "y" : 2187.181876711567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38102",
        "shared_name" : "C11H11O8",
        "name" : "C11H11O8",
        "SUID" : 38102,
        "selected" : false
      },
      "position" : {
        "x" : -284.4237636017863,
        "y" : 1775.2552867457466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38077",
        "shared_name" : "C17H15O7",
        "name" : "C17H15O7",
        "SUID" : 38077,
        "selected" : false
      },
      "position" : {
        "x" : -335.9406970429484,
        "y" : 2517.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38060",
        "shared_name" : "C12H17O6",
        "name" : "C12H17O6",
        "SUID" : 38060,
        "selected" : false
      },
      "position" : {
        "x" : -1078.6668933320109,
        "y" : -2658.242638058941
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38057",
        "shared_name" : "C15H19O5",
        "name" : "C15H19O5",
        "SUID" : 38057,
        "selected" : false
      },
      "position" : {
        "x" : -38.51537355662026,
        "y" : -217.4483570530815
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38052",
        "shared_name" : "C15H21O4",
        "name" : "C15H21O4",
        "SUID" : 38052,
        "selected" : false
      },
      "position" : {
        "x" : 1118.9252392363485,
        "y" : -2658.242638058941
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38024",
        "shared_name" : "C18H9O9",
        "name" : "C18H9O9",
        "SUID" : 38024,
        "selected" : false
      },
      "position" : {
        "x" : 631.0012871336874,
        "y" : 2283.940635256489
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38014",
        "shared_name" : "C11H15O6",
        "name" : "C11H15O6",
        "SUID" : 38014,
        "selected" : false
      },
      "position" : {
        "x" : 814.2530285429891,
        "y" : 1236.1908946559029
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38012",
        "shared_name" : "C19H19O7",
        "name" : "C19H19O7",
        "SUID" : 38012,
        "selected" : false
      },
      "position" : {
        "x" : -361.80004152537026,
        "y" : 1153.0977855250435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38010",
        "shared_name" : "C19H9O12",
        "name" : "C19H9O12",
        "SUID" : 38010,
        "selected" : false
      },
      "position" : {
        "x" : -1105.7412951874796,
        "y" : 2617.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37983",
        "shared_name" : "C18H15O14",
        "name" : "C18H15O14",
        "SUID" : 37983,
        "selected" : false
      },
      "position" : {
        "x" : -525.439125387675,
        "y" : -2098.6892780735893
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37969",
        "shared_name" : "C16H11O12",
        "name" : "C16H11O12",
        "SUID" : 37969,
        "selected" : false
      },
      "position" : {
        "x" : -1096.2134707856242,
        "y" : 748.5448451563911
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37951",
        "shared_name" : "C14H17O9",
        "name" : "C14H17O9",
        "SUID" : 37951,
        "selected" : false
      },
      "position" : {
        "x" : -995.8313525605265,
        "y" : 2412.8055797144966
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37950",
        "shared_name" : "C15H17O11",
        "name" : "C15H17O11",
        "SUID" : 37950,
        "selected" : false
      },
      "position" : {
        "x" : -1105.7412951874796,
        "y" : 2396.7909274622994
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37937",
        "shared_name" : "C15H13O6",
        "name" : "C15H13O6",
        "SUID" : 37937,
        "selected" : false
      },
      "position" : {
        "x" : 34.835731179707864,
        "y" : -1609.3924488499565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37916",
        "shared_name" : "C13H17O6",
        "name" : "C13H17O6",
        "SUID" : 37916,
        "selected" : false
      },
      "position" : {
        "x" : -1055.3156360077921,
        "y" : -567.9383167698784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37911",
        "shared_name" : "C15H21O8",
        "name" : "C15H21O8",
        "SUID" : 37911,
        "selected" : false
      },
      "position" : {
        "x" : -159.31104311228432,
        "y" : -2026.7389301731987
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37895",
        "shared_name" : "C19H9O11",
        "name" : "C19H9O11",
        "SUID" : 37895,
        "selected" : false
      },
      "position" : {
        "x" : 538.6606804442342,
        "y" : 2228.1561809107857
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37894",
        "shared_name" : "C20H9O13",
        "name" : "C20H9O13",
        "SUID" : 37894,
        "selected" : false
      },
      "position" : {
        "x" : 442.26556936024986,
        "y" : 2187.181876711567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37888",
        "shared_name" : "C11H17O6",
        "name" : "C11H17O6",
        "SUID" : 37888,
        "selected" : false
      },
      "position" : {
        "x" : -635.288750021464,
        "y" : 107.8513026759224
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37874",
        "shared_name" : "C14H13O7",
        "name" : "C14H13O7",
        "SUID" : 37874,
        "selected" : false
      },
      "position" : {
        "x" : 697.0731503081258,
        "y" : 315.82202678175736
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37865",
        "shared_name" : "C11H7O7",
        "name" : "C11H7O7",
        "SUID" : 37865,
        "selected" : false
      },
      "position" : {
        "x" : -50.952476828104636,
        "y" : 2227.1344066187935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37862",
        "shared_name" : "C17H13O13",
        "name" : "C17H13O13",
        "SUID" : 37862,
        "selected" : false
      },
      "position" : {
        "x" : 486.589912087911,
        "y" : -52.69170422105026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37860",
        "shared_name" : "C17H7O10",
        "name" : "C17H7O10",
        "SUID" : 37860,
        "selected" : false
      },
      "position" : {
        "x" : -483.310478537089,
        "y" : 2686.9854236170845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37859",
        "shared_name" : "C17H9O11",
        "name" : "C17H9O11",
        "SUID" : 37859,
        "selected" : false
      },
      "position" : {
        "x" : -401.8449786591593,
        "y" : 2757.6409106776314
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37851",
        "shared_name" : "C20H27O10",
        "name" : "C20H27O10",
        "SUID" : 37851,
        "selected" : false
      },
      "position" : {
        "x" : 195.0959698271688,
        "y" : 2713.6377254054146
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37843",
        "shared_name" : "C17H9O8",
        "name" : "C17H9O8",
        "SUID" : 37843,
        "selected" : false
      },
      "position" : {
        "x" : -960.6751483368937,
        "y" : 2778.2677112147408
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37842",
        "shared_name" : "C18H9O10",
        "name" : "C18H9O10",
        "SUID" : 37842,
        "selected" : false
      },
      "position" : {
        "x" : -1035.7616046357218,
        "y" : 2700.8526416346626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37835",
        "shared_name" : "C16H7O10",
        "name" : "C16H7O10",
        "SUID" : 37835,
        "selected" : false
      },
      "position" : {
        "x" : -874.7576526093546,
        "y" : 1015.8231273219185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37832",
        "shared_name" : "C19H25O7",
        "name" : "C19H25O7",
        "SUID" : 37832,
        "selected" : false
      },
      "position" : {
        "x" : 1.4199749541219262,
        "y" : 2617.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37831",
        "shared_name" : "C20H25O9",
        "name" : "C20H25O9",
        "SUID" : 37831,
        "selected" : false
      },
      "position" : {
        "x" : 100.6186749052938,
        "y" : 2660.0077395960884
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37827",
        "shared_name" : "C17H9O9",
        "name" : "C17H9O9",
        "SUID" : 37827,
        "selected" : false
      },
      "position" : {
        "x" : -554.7563250947062,
        "y" : -1598.6153187230034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37822",
        "shared_name" : "C21H17O11",
        "name" : "C21H17O11",
        "SUID" : 37822,
        "selected" : false
      },
      "position" : {
        "x" : -549.7198642182414,
        "y" : 2187.181876711567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37805",
        "shared_name" : "C12H19O6",
        "name" : "C12H19O6",
        "SUID" : 37805,
        "selected" : false
      },
      "position" : {
        "x" : -808.7079928803507,
        "y" : 2187.181876711567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37803",
        "shared_name" : "C13H9O7",
        "name" : "C13H9O7",
        "SUID" : 37803,
        "selected" : false
      },
      "position" : {
        "x" : 342.61624875783286,
        "y" : 1115.8231273219185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37791",
        "shared_name" : "C13H17O9",
        "name" : "C13H17O9",
        "SUID" : 37791,
        "selected" : false
      },
      "position" : {
        "x" : -883.2410205292765,
        "y" : 143.05207019301224
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37784",
        "shared_name" : "C13H9O6",
        "name" : "C13H9O6",
        "SUID" : 37784,
        "selected" : false
      },
      "position" : {
        "x" : 212.591865212911,
        "y" : -48.67882580308151
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37771",
        "shared_name" : "C16H21O7",
        "name" : "C16H21O7",
        "SUID" : 37771,
        "selected" : false
      },
      "position" : {
        "x" : 1285.2287365508016,
        "y" : -745.8179401829643
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37769",
        "shared_name" : "C11H17O5",
        "name" : "C11H17O5",
        "SUID" : 37769,
        "selected" : false
      },
      "position" : {
        "x" : -827.9957507538859,
        "y" : -52.69170422105026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37766",
        "shared_name" : "C19H11O11",
        "name" : "C19H11O11",
        "SUID" : 37766,
        "selected" : false
      },
      "position" : {
        "x" : -199.71906313181557,
        "y" : 2657.116923861225
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37765",
        "shared_name" : "C19H13O12",
        "name" : "C19H13O12",
        "SUID" : 37765,
        "selected" : false
      },
      "position" : {
        "x" : -98.58002504587807,
        "y" : 2685.6163135096626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37758",
        "shared_name" : "C17H19O12",
        "name" : "C17H19O12",
        "SUID" : 37758,
        "selected" : false
      },
      "position" : {
        "x" : -50.30626711130776,
        "y" : -913.3512405827446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37756",
        "shared_name" : "C15H19O10",
        "name" : "C15H19O10",
        "SUID" : 37756,
        "selected" : false
      },
      "position" : {
        "x" : -767.8434680390421,
        "y" : -1763.0382313206596
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37751",
        "shared_name" : "C13H9O10",
        "name" : "C13H9O10",
        "SUID" : 37751,
        "selected" : false
      },
      "position" : {
        "x" : 1054.4982067656454,
        "y" : 1675.2552867457466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37747",
        "shared_name" : "C11H15O7",
        "name" : "C11H15O7",
        "SUID" : 37747,
        "selected" : false
      },
      "position" : {
        "x" : 817.196170480245,
        "y" : 1880.9619441554146
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37739",
        "shared_name" : "C20H11O10",
        "name" : "C20H11O10",
        "SUID" : 37739,
        "selected" : false
      },
      "position" : {
        "x" : 710.18323102712,
        "y" : 2617.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37738",
        "shared_name" : "C20H13O11",
        "name" : "C20H13O11",
        "SUID" : 37738,
        "selected" : false
      },
      "position" : {
        "x" : 707.1657787871297,
        "y" : 2725.5414844081
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37734",
        "shared_name" : "C12H15O5",
        "name" : "C12H15O5",
        "SUID" : 37734,
        "selected" : false
      },
      "position" : {
        "x" : -1105.7412951874796,
        "y" : -2436.6312488987846
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37722",
        "shared_name" : "C19H17O12",
        "name" : "C19H17O12",
        "SUID" : 37722,
        "selected" : false
      },
      "position" : {
        "x" : 403.5346447539266,
        "y" : -814.064804501812
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37709",
        "shared_name" : "C17H21O6",
        "name" : "C17H21O6",
        "SUID" : 37709,
        "selected" : false
      },
      "position" : {
        "x" : 821.6012341093954,
        "y" : -1141.842506833355
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37702",
        "shared_name" : "C11H9O7",
        "name" : "C11H9O7",
        "SUID" : 37702,
        "selected" : false
      },
      "position" : {
        "x" : -363.2248614716593,
        "y" : 1852.8355174586372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37695",
        "shared_name" : "C13H15O6",
        "name" : "C13H15O6",
        "SUID" : 37695,
        "selected" : false
      },
      "position" : {
        "x" : -821.2115405488078,
        "y" : 2485.848067812641
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37691",
        "shared_name" : "C12H5O7",
        "name" : "C12H5O7",
        "SUID" : 37691,
        "selected" : false
      },
      "position" : {
        "x" : -589.1042102265421,
        "y" : 2044.6939311549263
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37681",
        "shared_name" : "C12H7O9",
        "name" : "C12H7O9",
        "SUID" : 37681,
        "selected" : false
      },
      "position" : {
        "x" : -147.17484316111245,
        "y" : 2281.395202212055
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37680",
        "shared_name" : "C13H7O11",
        "name" : "C13H7O11",
        "SUID" : 37680,
        "selected" : false
      },
      "position" : {
        "x" : -235.9406970429484,
        "y" : 2347.1353374049263
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37678",
        "shared_name" : "C15H21O7",
        "name" : "C15H21O7",
        "SUID" : 37678,
        "selected" : false
      },
      "position" : {
        "x" : 424.1457287383016,
        "y" : -1271.3685841038628
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37677",
        "shared_name" : "C16H21O9",
        "name" : "C16H21O9",
        "SUID" : 37677,
        "selected" : false
      },
      "position" : {
        "x" : 378.57389035939536,
        "y" : -1384.374504514019
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37663",
        "shared_name" : "C14H15O9",
        "name" : "C14H15O9",
        "SUID" : 37663,
        "selected" : false
      },
      "position" : {
        "x" : -893.9931567597453,
        "y" : -2369.351082272808
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37659",
        "shared_name" : "C12H17O8",
        "name" : "C12H17O8",
        "SUID" : 37659,
        "selected" : false
      },
      "position" : {
        "x" : -528.7896045136515,
        "y" : 148.83575015517044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37657",
        "shared_name" : "C18H15O13",
        "name" : "C18H15O13",
        "SUID" : 37657,
        "selected" : false
      },
      "position" : {
        "x" : 262.7936894011434,
        "y" : 1775.2552867457466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37655",
        "shared_name" : "C18H21O9",
        "name" : "C18H21O9",
        "SUID" : 37655,
        "selected" : false
      },
      "position" : {
        "x" : -975.5628875184123,
        "y" : 1865.4674754664497
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37651",
        "shared_name" : "C17H21O10",
        "name" : "C17H21O10",
        "SUID" : 37651,
        "selected" : false
      },
      "position" : {
        "x" : 11.240440042012551,
        "y" : -513.9481739476128
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37639",
        "shared_name" : "C12H15O7",
        "name" : "C12H15O7",
        "SUID" : 37639,
        "selected" : false
      },
      "position" : {
        "x" : -416.78685793162026,
        "y" : 156.72054439039994
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37635",
        "shared_name" : "C12H7O6",
        "name" : "C12H7O6",
        "SUID" : 37635,
        "selected" : false
      },
      "position" : {
        "x" : -668.7342074799601,
        "y" : 1284.1563640162544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37623",
        "shared_name" : "C17H17O12",
        "name" : "C17H17O12",
        "SUID" : 37623,
        "selected" : false
      },
      "position" : {
        "x" : 323.4118534636434,
        "y" : 1955.4232402369576
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37614",
        "shared_name" : "C17H13O10",
        "name" : "C17H13O10",
        "SUID" : 37614,
        "selected" : false
      },
      "position" : {
        "x" : 455.0570866179403,
        "y" : 1827.7462993189888
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37613",
        "shared_name" : "C17H15O11",
        "name" : "C17H15O11",
        "SUID" : 37613,
        "selected" : false
      },
      "position" : {
        "x" : 349.12553754567466,
        "y" : 1847.0184703394966
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37595",
        "shared_name" : "C12H9O9",
        "name" : "C12H9O9",
        "SUID" : 37595,
        "selected" : false
      },
      "position" : {
        "x" : -464.39461549997964,
        "y" : 1904.0524516627388
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37593",
        "shared_name" : "C17H21O11",
        "name" : "C17H21O11",
        "SUID" : 37593,
        "selected" : false
      },
      "position" : {
        "x" : 313.62854734181724,
        "y" : -1471.6500782444878
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37586",
        "shared_name" : "C15H15O11",
        "name" : "C15H15O11",
        "SUID" : 37586,
        "selected" : false
      },
      "position" : {
        "x" : -791.7591784882609,
        "y" : -2403.1104206517143
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37585",
        "shared_name" : "C15H17O12",
        "name" : "C15H17O12",
        "SUID" : 37585,
        "selected" : false
      },
      "position" : {
        "x" : -752.2959216523234,
        "y" : -2503.1970753148003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37582",
        "shared_name" : "C14H19O5",
        "name" : "C14H19O5",
        "SUID" : 37582,
        "selected" : false
      },
      "position" : {
        "x" : -103.75814089060464,
        "y" : -1956.8418201878471
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37576",
        "shared_name" : "C12H13O5",
        "name" : "C12H13O5",
        "SUID" : 37576,
        "selected" : false
      },
      "position" : {
        "x" : -1040.841153829104,
        "y" : 281.8238597437935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37572",
        "shared_name" : "C11H13O7",
        "name" : "C11H13O7",
        "SUID" : 37572,
        "selected" : false
      },
      "position" : {
        "x" : -1013.4404529023234,
        "y" : 1531.7950358912544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37571",
        "shared_name" : "C11H15O8",
        "name" : "C11H15O8",
        "SUID" : 37571,
        "selected" : false
      },
      "position" : {
        "x" : -1105.7412951874796,
        "y" : 1594.8250499293404
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37566",
        "shared_name" : "C15H13O9",
        "name" : "C15H13O9",
        "SUID" : 37566,
        "selected" : false
      },
      "position" : {
        "x" : 626.4272381377157,
        "y" : -36.82922691849899
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37562",
        "shared_name" : "C11H11O7",
        "name" : "C11H11O7",
        "SUID" : 37562,
        "selected" : false
      },
      "position" : {
        "x" : 973.799384744161,
        "y" : 1333.499259524067
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37556",
        "shared_name" : "C16H9O9",
        "name" : "C16H9O9",
        "SUID" : 37556,
        "selected" : false
      },
      "position" : {
        "x" : 821.8900372099813,
        "y" : 49.10123210402298
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37531",
        "shared_name" : "C18H23O10",
        "name" : "C18H23O10",
        "SUID" : 37531,
        "selected" : false
      },
      "position" : {
        "x" : -865.2951510834757,
        "y" : 1843.931388430317
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37530",
        "shared_name" : "C19H23O12",
        "name" : "C19H23O12",
        "SUID" : 37530,
        "selected" : false
      },
      "position" : {
        "x" : -787.6060107636515,
        "y" : 1775.2552867457466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37523",
        "shared_name" : "C19H15O12",
        "name" : "C19H15O12",
        "SUID" : 37523,
        "selected" : false
      },
      "position" : {
        "x" : 727.7533642363485,
        "y" : -1636.8372730687065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37517",
        "shared_name" : "C16H19O10",
        "name" : "C16H19O10",
        "SUID" : 37517,
        "selected" : false
      },
      "position" : {
        "x" : -84.88623842478432,
        "y" : -1035.4328464939995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37513",
        "shared_name" : "C15H11O6",
        "name" : "C15H11O6",
        "SUID" : 37513,
        "selected" : false
      },
      "position" : {
        "x" : -692.1592944550578,
        "y" : -1688.5095447972221
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37510",
        "shared_name" : "C14H19O9",
        "name" : "C14H19O9",
        "SUID" : 37510,
        "selected" : false
      },
      "position" : {
        "x" : -1105.7412951874796,
        "y" : -674.9285358860893
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37503",
        "shared_name" : "C18H15O9",
        "name" : "C18H15O9",
        "SUID" : 37503,
        "selected" : false
      },
      "position" : {
        "x" : -338.36529573679604,
        "y" : 2408.0364032313423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37496",
        "shared_name" : "C19H13O11",
        "name" : "C19H13O11",
        "SUID" : 37496,
        "selected" : false
      },
      "position" : {
        "x" : 810.1673161101278,
        "y" : -1739.4582142308159
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37483",
        "shared_name" : "C18H11O13",
        "name" : "C18H11O13",
        "SUID" : 37483,
        "selected" : false
      },
      "position" : {
        "x" : -438.75951418162026,
        "y" : -953.4647468998833
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37474",
        "shared_name" : "C19H15O9",
        "name" : "C19H15O9",
        "SUID" : 37474,
        "selected" : false
      },
      "position" : {
        "x" : -452.5720218110148,
        "y" : 2440.5570598170357
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37469",
        "shared_name" : "C12H13O9",
        "name" : "C12H13O9",
        "SUID" : 37469,
        "selected" : false
      },
      "position" : {
        "x" : -914.7672351288859,
        "y" : 1469.414069704731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37463",
        "shared_name" : "C15H7O9",
        "name" : "C15H7O9",
        "SUID" : 37463,
        "selected" : false
      },
      "position" : {
        "x" : 356.97940793752036,
        "y" : 162.88851886244584
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37457",
        "shared_name" : "C15H9O6",
        "name" : "C15H9O6",
        "SUID" : 37457,
        "selected" : false
      },
      "position" : {
        "x" : -515.596611349589,
        "y" : -619.9519886448784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37446",
        "shared_name" : "C14H11O8",
        "name" : "C14H11O8",
        "SUID" : 37446,
        "selected" : false
      },
      "position" : {
        "x" : -870.3156817841593,
        "y" : 707.8268809840279
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37434",
        "shared_name" : "C19H17O11",
        "name" : "C19H17O11",
        "SUID" : 37434,
        "selected" : false
      },
      "position" : {
        "x" : 999.8806530547079,
        "y" : -1025.2648395970268
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37429",
        "shared_name" : "C16H13O10",
        "name" : "C16H13O10",
        "SUID" : 37429,
        "selected" : false
      },
      "position" : {
        "x" : -533.3948901581828,
        "y" : -795.9549641087456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37421",
        "shared_name" : "C11H7O6",
        "name" : "C11H7O6",
        "SUID" : 37421,
        "selected" : false
      },
      "position" : {
        "x" : -617.8779529023234,
        "y" : 1830.3497691676216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37416",
        "shared_name" : "C13H17O7",
        "name" : "C13H17O7",
        "SUID" : 37416,
        "selected" : false
      },
      "position" : {
        "x" : -882.4496320176188,
        "y" : 2398.1723170802193
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37415",
        "shared_name" : "C13H19O8",
        "name" : "C13H19O8",
        "SUID" : 37415,
        "selected" : false
      },
      "position" : {
        "x" : -831.7718203949992,
        "y" : 2295.5082011744576
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37409",
        "shared_name" : "C17H11O11",
        "name" : "C17H11O11",
        "SUID" : 37409,
        "selected" : false
      },
      "position" : {
        "x" : -420.6999743866984,
        "y" : -844.8710483982964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37407",
        "shared_name" : "C18H13O11",
        "name" : "C18H13O11",
        "SUID" : 37407,
        "selected" : false
      },
      "position" : {
        "x" : -490.2974170136515,
        "y" : -429.978752560894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37403",
        "shared_name" : "C12H13O6",
        "name" : "C12H13O6",
        "SUID" : 37403,
        "selected" : false
      },
      "position" : {
        "x" : -314.8781970429484,
        "y" : 98.84876971693802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37398",
        "shared_name" : "C12H11O9",
        "name" : "C12H11O9",
        "SUID" : 37398,
        "selected" : false
      },
      "position" : {
        "x" : 990.0031353545126,
        "y" : 1450.3011355921822
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37393",
        "shared_name" : "C14H13O6",
        "name" : "C14H13O6",
        "SUID" : 37393,
        "selected" : false
      },
      "position" : {
        "x" : -782.1219104218546,
        "y" : -754.2474140599174
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37392",
        "shared_name" : "C15H13O8",
        "name" : "C15H13O8",
        "SUID" : 37392,
        "selected" : false
      },
      "position" : {
        "x" : -648.6594775605265,
        "y" : -728.4766010716362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37389",
        "shared_name" : "C13H13O10",
        "name" : "C13H13O10",
        "SUID" : 37389,
        "selected" : false
      },
      "position" : {
        "x" : 1051.1937519621786,
        "y" : 1775.2552867457466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37387",
        "shared_name" : "C18H23O9",
        "name" : "C18H23O9",
        "SUID" : 37387,
        "selected" : false
      },
      "position" : {
        "x" : 755.0447689604696,
        "y" : -932.2282757237358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37384",
        "shared_name" : "C13H17O10",
        "name" : "C13H17O10",
        "SUID" : 37384,
        "selected" : false
      },
      "position" : {
        "x" : -383.5247119355265,
        "y" : 82.4880214259224
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37379",
        "shared_name" : "C13H15O8",
        "name" : "C13H15O8",
        "SUID" : 37379,
        "selected" : false
      },
      "position" : {
        "x" : -874.8396838593546,
        "y" : 255.39569812269974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37376",
        "shared_name" : "C12H11O7",
        "name" : "C12H11O7",
        "SUID" : 37376,
        "selected" : false
      },
      "position" : {
        "x" : 1150.4916493010458,
        "y" : 1887.9429011866646
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37373",
        "shared_name" : "C14H7O10",
        "name" : "C14H7O10",
        "SUID" : 37373,
        "selected" : false
      },
      "position" : {
        "x" : -461.80004152537026,
        "y" : 1305.8531737849312
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37370",
        "shared_name" : "C14H17O10",
        "name" : "C14H17O10",
        "SUID" : 37370,
        "selected" : false
      },
      "position" : {
        "x" : -934.2367175507609,
        "y" : -2491.390388913433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37366",
        "shared_name" : "C12H11O5",
        "name" : "C12H11O5",
        "SUID" : 37366,
        "selected" : false
      },
      "position" : {
        "x" : -167.32503542185464,
        "y" : 39.764060549457554
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37363",
        "shared_name" : "C19H21O9",
        "name" : "C19H21O9",
        "SUID" : 37363,
        "selected" : false
      },
      "position" : {
        "x" : 718.6320683073934,
        "y" : -2288.077339597027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37360",
        "shared_name" : "C11H13O6",
        "name" : "C11H13O6",
        "SUID" : 37360,
        "selected" : false
      },
      "position" : {
        "x" : 1048.261729867452,
        "y" : 1994.964980654438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37357",
        "shared_name" : "C15H17O4",
        "name" : "C15H17O4",
        "SUID" : 37357,
        "selected" : false
      },
      "position" : {
        "x" : -219.23663362742104,
        "y" : -152.69170422105026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37355",
        "shared_name" : "C19H25O12",
        "name" : "C19H25O12",
        "SUID" : 37355,
        "selected" : false
      },
      "position" : {
        "x" : 670.1934544157918,
        "y" : -781.5597004368706
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37351",
        "shared_name" : "C16H13O8",
        "name" : "C16H13O8",
        "SUID" : 37351,
        "selected" : false
      },
      "position" : {
        "x" : 562.2333256316122,
        "y" : 1814.3519511744576
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37349",
        "shared_name" : "C18H19O13",
        "name" : "C18H19O13",
        "SUID" : 37349,
        "selected" : false
      },
      "position" : {
        "x" : -339.8451808381144,
        "y" : -2067.4344105198784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37345",
        "shared_name" : "C19H25O6",
        "name" : "C19H25O6",
        "SUID" : 37345,
        "selected" : false
      },
      "position" : {
        "x" : 150.9386974883016,
        "y" : 2452.669066958149
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37344",
        "shared_name" : "C20H25O8",
        "name" : "C20H25O8",
        "SUID" : 37344,
        "selected" : false
      },
      "position" : {
        "x" : 225.99666372060142,
        "y" : 2372.2016292140083
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37338",
        "shared_name" : "C15H11O10",
        "name" : "C15H11O10",
        "SUID" : 37338,
        "selected" : false
      },
      "position" : {
        "x" : -978.368225424296,
        "y" : 706.2150035426216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37329",
        "shared_name" : "C13H7O8",
        "name" : "C13H7O8",
        "SUID" : 37329,
        "selected" : false
      },
      "position" : {
        "x" : -564.3590777802531,
        "y" : 1271.6334643885689
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37327",
        "shared_name" : "C15H19O11",
        "name" : "C15H19O11",
        "SUID" : 37327,
        "selected" : false
      },
      "position" : {
        "x" : -892.4513171601359,
        "y" : -525.2815174534721
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37322",
        "shared_name" : "C17H21O5",
        "name" : "C17H21O5",
        "SUID" : 37322,
        "selected" : false
      },
      "position" : {
        "x" : 542.0210033965047,
        "y" : -2408.5882496312065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37318",
        "shared_name" : "C20H19O10",
        "name" : "C20H19O10",
        "SUID" : 37318,
        "selected" : false
      },
      "position" : {
        "x" : -500.47837862253823,
        "y" : 2338.3592753932076
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37317",
        "shared_name" : "C21H19O12",
        "name" : "C21H19O12",
        "SUID" : 37317,
        "selected" : false
      },
      "position" : {
        "x" : -451.7297671723429,
        "y" : 2236.9431987330513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37312",
        "shared_name" : "C19H19O10",
        "name" : "C19H19O10",
        "SUID" : 37312,
        "selected" : false
      },
      "position" : {
        "x" : -666.9991534638468,
        "y" : 2713.6377254054146
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37306",
        "shared_name" : "C11H9O6",
        "name" : "C11H9O6",
        "SUID" : 37306,
        "selected" : false
      },
      "position" : {
        "x" : 1111.7284008574422,
        "y" : 1548.4398952052193
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37302",
        "shared_name" : "C15H15O12",
        "name" : "C15H15O12",
        "SUID" : 37302,
        "selected" : false
      },
      "position" : {
        "x" : -899.9119647431437,
        "y" : 496.1807017848091
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37298",
        "shared_name" : "C19H23O9",
        "name" : "C19H23O9",
        "SUID" : 37298,
        "selected" : false
      },
      "position" : {
        "x" : -127.23928102732339,
        "y" : 1234.704825930317
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37292",
        "shared_name" : "C16H17O11",
        "name" : "C16H17O11",
        "SUID" : 37292,
        "selected" : false
      },
      "position" : {
        "x" : -564.6007312226359,
        "y" : -1801.9442066624565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37287",
        "shared_name" : "C20H29O9",
        "name" : "C20H29O9",
        "SUID" : 37287,
        "selected" : false
      },
      "position" : {
        "x" : 813.2006832671102,
        "y" : 2617.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37286",
        "shared_name" : "C20H31O10",
        "name" : "C20H31O10",
        "SUID" : 37286,
        "selected" : false
      },
      "position" : {
        "x" : 810.18323102712,
        "y" : 2725.5414844081
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37280",
        "shared_name" : "C16H13O11",
        "name" : "C16H13O11",
        "SUID" : 37280,
        "selected" : false
      },
      "position" : {
        "x" : 567.8469616484579,
        "y" : 34.98655848952103
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37279",
        "shared_name" : "C16H15O12",
        "name" : "C16H15O12",
        "SUID" : 37279,
        "selected" : false
      },
      "position" : {
        "x" : 456.97940793752036,
        "y" : 76.87590556593705
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37276",
        "shared_name" : "C14H11O6",
        "name" : "C14H11O6",
        "SUID" : 37276,
        "selected" : false
      },
      "position" : {
        "x" : 658.335029275411,
        "y" : 200.8361716792183
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37274",
        "shared_name" : "C12H13O8",
        "name" : "C12H13O8",
        "SUID" : 37274,
        "selected" : false
      },
      "position" : {
        "x" : 1035.719234139913,
        "y" : 1888.0241694972115
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37273",
        "shared_name" : "C12H15O9",
        "name" : "C12H15O9",
        "SUID" : 37273,
        "selected" : false
      },
      "position" : {
        "x" : 929.237186105245,
        "y" : 1885.7050929591255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37271",
        "shared_name" : "C13H13O8",
        "name" : "C13H13O8",
        "SUID" : 37271,
        "selected" : false
      },
      "position" : {
        "x" : -202.3017810273234,
        "y" : 114.2487407252388
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37270",
        "shared_name" : "C13H15O9",
        "name" : "C13H15O9",
        "SUID" : 37270,
        "selected" : false
      },
      "position" : {
        "x" : -304.43563112497964,
        "y" : 159.49945979567337
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37268",
        "shared_name" : "C17H9O12",
        "name" : "C17H9O12",
        "SUID" : 37268,
        "selected" : false
      },
      "position" : {
        "x" : -1080.7929919648234,
        "y" : -2098.683128781597
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37264",
        "shared_name" : "C12H9O7",
        "name" : "C12H9O7",
        "SUID" : 37264,
        "selected" : false
      },
      "position" : {
        "x" : -758.6143096375529,
        "y" : 1213.7641368434029
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37259",
        "shared_name" : "C16H13O12",
        "name" : "C16H13O12",
        "SUID" : 37259,
        "selected" : false
      },
      "position" : {
        "x" : -621.1992572236124,
        "y" : -2235.1783642247124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37256",
        "shared_name" : "C16H17O9",
        "name" : "C16H17O9",
        "SUID" : 37256,
        "selected" : false
      },
      "position" : {
        "x" : -140.15574678660073,
        "y" : -837.284546323101
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37253",
        "shared_name" : "C17H15O6",
        "name" : "C17H15O6",
        "SUID" : 37253,
        "selected" : false
      },
      "position" : {
        "x" : 911.6089855742391,
        "y" : -781.9986652806206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37252",
        "shared_name" : "C18H15O8",
        "name" : "C18H15O8",
        "SUID" : 37252,
        "selected" : false
      },
      "position" : {
        "x" : 843.6859814238485,
        "y" : -871.2926296666069
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37249",
        "shared_name" : "C15H11O7",
        "name" : "C15H11O7",
        "SUID" : 37249,
        "selected" : false
      },
      "position" : {
        "x" : -493.40843996287026,
        "y" : -720.2671589329643
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37245",
        "shared_name" : "C18H17O13",
        "name" : "C18H17O13",
        "SUID" : 37245,
        "selected" : false
      },
      "position" : {
        "x" : 7.634254128926614,
        "y" : -850.6654438450737
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37241",
        "shared_name" : "C15H9O9",
        "name" : "C15H9O9",
        "SUID" : 37241,
        "selected" : false
      },
      "position" : {
        "x" : -916.2954486298624,
        "y" : 832.4597220942574
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37240",
        "shared_name" : "C16H9O11",
        "name" : "C16H9O11",
        "SUID" : 37240,
        "selected" : false
      },
      "position" : {
        "x" : -946.1914218354289,
        "y" : 936.1108089015083
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37237",
        "shared_name" : "C19H15O11",
        "name" : "C19H15O11",
        "SUID" : 37237,
        "selected" : false
      },
      "position" : {
        "x" : -343.78598055124917,
        "y" : 2296.7054782435494
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37236",
        "shared_name" : "C20H19O12",
        "name" : "C20H19O12",
        "SUID" : 37236,
        "selected" : false
      },
      "position" : {
        "x" : -351.7297671723429,
        "y" : 2187.181876711567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37233",
        "shared_name" : "C13H9O9",
        "name" : "C13H9O9",
        "SUID" : 37233,
        "selected" : false
      },
      "position" : {
        "x" : -660.4829486298624,
        "y" : 1220.1518016383247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37232",
        "shared_name" : "C13H11O10",
        "name" : "C13H11O10",
        "SUID" : 37232,
        "selected" : false
      },
      "position" : {
        "x" : -741.8275345254008,
        "y" : 1312.6867881342964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37229",
        "shared_name" : "C20H23O11",
        "name" : "C20H23O11",
        "SUID" : 37229,
        "selected" : false
      },
      "position" : {
        "x" : -222.1332019257609,
        "y" : 1270.552009157856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37224",
        "shared_name" : "C18H25O8",
        "name" : "C18H25O8",
        "SUID" : 37224,
        "selected" : false
      },
      "position" : {
        "x" : -56.33599886179604,
        "y" : 1273.651603274067
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37218",
        "shared_name" : "C15H13O5",
        "name" : "C15H13O5",
        "SUID" : 37218,
        "selected" : false
      },
      "position" : {
        "x" : 113.20728269337974,
        "y" : -815.5283359959526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37215",
        "shared_name" : "C14H17O5",
        "name" : "C14H17O5",
        "SUID" : 37215,
        "selected" : false
      },
      "position" : {
        "x" : -271.0682834076945,
        "y" : -960.1413750126762
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37214",
        "shared_name" : "C15H17O7",
        "name" : "C15H17O7",
        "SUID" : 37214,
        "selected" : false
      },
      "position" : {
        "x" : -165.4869135308329,
        "y" : -979.3739895298881
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37211",
        "shared_name" : "C15H19O7",
        "name" : "C15H19O7",
        "SUID" : 37211,
        "selected" : false
      },
      "position" : {
        "x" : -233.45414003611245,
        "y" : -1916.109367795269
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37208",
        "shared_name" : "C17H15O10",
        "name" : "C17H15O10",
        "SUID" : 37208,
        "selected" : false
      },
      "position" : {
        "x" : -202.52002748728432,
        "y" : -723.9145130589409
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37205",
        "shared_name" : "C19H25O9",
        "name" : "C19H25O9",
        "SUID" : 37205,
        "selected" : false
      },
      "position" : {
        "x" : 6.253345162862161,
        "y" : 1844.3831553980904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37201",
        "shared_name" : "C19H17O13",
        "name" : "C19H17O13",
        "SUID" : 37201,
        "selected" : false
      },
      "position" : {
        "x" : 668.3474728178915,
        "y" : -1526.2817921116753
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37199",
        "shared_name" : "C15H13O11",
        "name" : "C15H13O11",
        "SUID" : 37199,
        "selected" : false
      },
      "position" : {
        "x" : -996.3071788239542,
        "y" : 561.9902110621529
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37197",
        "shared_name" : "C19H27O10",
        "name" : "C19H27O10",
        "SUID" : 37197,
        "selected" : false
      },
      "position" : {
        "x" : 86.7627293181356,
        "y" : 1775.2552867457466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37195",
        "shared_name" : "C18H21O10",
        "name" : "C18H21O10",
        "SUID" : 37195,
        "selected" : false
      },
      "position" : {
        "x" : 1052.0100170683797,
        "y" : -2246.2237934544487
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37193",
        "shared_name" : "C15H17O5",
        "name" : "C15H17O5",
        "SUID" : 37193,
        "selected" : false
      },
      "position" : {
        "x" : 610.3153912138876,
        "y" : -1411.5374683812065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37192",
        "shared_name" : "C15H19O6",
        "name" : "C15H19O6",
        "SUID" : 37192,
        "selected" : false
      },
      "position" : {
        "x" : 523.9735027861532,
        "y" : -1334.892570920269
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37184",
        "shared_name" : "C16H11O9",
        "name" : "C16H11O9",
        "SUID" : 37184,
        "selected" : false
      },
      "position" : {
        "x" : -377.5600360322062,
        "y" : -743.0507893040581
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37181",
        "shared_name" : "C17H13O9",
        "name" : "C17H13O9",
        "SUID" : 37181,
        "selected" : false
      },
      "position" : {
        "x" : 191.52237668752036,
        "y" : -741.2718128636284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37180",
        "shared_name" : "C18H17O10",
        "name" : "C18H17O10",
        "SUID" : 37180,
        "selected" : false
      },
      "position" : {
        "x" : 299.62137571095786,
        "y" : -774.4940571263237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37175",
        "shared_name" : "C19H21O8",
        "name" : "C19H21O8",
        "SUID" : 37175,
        "selected" : false
      },
      "position" : {
        "x" : -268.3599170136515,
        "y" : 1210.335700564106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37174",
        "shared_name" : "C20H21O10",
        "name" : "C20H21O10",
        "SUID" : 37174,
        "selected" : false
      },
      "position" : {
        "x" : -321.8087390351359,
        "y" : 1312.2116313502388
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37171",
        "shared_name" : "C17H17O13",
        "name" : "C17H17O13",
        "SUID" : 37171,
        "selected" : false
      },
      "position" : {
        "x" : -451.8601764130656,
        "y" : -2068.297630734722
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37167",
        "shared_name" : "C17H19O5",
        "name" : "C17H19O5",
        "SUID" : 37167,
        "selected" : false
      },
      "position" : {
        "x" : 656.9764057707723,
        "y" : -1171.3685841038628
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37162",
        "shared_name" : "C17H19O6",
        "name" : "C17H19O6",
        "SUID" : 37162,
        "selected" : false
      },
      "position" : {
        "x" : -1105.7412951874796,
        "y" : 1988.9193645045357
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37160",
        "shared_name" : "C18H11O8",
        "name" : "C18H11O8",
        "SUID" : 37160,
        "selected" : false
      },
      "position" : {
        "x" : 504.1483265471395,
        "y" : 2617.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37159",
        "shared_name" : "C19H11O10",
        "name" : "C19H11O10",
        "SUID" : 37159,
        "selected" : false
      },
      "position" : {
        "x" : 501.13087430714927,
        "y" : 2725.5414844081
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37156",
        "shared_name" : "C12H7O7",
        "name" : "C12H7O7",
        "SUID" : 37156,
        "selected" : false
      },
      "position" : {
        "x" : 914.2530285429891,
        "y" : 1637.0970531031685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37155",
        "shared_name" : "C12H9O8",
        "name" : "C12H9O8",
        "SUID" : 37155,
        "selected" : false
      },
      "position" : {
        "x" : 1007.477607400411,
        "y" : 1569.5231547877388
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37152",
        "shared_name" : "C16H21O11",
        "name" : "C16H21O11",
        "SUID" : 37152,
        "selected" : false
      },
      "position" : {
        "x" : -193.5175898957316,
        "y" : -1076.381340451519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37146",
        "shared_name" : "C14H13O11",
        "name" : "C14H13O11",
        "SUID" : 37146,
        "selected" : false
      },
      "position" : {
        "x" : 268.0778576445516,
        "y" : 1368.6365366503792
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37141",
        "shared_name" : "C16H21O5",
        "name" : "C16H21O5",
        "SUID" : 37141,
        "selected" : false
      },
      "position" : {
        "x" : -996.2296069550578,
        "y" : 2087.181876711567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37139",
        "shared_name" : "C15H11O11",
        "name" : "C15H11O11",
        "SUID" : 37139,
        "selected" : false
      },
      "position" : {
        "x" : 45.43737664937339,
        "y" : -8.250755734722134
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37138",
        "shared_name" : "C16H11O13",
        "name" : "C16H11O13",
        "SUID" : 37138,
        "selected" : false
      },
      "position" : {
        "x" : 107.56063428639732,
        "y" : 80.50622516127396
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37133",
        "shared_name" : "C12H13O7",
        "name" : "C12H13O7",
        "SUID" : 37133,
        "selected" : false
      },
      "position" : {
        "x" : 597.2378670287069,
        "y" : 1174.0229106471138
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37124",
        "shared_name" : "C15H15O6",
        "name" : "C15H15O6",
        "SUID" : 37124,
        "selected" : false
      },
      "position" : {
        "x" : 15.269782693379739,
        "y" : -772.5272144749565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37122",
        "shared_name" : "C19H23O11",
        "name" : "C19H23O11",
        "SUID" : 37122,
        "selected" : false
      },
      "position" : {
        "x" : 767.0318676543172,
        "y" : -825.4856495335503
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37119",
        "shared_name" : "C14H11O10",
        "name" : "C14H11O10",
        "SUID" : 37119,
        "selected" : false
      },
      "position" : {
        "x" : 315.3611828398641,
        "y" : 1270.6421428248482
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37118",
        "shared_name" : "C15H11O12",
        "name" : "C15H11O12",
        "SUID" : 37118,
        "selected" : false
      },
      "position" : {
        "x" : 200.8963390898641,
        "y" : 1252.74766498061
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37115",
        "shared_name" : "C15H9O10",
        "name" : "C15H9O10",
        "SUID" : 37115,
        "selected" : false
      },
      "position" : {
        "x" : 249.4882275175985,
        "y" : 172.4228005930977
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37114",
        "shared_name" : "C16H9O12",
        "name" : "C16H9O12",
        "SUID" : 37114,
        "selected" : false
      },
      "position" : {
        "x" : 227.89159360646568,
        "y" : 75.55795245619584
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37112",
        "shared_name" : "C13H11O7",
        "name" : "C13H11O7",
        "SUID" : 37112,
        "selected" : false
      },
      "position" : {
        "x" : -94.81230959177651,
        "y" : 116.78476672621537
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37110",
        "shared_name" : "C16H19O8",
        "name" : "C16H19O8",
        "SUID" : 37110,
        "selected" : false
      },
      "position" : {
        "x" : 477.65564695119224,
        "y" : -1455.2302784398003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37104",
        "shared_name" : "C16H19O5",
        "name" : "C16H19O5",
        "SUID" : 37104,
        "selected" : false
      },
      "position" : {
        "x" : 1130.1908642363485,
        "y" : -2305.942345090191
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37101",
        "shared_name" : "C19H21O12",
        "name" : "C19H21O12",
        "SUID" : 37101,
        "selected" : false
      },
      "position" : {
        "x" : 1093.5924450468954,
        "y" : -2144.498539395611
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37100",
        "shared_name" : "C19H23O13",
        "name" : "C19H23O13",
        "SUID" : 37100,
        "selected" : false
      },
      "position" : {
        "x" : 1181.1348644804891,
        "y" : -2091.248970456402
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37097",
        "shared_name" : "C14H17O7",
        "name" : "C14H17O7",
        "SUID" : 37097,
        "selected" : false
      },
      "position" : {
        "x" : -693.202080099589,
        "y" : -1968.2879871800346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37096",
        "shared_name" : "C15H17O9",
        "name" : "C15H17O9",
        "SUID" : 37096,
        "selected" : false
      },
      "position" : {
        "x" : -676.1160510468546,
        "y" : -1845.6390308812065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37093",
        "shared_name" : "C20H23O10",
        "name" : "C20H23O10",
        "SUID" : 37093,
        "selected" : false
      },
      "position" : {
        "x" : 0.5666386198934106,
        "y" : 1973.3036265894966
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37091",
        "shared_name" : "C20H27O9",
        "name" : "C20H27O9",
        "SUID" : 37091,
        "selected" : false
      },
      "position" : {
        "x" : 289.30533376454673,
        "y" : 2283.4405894801216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37090",
        "shared_name" : "C21H27O11",
        "name" : "C21H27O11",
        "SUID" : 37090,
        "selected" : false
      },
      "position" : {
        "x" : 342.26556936024986,
        "y" : 2187.181876711567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37088",
        "shared_name" : "C20H19O11",
        "name" : "C20H19O11",
        "SUID" : 37088,
        "selected" : false
      },
      "position" : {
        "x" : 631.6718474936422,
        "y" : -902.2560562565727
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37084",
        "shared_name" : "C17H25O10",
        "name" : "C17H25O10",
        "SUID" : 37084,
        "selected" : false
      },
      "position" : {
        "x" : 1016.6919018340047,
        "y" : -2556.660393185894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37082",
        "shared_name" : "C10H13O6",
        "name" : "C10H13O6",
        "SUID" : 37082,
        "selected" : false
      },
      "position" : {
        "x" : 1016.2306438994344,
        "y" : 1115.8231273219185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37081",
        "shared_name" : "C11H13O8",
        "name" : "C11H13O8",
        "SUID" : 37081,
        "selected" : false
      },
      "position" : {
        "x" : 979.3044506621297,
        "y" : 1220.3177562281685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37079",
        "shared_name" : "C18H19O6",
        "name" : "C18H19O6",
        "SUID" : 37079,
        "selected" : false
      },
      "position" : {
        "x" : 520.9691845488485,
        "y" : -2320.986519284527
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37078",
        "shared_name" : "C19H19O8",
        "name" : "C19H19O8",
        "SUID" : 37078,
        "selected" : false
      },
      "position" : {
        "x" : 637.2422863554891,
        "y" : -2376.0962757542534
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37076",
        "shared_name" : "C18H17O9",
        "name" : "C18H17O9",
        "SUID" : 37076,
        "selected" : false
      },
      "position" : {
        "x" : 946.2529064726766,
        "y" : -911.0755863860054
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37075",
        "shared_name" : "C18H19O10",
        "name" : "C18H19O10",
        "SUID" : 37075,
        "selected" : false
      },
      "position" : {
        "x" : 1063.4412609648641,
        "y" : -927.091693349163
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37073",
        "shared_name" : "C18H21O13",
        "name" : "C18H21O13",
        "SUID" : 37073,
        "selected" : false
      },
      "position" : {
        "x" : 446.6874767851766,
        "y" : -1383.6805347874565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37071",
        "shared_name" : "C12H15O6",
        "name" : "C12H15O6",
        "SUID" : 37071,
        "selected" : false
      },
      "position" : {
        "x" : -799.5951770234171,
        "y" : 169.7169261500435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37070",
        "shared_name" : "C12H17O7",
        "name" : "C12H17O7",
        "SUID" : 37070,
        "selected" : false
      },
      "position" : {
        "x" : -824.9408038544718,
        "y" : 55.46338611098099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37068",
        "shared_name" : "C17H17O6",
        "name" : "C17H17O6",
        "SUID" : 37068,
        "selected" : false
      },
      "position" : {
        "x" : 1009.5020977568563,
        "y" : -2167.330519624035
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37067",
        "shared_name" : "C18H17O8",
        "name" : "C18H17O8",
        "SUID" : 37067,
        "selected" : false
      },
      "position" : {
        "x" : 937.0201183867391,
        "y" : -2090.6445621922417
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37064",
        "shared_name" : "C12H11O6",
        "name" : "C12H11O6",
        "SUID" : 37064,
        "selected" : false
      },
      "position" : {
        "x" : 492.0494915556844,
        "y" : 1145.3312144801216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37063",
        "shared_name" : "C13H11O8",
        "name" : "C13H11O8",
        "SUID" : 37063,
        "selected" : false
      },
      "position" : {
        "x" : 408.3162762236532,
        "y" : 1212.3169627711372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37060",
        "shared_name" : "C18H25O9",
        "name" : "C18H25O9",
        "SUID" : 37060,
        "selected" : false
      },
      "position" : {
        "x" : 950.1762310576376,
        "y" : -2254.278526730816
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37058",
        "shared_name" : "C14H15O5",
        "name" : "C14H15O5",
        "SUID" : 37058,
        "selected" : false
      },
      "position" : {
        "x" : 70.04508176564536,
        "y" : -1495.0930714085503
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37055",
        "shared_name" : "C19H25O10",
        "name" : "C19H25O10",
        "SUID" : 37055,
        "selected" : false
      },
      "position" : {
        "x" : -79.32991823435464,
        "y" : 1164.1055064723091
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37054",
        "shared_name" : "C20H25O12",
        "name" : "C20H25O12",
        "SUID" : 37054,
        "selected" : false
      },
      "position" : {
        "x" : -183.11776003122964,
        "y" : 1170.1869884059029
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37052",
        "shared_name" : "C15H15O8",
        "name" : "C15H15O8",
        "SUID" : 37052,
        "selected" : false
      },
      "position" : {
        "x" : -606.4803851533,
        "y" : -1912.4950794651909
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37050",
        "shared_name" : "C12H15O8",
        "name" : "C12H15O8",
        "SUID" : 37050,
        "selected" : false
      },
      "position" : {
        "x" : 700.4653088164266,
        "y" : 1228.3218455836372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37046",
        "shared_name" : "C16H11O10",
        "name" : "C16H11O10",
        "SUID" : 37046,
        "selected" : false
      },
      "position" : {
        "x" : 719.502151162618,
        "y" : 35.51821666212845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37045",
        "shared_name" : "C17H11O12",
        "name" : "C17H11O12",
        "SUID" : 37045,
        "selected" : false
      },
      "position" : {
        "x" : 797.5737902235921,
        "y" : -36.81274933366012
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37043",
        "shared_name" : "C15H13O10",
        "name" : "C15H13O10",
        "SUID" : 37043,
        "selected" : false
      },
      "position" : {
        "x" : -719.5289233613078,
        "y" : -2295.915203519146
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37041",
        "shared_name" : "C16H15O10",
        "name" : "C16H15O10",
        "SUID" : 37041,
        "selected" : false
      },
      "position" : {
        "x" : -495.97110780954995,
        "y" : -1895.4864735081596
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37037",
        "shared_name" : "C20H25O11",
        "name" : "C20H25O11",
        "SUID" : 37037,
        "selected" : false
      },
      "position" : {
        "x" : 85.84825483083091,
        "y" : 1912.5613170191841
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37036",
        "shared_name" : "C20H27O12",
        "name" : "C20H27O12",
        "SUID" : 37036,
        "selected" : false
      },
      "position" : {
        "x" : 162.7936894011434,
        "y" : 1845.0721812769966
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37033",
        "shared_name" : "C13H11O6",
        "name" : "C13H11O6",
        "SUID" : 37033,
        "selected" : false
      },
      "position" : {
        "x" : -820.7758410859171,
        "y" : 337.7513499781685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37030",
        "shared_name" : "C13H13O9",
        "name" : "C13H13O9",
        "SUID" : 37030,
        "selected" : false
      },
      "position" : {
        "x" : 523.7662045073446,
        "y" : 1258.8313823268013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37029",
        "shared_name" : "C13H15O10",
        "name" : "C13H15O10",
        "SUID" : 37029,
        "selected" : false
      },
      "position" : {
        "x" : 621.4126574110921,
        "y" : 1300.881957583149
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37027",
        "shared_name" : "C17H23O5",
        "name" : "C17H23O5",
        "SUID" : 37027,
        "selected" : false
      },
      "position" : {
        "x" : 68.62285772084556,
        "y" : 1115.8231273219185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37026",
        "shared_name" : "C18H23O7",
        "name" : "C18H23O7",
        "SUID" : 37026,
        "selected" : false
      },
      "position" : {
        "x" : -4.0799258637491675,
        "y" : 1193.8089366480904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37024",
        "shared_name" : "C19H19O12",
        "name" : "C19H19O12",
        "SUID" : 37024,
        "selected" : false
      },
      "position" : {
        "x" : 1110.5013500761922,
        "y" : -1029.8264851048393
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37023",
        "shared_name" : "C19H21O13",
        "name" : "C19H21O13",
        "SUID" : 37023,
        "selected" : false
      },
      "position" : {
        "x" : 1217.2284313750204,
        "y" : -1031.95887798814
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37021",
        "shared_name" : "C16H23O9",
        "name" : "C16H23O9",
        "SUID" : 37021,
        "selected" : false
      },
      "position" : {
        "x" : 135.77991452931724,
        "y" : -342.80913586167526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37020",
        "shared_name" : "C17H23O11",
        "name" : "C17H23O11",
        "SUID" : 37020,
        "selected" : false
      },
      "position" : {
        "x" : 225.39527097462974,
        "y" : -290.10161633042526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37018",
        "shared_name" : "C15H21O9",
        "name" : "C15H21O9",
        "SUID" : 37018,
        "selected" : false
      },
      "position" : {
        "x" : -234.71853670359292,
        "y" : -1171.3685841038628
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37015",
        "shared_name" : "C18H11O12",
        "name" : "C18H11O12",
        "SUID" : 37015,
        "selected" : false
      },
      "position" : {
        "x" : -471.94918855906167,
        "y" : -1606.2132801487846
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37013",
        "shared_name" : "C18H17O7",
        "name" : "C18H17O7",
        "SUID" : 37013,
        "selected" : false
      },
      "position" : {
        "x" : -860.6751483368937,
        "y" : 2617.81931643935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37012",
        "shared_name" : "C19H17O9",
        "name" : "C19H17O9",
        "SUID" : 37012,
        "selected" : false
      },
      "position" : {
        "x" : -761.4764483857218,
        "y" : 2660.0077395960884
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37010",
        "shared_name" : "C15H13O7",
        "name" : "C15H13O7",
        "SUID" : 37010,
        "selected" : false
      },
      "position" : {
        "x" : -693.4580615449015,
        "y" : -1798.6935657933159
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37007",
        "shared_name" : "C15H15O9",
        "name" : "C15H15O9",
        "SUID" : 37007,
        "selected" : false
      },
      "position" : {
        "x" : -783.9902575898234,
        "y" : -666.9068226292534
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37005",
        "shared_name" : "C17H17O7",
        "name" : "C17H17O7",
        "SUID" : 37005,
        "selected" : false
      },
      "position" : {
        "x" : 1009.4399487090047,
        "y" : -822.7615894749565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37004",
        "shared_name" : "C17H19O8",
        "name" : "C17H19O8",
        "SUID" : 37004,
        "selected" : false
      },
      "position" : {
        "x" : 1122.5551525664266,
        "y" : -828.8533024266167
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37002",
        "shared_name" : "C19H15O13",
        "name" : "C19H15O13",
        "SUID" : 37002,
        "selected" : false
      },
      "position" : {
        "x" : -346.3967250275675,
        "y" : -1535.4465565159721
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36999",
        "shared_name" : "C15H11O5",
        "name" : "C15H11O5",
        "SUID" : 36999,
        "selected" : false
      },
      "position" : {
        "x" : 717.196170480245,
        "y" : 1945.7423167750435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36998",
        "shared_name" : "C16H11O7",
        "name" : "C16H11O7",
        "SUID" : 36998,
        "selected" : false
      },
      "position" : {
        "x" : 660.3929096770223,
        "y" : 1856.63381152602
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36996",
        "shared_name" : "C19H21O10",
        "name" : "C19H21O10",
        "SUID" : 36996,
        "selected" : false
      },
      "position" : {
        "x" : 811.8102642607626,
        "y" : -923.228041119854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36994",
        "shared_name" : "C18H21O7",
        "name" : "C18H21O7",
        "SUID" : 36994,
        "selected" : false
      },
      "position" : {
        "x" : 622.4728466582235,
        "y" : -2324.3973621800346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36993",
        "shared_name" : "C18H23O8",
        "name" : "C18H23O8",
        "SUID" : 36993,
        "selected" : false
      },
      "position" : {
        "x" : 740.6631886076864,
        "y" : -2344.891350217144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36991",
        "shared_name" : "C16H11O11",
        "name" : "C16H11O11",
        "SUID" : 36991,
        "selected" : false
      },
      "position" : {
        "x" : -631.8115924286906,
        "y" : -2125.4112019017143
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36989",
        "shared_name" : "C20H21O6",
        "name" : "C20H21O6",
        "SUID" : 36989,
        "selected" : false
      },
      "position" : {
        "x" : 876.0674339842733,
        "y" : 2347.6302714869576
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36985",
        "shared_name" : "C17H21O9",
        "name" : "C17H21O9",
        "SUID" : 36985,
        "selected" : false
      },
      "position" : {
        "x" : 1230.8074719023641,
        "y" : -849.4624943211479
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36984",
        "shared_name" : "C18H21O11",
        "name" : "C18H21O11",
        "SUID" : 36984,
        "selected" : false
      },
      "position" : {
        "x" : 1172.6916271758016,
        "y" : -939.3536514714165
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36982",
        "shared_name" : "C14H13O10",
        "name" : "C14H13O10",
        "SUID" : 36982,
        "selected" : false
      },
      "position" : {
        "x" : -98.64844545603432,
        "y" : 45.95891528578568
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36981",
        "shared_name" : "C15H13O12",
        "name" : "C15H13O12",
        "SUID" : 36981,
        "selected" : false
      },
      "position" : {
        "x" : -56.979690878397605,
        "y" : -52.69170422105026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36979",
        "shared_name" : "C20H21O12",
        "name" : "C20H21O12",
        "SUID" : 36979,
        "selected" : false
      },
      "position" : {
        "x" : 723.4364925932821,
        "y" : -849.5340504124565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36978",
        "shared_name" : "C20H23O13",
        "name" : "C20H23O13",
        "SUID" : 36978,
        "selected" : false
      },
      "position" : {
        "x" : 720.7012020659383,
        "y" : -740.7728046849174
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36976",
        "shared_name" : "C16H13O6",
        "name" : "C16H13O6",
        "SUID" : 36976,
        "selected" : false
      },
      "position" : {
        "x" : -123.89882692576089,
        "y" : -1545.4436268284721
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36975",
        "shared_name" : "C17H13O8",
        "name" : "C17H13O8",
        "SUID" : 36975,
        "selected" : false
      },
      "position" : {
        "x" : -198.99373659372964,
        "y" : -1629.6518177464409
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36971",
        "shared_name" : "C19H21O7",
        "name" : "C19H21O7",
        "SUID" : 36971,
        "selected" : false
      },
      "position" : {
        "x" : -184.42376360178628,
        "y" : 1912.4891124293404
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36970",
        "shared_name" : "C19H23O8",
        "name" : "C19H23O8",
        "SUID" : 36970,
        "selected" : false
      },
      "position" : {
        "x" : -79.19207414866128,
        "y" : 1903.4115977809029
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36968",
        "shared_name" : "C16H9O10",
        "name" : "C16H9O10",
        "SUID" : 36968,
        "selected" : false
      },
      "position" : {
        "x" : -972.0490344452921,
        "y" : -2116.2542347386284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36966",
        "shared_name" : "C14H11O7",
        "name" : "C14H11O7",
        "SUID" : 36966,
        "selected" : false
      },
      "position" : {
        "x" : -738.7079699921671,
        "y" : -2079.5665821507378
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36965",
        "shared_name" : "C14H13O8",
        "name" : "C14H13O8",
        "SUID" : 36965,
        "selected" : false
      },
      "position" : {
        "x" : -838.8770678925578,
        "y" : -2245.9348110630913
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36962",
        "shared_name" : "C18H15O10",
        "name" : "C18H15O10",
        "SUID" : 36962,
        "selected" : false
      },
      "position" : {
        "x" : 593.0126720976766,
        "y" : -1627.9481129124565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36960",
        "shared_name" : "C19H17O10",
        "name" : "C19H17O10",
        "SUID" : 36960,
        "selected" : false
      },
      "position" : {
        "x" : 909.9937817168172,
        "y" : -1968.9447407200737
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36959",
        "shared_name" : "C20H17O12",
        "name" : "C20H17O12",
        "SUID" : 36959,
        "selected" : false
      },
      "position" : {
        "x" : 986.0371014189657,
        "y" : -1888.3421253636284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36957",
        "shared_name" : "C15H21O6",
        "name" : "C15H21O6",
        "SUID" : 36957,
        "selected" : false
      },
      "position" : {
        "x" : 57.25379148244224,
        "y" : -264.861809201519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36956",
        "shared_name" : "C16H21O8",
        "name" : "C16H21O8",
        "SUID" : 36956,
        "selected" : false
      },
      "position" : {
        "x" : 32.892997415059426,
        "y" : -373.0797047093315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36954",
        "shared_name" : "C12H7O8",
        "name" : "C12H7O8",
        "SUID" : 36954,
        "selected" : false
      },
      "position" : {
        "x" : -579.9892505097453,
        "y" : 1930.7906261012154
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36953",
        "shared_name" : "C13H7O10",
        "name" : "C13H7O10",
        "SUID" : 36953,
        "selected" : false
      },
      "position" : {
        "x" : -687.6060107636515,
        "y" : 1944.5377879664497
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36951",
        "shared_name" : "C15H15O5",
        "name" : "C15H15O5",
        "SUID" : 36951,
        "selected" : false
      },
      "position" : {
        "x" : -65.16426882029214,
        "y" : -1786.1827320530815
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36950",
        "shared_name" : "C16H15O7",
        "name" : "C16H15O7",
        "SUID" : 36950,
        "selected" : false
      },
      "position" : {
        "x" : -167.7020495820109,
        "y" : -1756.2764820530815
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36948",
        "shared_name" : "C17H23O9",
        "name" : "C17H23O9",
        "SUID" : 36948,
        "selected" : false
      },
      "position" : {
        "x" : 1084.7563244414266,
        "y" : -2478.3794483616753
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36947",
        "shared_name" : "C18H23O11",
        "name" : "C18H23O11",
        "SUID" : 36947,
        "selected" : false
      },
      "position" : {
        "x" : 1012.0424725127157,
        "y" : -2383.4990772679253
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36945",
        "shared_name" : "C15H9O7",
        "name" : "C15H9O7",
        "SUID" : 36945,
        "selected" : false
      },
      "position" : {
        "x" : 717.9654537749227,
        "y" : -16.288230366985317
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36944",
        "shared_name" : "C15H11O8",
        "name" : "C15H11O8",
        "SUID" : 36944,
        "selected" : false
      },
      "position" : {
        "x" : 641.2430492949422,
        "y" : 90.60705333205033
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36942",
        "shared_name" : "C17H17O11",
        "name" : "C17H17O11",
        "SUID" : 36942,
        "selected" : false
      },
      "position" : {
        "x" : -69.23111757517495,
        "y" : -771.8507465794487
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36941",
        "shared_name" : "C18H21O12",
        "name" : "C18H21O12",
        "SUID" : 36941,
        "selected" : false
      },
      "position" : {
        "x" : -46.6786883759562,
        "y" : -653.5203175023003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36938",
        "shared_name" : "C17H13O12",
        "name" : "C17H13O12",
        "SUID" : 36938,
        "selected" : false
      },
      "position" : {
        "x" : -510.1802295136515,
        "y" : -906.8360332920952
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36937",
        "shared_name" : "C18H13O14",
        "name" : "C18H13O14",
        "SUID" : 36937,
        "selected" : false
      },
      "position" : {
        "x" : -528.6838000702921,
        "y" : -1024.481682248394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36933",
        "shared_name" : "C16H9O8",
        "name" : "C16H9O8",
        "SUID" : 36933,
        "selected" : false
      },
      "position" : {
        "x" : -412.4621051240031,
        "y" : -636.8272022679253
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36932",
        "shared_name" : "C17H9O10",
        "name" : "C17H9O10",
        "SUID" : 36932,
        "selected" : false
      },
      "position" : {
        "x" : -441.0886767792765,
        "y" : -524.0817188694878
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36930",
        "shared_name" : "C11H11O6",
        "name" : "C11H11O6",
        "SUID" : 36930,
        "selected" : false
      },
      "position" : {
        "x" : -767.5941890168253,
        "y" : 1516.1824260279732
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36929",
        "shared_name" : "C12H11O8",
        "name" : "C12H11O8",
        "SUID" : 36929,
        "selected" : false
      },
      "position" : {
        "x" : -815.3684924531046,
        "y" : 1419.1519160792427
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36927",
        "shared_name" : "C17H19O9",
        "name" : "C17H19O9",
        "SUID" : 36927,
        "selected" : false
      },
      "position" : {
        "x" : -126.84368547678628,
        "y" : -467.2705921605034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36926",
        "shared_name" : "C18H19O11",
        "name" : "C18H19O11",
        "SUID" : 36926,
        "selected" : false
      },
      "position" : {
        "x" : -155.57737883806863,
        "y" : -606.055656857769
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36924",
        "shared_name" : "C17H15O9",
        "name" : "C17H15O9",
        "SUID" : 36924,
        "selected" : false
      },
      "position" : {
        "x" : -275.1122592377726,
        "y" : -1719.5094837620659
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36923",
        "shared_name" : "C18H15O11",
        "name" : "C18H15O11",
        "SUID" : 36923,
        "selected" : false
      },
      "position" : {
        "x" : -369.213669149882,
        "y" : -1649.2591785862846
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36921",
        "shared_name" : "C18H19O9",
        "name" : "C18H19O9",
        "SUID" : 36921,
        "selected" : false
      },
      "position" : {
        "x" : 955.0671764922079,
        "y" : -2196.1299709752006
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36920",
        "shared_name" : "C19H19O11",
        "name" : "C19H19O11",
        "SUID" : 36920,
        "selected" : false
      },
      "position" : {
        "x" : 999.6549297881063,
        "y" : -2095.303787656109
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36918",
        "shared_name" : "C17H21O12",
        "name" : "C17H21O12",
        "SUID" : 36918,
        "selected" : false
      },
      "position" : {
        "x" : -272.84759554148354,
        "y" : -2027.0997852757378
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36916",
        "shared_name" : "C15H11O9",
        "name" : "C15H11O9",
        "SUID" : 36916,
        "selected" : false
      },
      "position" : {
        "x" : -731.7725451874796,
        "y" : -2177.0524296238823
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36914",
        "shared_name" : "C13H13O7",
        "name" : "C13H13O7",
        "SUID" : 36914,
        "selected" : false
      },
      "position" : {
        "x" : -951.2347720551554,
        "y" : 334.583259157856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36912",
        "shared_name" : "C20H25O13",
        "name" : "C20H25O13",
        "SUID" : 36912,
        "selected" : false
      },
      "position" : {
        "x" : 757.2834316801961,
        "y" : -2110.9585957005424
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36910",
        "shared_name" : "C14H19O6",
        "name" : "C14H19O6",
        "SUID" : 36910,
        "selected" : false
      },
      "position" : {
        "x" : -256.6608966279093,
        "y" : -1062.706779904644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36909",
        "shared_name" : "C15H19O8",
        "name" : "C15H19O8",
        "SUID" : 36909,
        "selected" : false
      },
      "position" : {
        "x" : -158.3044196057383,
        "y" : -1103.2601246312065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36907",
        "shared_name" : "C13H15O7",
        "name" : "C13H15O7",
        "SUID" : 36907,
        "selected" : false
      },
      "position" : {
        "x" : -998.9128650116984,
        "y" : -2431.8735889866753
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36906",
        "shared_name" : "C13H17O8",
        "name" : "C13H17O8",
        "SUID" : 36906,
        "selected" : false
      },
      "position" : {
        "x" : -1021.8233264374796,
        "y" : -2554.1111683323784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36904",
        "shared_name" : "C19H23O10",
        "name" : "C19H23O10",
        "SUID" : 36904,
        "selected" : false
      },
      "position" : {
        "x" : 826.1245533537801,
        "y" : -2270.15223736314
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36903",
        "shared_name" : "C19H25O11",
        "name" : "C19H25O11",
        "SUID" : 36903,
        "selected" : false
      },
      "position" : {
        "x" : 840.1703793120321,
        "y" : -2171.0683831646843
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36901",
        "shared_name" : "C15H7O8",
        "name" : "C15H7O8",
        "SUID" : 36901,
        "selected" : false
      },
      "position" : {
        "x" : -835.400566427714,
        "y" : 910.3685679957466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36899",
        "shared_name" : "C16H19O9",
        "name" : "C16H19O9",
        "SUID" : 36899,
        "selected" : false
      },
      "position" : {
        "x" : -349.8457034516398,
        "y" : -1866.6756214573784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36897",
        "shared_name" : "C17H15O12",
        "name" : "C17H15O12",
        "SUID" : 36897,
        "selected" : false
      },
      "position" : {
        "x" : -532.1990741181437,
        "y" : -1975.7244190648003
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36895",
        "shared_name" : "C15H17O6",
        "name" : "C15H17O6",
        "SUID" : 36895,
        "selected" : false
      },
      "position" : {
        "x" : -136.65670046091714,
        "y" : -1862.0079273655815
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36894",
        "shared_name" : "C16H17O8",
        "name" : "C16H17O8",
        "SUID" : 36894,
        "selected" : false
      },
      "position" : {
        "x" : -236.91349062204995,
        "y" : -1833.4161304905815
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36892",
        "shared_name" : "C15H17O10",
        "name" : "C15H17O10",
        "SUID" : 36892,
        "selected" : false
      },
      "position" : {
        "x" : -885.3500598359171,
        "y" : -628.8566212132378
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36891",
        "shared_name" : "C16H17O12",
        "name" : "C16H17O12",
        "SUID" : 36891,
        "selected" : false
      },
      "position" : {
        "x" : -953.0957873749796,
        "y" : -714.2767567112846
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36889",
        "shared_name" : "C18H21O8",
        "name" : "C18H21O8",
        "SUID" : 36889,
        "selected" : false
      },
      "position" : {
        "x" : 794.2465435576376,
        "y" : -1031.1568378880424
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36887",
        "shared_name" : "C16H17O5",
        "name" : "C16H17O5",
        "SUID" : 36887,
        "selected" : false
      },
      "position" : {
        "x" : 1065.1449352812704,
        "y" : -730.2012257054253
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36886",
        "shared_name" : "C16H19O6",
        "name" : "C16H19O6",
        "SUID" : 36886,
        "selected" : false
      },
      "position" : {
        "x" : 1171.6860729765829,
        "y" : -729.1115040257378
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36884",
        "shared_name" : "C16H15O6",
        "name" : "C16H15O6",
        "SUID" : 36884,
        "selected" : false
      },
      "position" : {
        "x" : 649.0286938261922,
        "y" : -1609.7659229710503
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36883",
        "shared_name" : "C16H17O7",
        "name" : "C16H17O7",
        "SUID" : 36883,
        "selected" : false
      },
      "position" : {
        "x" : 571.1876904082235,
        "y" : -1539.1524586155815
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36881",
        "shared_name" : "C21H21O8",
        "name" : "C21H21O8",
        "SUID" : 36881,
        "selected" : false
      },
      "position" : {
        "x" : 800.9809776854452,
        "y" : 2270.2152019068794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36880",
        "shared_name" : "C22H21O10",
        "name" : "C22H21O10",
        "SUID" : 36880,
        "selected" : false
      },
      "position" : {
        "x" : 731.0012871336874,
        "y" : 2187.181876711567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36878",
        "shared_name" : "C14H13O9",
        "name" : "C14H13O9",
        "SUID" : 36878,
        "selected" : false
      },
      "position" : {
        "x" : -981.0303386139933,
        "y" : 442.094245485981
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36877",
        "shared_name" : "C14H15O10",
        "name" : "C14H15O10",
        "SUID" : 36877,
        "selected" : false
      },
      "position" : {
        "x" : -888.4757159638468,
        "y" : 375.35358386488724
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36875",
        "shared_name" : "C18H17O12",
        "name" : "C18H17O12",
        "SUID" : 36875,
        "selected" : false
      },
      "position" : {
        "x" : -357.5448821473185,
        "y" : -1743.2014393284721
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36873",
        "shared_name" : "C18H17O11",
        "name" : "C18H17O11",
        "SUID" : 36873,
        "selected" : false
      },
      "position" : {
        "x" : 527.9965893340047,
        "y" : -1528.8729786351128
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36871",
        "shared_name" : "C16H11O8",
        "name" : "C16H11O8",
        "SUID" : 36871,
        "selected" : false
      },
      "position" : {
        "x" : -589.6413043427531,
        "y" : -1711.6568226292534
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36870",
        "shared_name" : "C16H13O9",
        "name" : "C16H13O9",
        "SUID" : 36870,
        "selected" : false
      },
      "position" : {
        "x" : -598.1981891083781,
        "y" : -1829.5873341038628
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36868",
        "shared_name" : "C17H19O7",
        "name" : "C17H19O7",
        "SUID" : 36868,
        "selected" : false
      },
      "position" : {
        "x" : 1023.4185101103719,
        "y" : -2280.775009579937
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36867",
        "shared_name" : "C17H21O8",
        "name" : "C17H21O8",
        "SUID" : 36867,
        "selected" : false
      },
      "position" : {
        "x" : 1082.2008434843954,
        "y" : -2374.1504902317924
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36865",
        "shared_name" : "C14H7O7",
        "name" : "C14H7O7",
        "SUID" : 36865,
        "selected" : false
      },
      "position" : {
        "x" : 305.4969708037313,
        "y" : 62.67730670424271
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36863",
        "shared_name" : "C15H15O7",
        "name" : "C15H15O7",
        "SUID" : 36863,
        "selected" : false
      },
      "position" : {
        "x" : 148.7652355742391,
        "y" : -1572.7969898655815
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36862",
        "shared_name" : "C16H15O9",
        "name" : "C16H15O9",
        "SUID" : 36862,
        "selected" : false
      },
      "position" : {
        "x" : 262.09879270314536,
        "y" : -1586.994621701519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36860",
        "shared_name" : "C17H11O10",
        "name" : "C17H11O10",
        "SUID" : 36860,
        "selected" : false
      },
      "position" : {
        "x" : -483.3308795380656,
        "y" : -1715.6592030003471
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36859",
        "shared_name" : "C17H13O11",
        "name" : "C17H13O11",
        "SUID" : 36859,
        "selected" : false
      },
      "position" : {
        "x" : -503.1133502411906,
        "y" : -1851.9478992894096
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36857",
        "shared_name" : "C14H7O6",
        "name" : "C14H7O6",
        "SUID" : 36857,
        "selected" : false
      },
      "position" : {
        "x" : -735.288750021464,
        "y" : 870.7933440730171
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36856",
        "shared_name" : "C14H9O7",
        "name" : "C14H9O7",
        "SUID" : 36856,
        "selected" : false
      },
      "position" : {
        "x" : -812.7627795624796,
        "y" : 796.7653232142525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36854",
        "shared_name" : "C17H13O7",
        "name" : "C17H13O7",
        "SUID" : 36854,
        "selected" : false
      },
      "position" : {
        "x" : 723.0955349516805,
        "y" : -1809.9616016819878
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36853",
        "shared_name" : "C18H13O9",
        "name" : "C18H13O9",
        "SUID" : 36853,
        "selected" : false
      },
      "position" : {
        "x" : 827.1294132780965,
        "y" : -1871.4973377659721
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36851",
        "shared_name" : "C14H9O8",
        "name" : "C14H9O8",
        "SUID" : 36851,
        "selected" : false
      },
      "position" : {
        "x" : 170.64964261769614,
        "y" : 68.83369403334427
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36850",
        "shared_name" : "C14H11O9",
        "name" : "C14H11O9",
        "SUID" : 36850,
        "selected" : false
      },
      "position" : {
        "x" : 14.897037179463723,
        "y" : 89.98474841566849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36848",
        "shared_name" : "C17H21O7",
        "name" : "C17H21O7",
        "SUID" : 36848,
        "selected" : false
      },
      "position" : {
        "x" : -998.4151118683878,
        "y" : 1979.0205607935982
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36847",
        "shared_name" : "C17H23O8",
        "name" : "C17H23O8",
        "SUID" : 36847,
        "selected" : false
      },
      "position" : {
        "x" : -900.0282901215617,
        "y" : 1941.2303691432076
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36845",
        "shared_name" : "C14H13O5",
        "name" : "C14H13O5",
        "SUID" : 36845,
        "selected" : false
      },
      "position" : {
        "x" : -804.2184985566203,
        "y" : -1833.9266285374565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36844",
        "shared_name" : "C14H15O6",
        "name" : "C14H15O6",
        "SUID" : 36844,
        "selected" : false
      },
      "position" : {
        "x" : -714.8542102265421,
        "y" : -1887.1988453343315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36842",
        "shared_name" : "C17H19O10",
        "name" : "C17H19O10",
        "SUID" : 36842,
        "selected" : false
      },
      "position" : {
        "x" : 387.9784618925985,
        "y" : -1572.8619312718315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36841",
        "shared_name" : "C18H19O12",
        "name" : "C18H19O12",
        "SUID" : 36841,
        "selected" : false
      },
      "position" : {
        "x" : 432.447578103536,
        "y" : -1486.3389210179253
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36839",
        "shared_name" : "C19H17O7",
        "name" : "C19H17O7",
        "SUID" : 36839,
        "selected" : false
      },
      "position" : {
        "x" : -708.7079928803507,
        "y" : 2306.025397829731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36838",
        "shared_name" : "C20H17O9",
        "name" : "C20H17O9",
        "SUID" : 36838,
        "selected" : false
      },
      "position" : {
        "x" : -603.7337497162882,
        "y" : 2286.032264284809
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36836",
        "shared_name" : "C16H17O6",
        "name" : "C16H17O6",
        "SUID" : 36836,
        "selected" : false
      },
      "position" : {
        "x" : -152.46135458231606,
        "y" : -249.90410656480026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36835",
        "shared_name" : "C16H19O7",
        "name" : "C16H19O7",
        "SUID" : 36835,
        "selected" : false
      },
      "position" : {
        "x" : -74.17284425974526,
        "y" : -336.4117359593315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36833",
        "shared_name" : "C14H15O7",
        "name" : "C14H15O7",
        "SUID" : 36833,
        "selected" : false
      },
      "position" : {
        "x" : -881.4847644257609,
        "y" : -708.1960529759331
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36832",
        "shared_name" : "C14H17O8",
        "name" : "C14H17O8",
        "SUID" : 36832,
        "selected" : false
      },
      "position" : {
        "x" : -985.3101428437296,
        "y" : -650.9718250706596
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36830",
        "shared_name" : "C18H17O6",
        "name" : "C18H17O6",
        "SUID" : 36830,
        "selected" : false
      },
      "position" : {
        "x" : 503.5346447539266,
        "y" : -1039.7257694676323
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36829",
        "shared_name" : "C19H17O8",
        "name" : "C19H17O8",
        "SUID" : 36829,
        "selected" : false
      },
      "position" : {
        "x" : 610.204902322286,
        "y" : -1005.9566730931206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36827",
        "shared_name" : "C16H21O6",
        "name" : "C16H21O6",
        "SUID" : 36827,
        "selected" : false
      },
      "position" : {
        "x" : 1107.5863720488485,
        "y" : -2534.309288449566
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36826",
        "shared_name" : "C16H23O7",
        "name" : "C16H23O7",
        "SUID" : 36826,
        "selected" : false
      },
      "position" : {
        "x" : 1199.5790783476766,
        "y" : -2504.9171680882378
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36824",
        "shared_name" : "C16H13O7",
        "name" : "C16H13O7",
        "SUID" : 36824,
        "selected" : false
      },
      "position" : {
        "x" : 61.7483135771688,
        "y" : -724.715813107769
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36823",
        "shared_name" : "C16H15O8",
        "name" : "C16H15O8",
        "SUID" : 36823,
        "selected" : false
      },
      "position" : {
        "x" : -84.5662387299601,
        "y" : -737.8336109593315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36821",
        "shared_name" : "C17H15O8",
        "name" : "C17H15O8",
        "SUID" : 36821,
        "selected" : false
      },
      "position" : {
        "x" : 621.8854137968954,
        "y" : -1726.1804432347221
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36820",
        "shared_name" : "C17H17O9",
        "name" : "C17H17O9",
        "SUID" : 36820,
        "selected" : false
      },
      "position" : {
        "x" : 499.9632336211141,
        "y" : -1622.4034962132378
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36818",
        "shared_name" : "C17H17O10",
        "name" : "C17H17O10",
        "SUID" : 36818,
        "selected" : false
      },
      "position" : {
        "x" : -325.2820704865519,
        "y" : -1839.595207639019
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36817",
        "shared_name" : "C17H19O11",
        "name" : "C17H19O11",
        "SUID" : 36817,
        "selected" : false
      },
      "position" : {
        "x" : -348.96938738108315,
        "y" : -1958.9773182347221
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36815",
        "shared_name" : "C14H9O6",
        "name" : "C14H9O6",
        "SUID" : 36815,
        "selected" : false
      },
      "position" : {
        "x" : -780.3000720429484,
        "y" : -2176.1935886814995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36814",
        "shared_name" : "C15H9O8",
        "name" : "C15H9O8",
        "SUID" : 36814,
        "selected" : false
      },
      "position" : {
        "x" : -855.1711047577921,
        "y" : -2137.185020871441
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36812",
        "shared_name" : "C18H19O7",
        "name" : "C18H19O7",
        "SUID" : 36812,
        "selected" : false
      },
      "position" : {
        "x" : 700.5440594267782,
        "y" : -1077.688225217144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36811",
        "shared_name" : "C19H19O9",
        "name" : "C19H19O9",
        "SUID" : 36811,
        "selected" : false
      },
      "position" : {
        "x" : 713.2998577666219,
        "y" : -968.96087307481
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "38216",
        "source" : "38214",
        "target" : "38215",
        "shared_name" : "C23H29O9 (interacts with) C23H27O8",
        "family_id" : 255,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C23H29O9 (interacts with) C23H27O8",
        "interaction" : "interacts with",
        "SUID" : 38216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38160",
        "source" : "38159",
        "target" : "38144",
        "shared_name" : "C15H15O10 (interacts with) C14H15O8",
        "family_id" : 27,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O10 (interacts with) C14H15O8",
        "interaction" : "interacts with",
        "SUID" : 38160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38147",
        "source" : "38146",
        "target" : "37429",
        "shared_name" : "C16H15O11 (interacts with) C16H13O10",
        "family_id" : 118,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H15O11 (interacts with) C16H13O10",
        "interaction" : "interacts with",
        "SUID" : 38147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38145",
        "source" : "38144",
        "target" : "37874",
        "shared_name" : "C14H15O8 (interacts with) C14H13O7",
        "family_id" : 27,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O8 (interacts with) C14H13O7",
        "interaction" : "interacts with",
        "SUID" : 38145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38175",
        "source" : "38140",
        "target" : "37199",
        "shared_name" : "C16H13O13 (interacts with) C15H13O11",
        "family_id" : 30,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O13 (interacts with) C15H13O11",
        "interaction" : "interacts with",
        "SUID" : 38175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38141",
        "source" : "38140",
        "target" : "37199",
        "shared_name" : "C16H13O13 (interacts with) C15H13O11",
        "family_id" : 267,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O13 (interacts with) C15H13O11",
        "interaction" : "interacts with",
        "SUID" : 38141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38139",
        "source" : "38137",
        "target" : "38138",
        "shared_name" : "C11H7O9 (interacts with) C10H7O7",
        "family_id" : 224,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C11H7O9 (interacts with) C10H7O7",
        "interaction" : "interacts with",
        "SUID" : 38139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38128",
        "source" : "38126",
        "target" : "38127",
        "shared_name" : "C13H9O8 (interacts with) C13H7O7",
        "family_id" : 176,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H9O8 (interacts with) C13H7O7",
        "interaction" : "interacts with",
        "SUID" : 38128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38142",
        "source" : "38121",
        "target" : "37233",
        "shared_name" : "C14H9O11 (interacts with) C13H9O9",
        "family_id" : 324,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H9O11 (interacts with) C13H9O9",
        "interaction" : "interacts with",
        "SUID" : 38142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38122",
        "source" : "38121",
        "target" : "37233",
        "shared_name" : "C14H9O11 (interacts with) C13H9O9",
        "family_id" : 105,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H9O11 (interacts with) C13H9O9",
        "interaction" : "interacts with",
        "SUID" : 38122,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38109",
        "source" : "38108",
        "target" : "37865",
        "shared_name" : "C11H9O8 (interacts with) C11H7O7",
        "family_id" : 95,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C11H9O8 (interacts with) C11H7O7",
        "interaction" : "interacts with",
        "SUID" : 38109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38103",
        "source" : "38102",
        "target" : "37702",
        "shared_name" : "C11H11O8 (interacts with) C11H9O7",
        "family_id" : 26,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C11H11O8 (interacts with) C11H9O7",
        "interaction" : "interacts with",
        "SUID" : 38103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38011",
        "source" : "38010",
        "target" : "37842",
        "shared_name" : "C19H9O12 (interacts with) C18H9O10",
        "family_id" : 280,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H9O12 (interacts with) C18H9O10",
        "interaction" : "interacts with",
        "SUID" : 38011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37984",
        "source" : "37983",
        "target" : "36897",
        "shared_name" : "C18H15O14 (interacts with) C17H15O12",
        "family_id" : 172,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H15O14 (interacts with) C17H15O12",
        "interaction" : "interacts with",
        "SUID" : 37984,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37970",
        "source" : "37969",
        "target" : "37338",
        "shared_name" : "C16H11O12 (interacts with) C15H11O10",
        "family_id" : 259,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O12 (interacts with) C15H11O10",
        "interaction" : "interacts with",
        "SUID" : 37970,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38036",
        "source" : "37951",
        "target" : "37416",
        "shared_name" : "C14H17O9 (interacts with) C13H17O7",
        "family_id" : 65,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H17O9 (interacts with) C13H17O7",
        "interaction" : "interacts with",
        "SUID" : 38036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37952",
        "source" : "37950",
        "target" : "37951",
        "shared_name" : "C15H17O11 (interacts with) C14H17O9",
        "family_id" : 65,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O11 (interacts with) C14H17O9",
        "interaction" : "interacts with",
        "SUID" : 37952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37912",
        "source" : "37911",
        "target" : "37211",
        "shared_name" : "C15H21O8 (interacts with) C15H19O7",
        "family_id" : 82,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O8 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 37912,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38025",
        "source" : "37895",
        "target" : "38024",
        "shared_name" : "C19H9O11 (interacts with) C18H9O9",
        "family_id" : 302,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H9O11 (interacts with) C18H9O9",
        "interaction" : "interacts with",
        "SUID" : 38025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38241",
        "source" : "37894",
        "target" : "37895",
        "shared_name" : "C20H9O13 (interacts with) C19H9O11",
        "family_id" : 302,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H9O13 (interacts with) C19H9O11",
        "interaction" : "interacts with",
        "SUID" : 38241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37896",
        "source" : "37894",
        "target" : "37895",
        "shared_name" : "C20H9O13 (interacts with) C19H9O11",
        "family_id" : 41,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H9O13 (interacts with) C19H9O11",
        "interaction" : "interacts with",
        "SUID" : 37896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37875",
        "source" : "37874",
        "target" : "37276",
        "shared_name" : "C14H13O7 (interacts with) C14H11O6",
        "family_id" : 234,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H13O7 (interacts with) C14H11O6",
        "interaction" : "interacts with",
        "SUID" : 37875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37863",
        "source" : "37862",
        "target" : "37280",
        "shared_name" : "C17H13O13 (interacts with) C16H13O11",
        "family_id" : 149,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O13 (interacts with) C16H13O11",
        "interaction" : "interacts with",
        "SUID" : 37863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38223",
        "source" : "37860",
        "target" : "38222",
        "shared_name" : "C17H7O10 (interacts with) C16H7O8",
        "family_id" : 51,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H7O10 (interacts with) C16H7O8",
        "interaction" : "interacts with",
        "SUID" : 38223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37861",
        "source" : "37859",
        "target" : "37860",
        "shared_name" : "C17H9O11 (interacts with) C17H7O10",
        "family_id" : 51,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H9O11 (interacts with) C17H7O10",
        "interaction" : "interacts with",
        "SUID" : 37861,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37852",
        "source" : "37851",
        "target" : "37831",
        "shared_name" : "C20H27O10 (interacts with) C20H25O9",
        "family_id" : 45,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H27O10 (interacts with) C20H25O9",
        "interaction" : "interacts with",
        "SUID" : 37852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37844",
        "source" : "37842",
        "target" : "37843",
        "shared_name" : "C18H9O10 (interacts with) C17H9O8",
        "family_id" : 280,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H9O10 (interacts with) C17H9O8",
        "interaction" : "interacts with",
        "SUID" : 37844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37899",
        "source" : "37835",
        "target" : "36901",
        "shared_name" : "C16H7O10 (interacts with) C15H7O8",
        "family_id" : 225,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H7O10 (interacts with) C15H7O8",
        "interaction" : "interacts with",
        "SUID" : 37899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37833",
        "source" : "37831",
        "target" : "37832",
        "shared_name" : "C20H25O9 (interacts with) C19H25O7",
        "family_id" : 45,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O9 (interacts with) C19H25O7",
        "interaction" : "interacts with",
        "SUID" : 37833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37854",
        "source" : "37822",
        "target" : "36838",
        "shared_name" : "C21H17O11 (interacts with) C20H17O9",
        "family_id" : 89,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H17O11 (interacts with) C20H17O9",
        "interaction" : "interacts with",
        "SUID" : 37854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38155",
        "source" : "37791",
        "target" : "37070",
        "shared_name" : "C13H17O9 (interacts with) C12H17O7",
        "family_id" : 1,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H17O9 (interacts with) C12H17O7",
        "interaction" : "interacts with",
        "SUID" : 38155,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38153",
        "source" : "37791",
        "target" : "37379",
        "shared_name" : "C13H17O9 (interacts with) C13H15O8",
        "family_id" : 90,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H17O9 (interacts with) C13H15O8",
        "interaction" : "interacts with",
        "SUID" : 38153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38067",
        "source" : "37791",
        "target" : "37070",
        "shared_name" : "C13H17O9 (interacts with) C12H17O7",
        "family_id" : 329,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H17O9 (interacts with) C12H17O7",
        "interaction" : "interacts with",
        "SUID" : 38067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37879",
        "source" : "37791",
        "target" : "37379",
        "shared_name" : "C13H17O9 (interacts with) C13H15O8",
        "family_id" : 25,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H17O9 (interacts with) C13H15O8",
        "interaction" : "interacts with",
        "SUID" : 37879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37792",
        "source" : "37791",
        "target" : "37070",
        "shared_name" : "C13H17O9 (interacts with) C12H17O7",
        "family_id" : 123,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H17O9 (interacts with) C12H17O7",
        "interaction" : "interacts with",
        "SUID" : 37792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37772",
        "source" : "37771",
        "target" : "36886",
        "shared_name" : "C16H21O7 (interacts with) C16H19O6",
        "family_id" : 241,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O7 (interacts with) C16H19O6",
        "interaction" : "interacts with",
        "SUID" : 37772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38230",
        "source" : "37766",
        "target" : "38229",
        "shared_name" : "C19H11O11 (interacts with) C18H11O9",
        "family_id" : 112,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H11O11 (interacts with) C18H11O9",
        "interaction" : "interacts with",
        "SUID" : 38230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38034",
        "source" : "37765",
        "target" : "37766",
        "shared_name" : "C19H13O12 (interacts with) C19H11O11",
        "family_id" : 279,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H13O12 (interacts with) C19H11O11",
        "interaction" : "interacts with",
        "SUID" : 38034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37767",
        "source" : "37765",
        "target" : "37766",
        "shared_name" : "C19H13O12 (interacts with) C19H11O11",
        "family_id" : 112,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H13O12 (interacts with) C19H11O11",
        "interaction" : "interacts with",
        "SUID" : 37767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38029",
        "source" : "37758",
        "target" : "37517",
        "shared_name" : "C17H19O12 (interacts with) C16H19O10",
        "family_id" : 133,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O12 (interacts with) C16H19O10",
        "interaction" : "interacts with",
        "SUID" : 38029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37759",
        "source" : "37758",
        "target" : "36942",
        "shared_name" : "C17H19O12 (interacts with) C17H17O11",
        "family_id" : 264,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O12 (interacts with) C17H17O11",
        "interaction" : "interacts with",
        "SUID" : 37759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37986",
        "source" : "37756",
        "target" : "37096",
        "shared_name" : "C15H19O10 (interacts with) C15H17O9",
        "family_id" : 63,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O10 (interacts with) C15H17O9",
        "interaction" : "interacts with",
        "SUID" : 37986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37757",
        "source" : "37756",
        "target" : "37096",
        "shared_name" : "C15H19O10 (interacts with) C15H17O9",
        "family_id" : 253,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O10 (interacts with) C15H17O9",
        "interaction" : "interacts with",
        "SUID" : 37757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37752",
        "source" : "37751",
        "target" : "37155",
        "shared_name" : "C13H9O10 (interacts with) C12H9O8",
        "family_id" : 79,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H9O10 (interacts with) C12H9O8",
        "interaction" : "interacts with",
        "SUID" : 37752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37740",
        "source" : "37738",
        "target" : "37739",
        "shared_name" : "C20H13O11 (interacts with) C20H11O10",
        "family_id" : 104,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H13O11 (interacts with) C20H11O10",
        "interaction" : "interacts with",
        "SUID" : 37740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38099",
        "source" : "37722",
        "target" : "37180",
        "shared_name" : "C19H17O12 (interacts with) C18H17O10",
        "family_id" : 152,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H17O12 (interacts with) C18H17O10",
        "interaction" : "interacts with",
        "SUID" : 38099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37723",
        "source" : "37722",
        "target" : "37180",
        "shared_name" : "C19H17O12 (interacts with) C18H17O10",
        "family_id" : 317,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H17O12 (interacts with) C18H17O10",
        "interaction" : "interacts with",
        "SUID" : 37723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37866",
        "source" : "37681",
        "target" : "37865",
        "shared_name" : "C12H7O9 (interacts with) C11H7O7",
        "family_id" : 188,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H7O9 (interacts with) C11H7O7",
        "interaction" : "interacts with",
        "SUID" : 37866,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37682",
        "source" : "37680",
        "target" : "37681",
        "shared_name" : "C13H7O11 (interacts with) C12H7O9",
        "family_id" : 188,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H7O11 (interacts with) C12H7O9",
        "interaction" : "interacts with",
        "SUID" : 37682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37877",
        "source" : "37678",
        "target" : "37192",
        "shared_name" : "C15H21O7 (interacts with) C15H19O6",
        "family_id" : 15,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O7 (interacts with) C15H19O6",
        "interaction" : "interacts with",
        "SUID" : 37877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38237",
        "source" : "37677",
        "target" : "37110",
        "shared_name" : "C16H21O9 (interacts with) C16H19O8",
        "family_id" : 68,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O9 (interacts with) C16H19O8",
        "interaction" : "interacts with",
        "SUID" : 38237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37939",
        "source" : "37677",
        "target" : "37110",
        "shared_name" : "C16H21O9 (interacts with) C16H19O8",
        "family_id" : 301,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O9 (interacts with) C16H19O8",
        "interaction" : "interacts with",
        "SUID" : 37939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37679",
        "source" : "37677",
        "target" : "37678",
        "shared_name" : "C16H21O9 (interacts with) C15H21O7",
        "family_id" : 15,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O9 (interacts with) C15H21O7",
        "interaction" : "interacts with",
        "SUID" : 37679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38233",
        "source" : "37663",
        "target" : "36965",
        "shared_name" : "C14H15O9 (interacts with) C14H13O8",
        "family_id" : 229,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O9 (interacts with) C14H13O8",
        "interaction" : "interacts with",
        "SUID" : 38233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38143",
        "source" : "37663",
        "target" : "36965",
        "shared_name" : "C14H15O9 (interacts with) C14H13O8",
        "family_id" : 339,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O9 (interacts with) C14H13O8",
        "interaction" : "interacts with",
        "SUID" : 38143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37728",
        "source" : "37663",
        "target" : "36907",
        "shared_name" : "C14H15O9 (interacts with) C13H15O7",
        "family_id" : 212,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H15O9 (interacts with) C13H15O7",
        "interaction" : "interacts with",
        "SUID" : 37728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37664",
        "source" : "37663",
        "target" : "36907",
        "shared_name" : "C14H15O9 (interacts with) C13H15O7",
        "family_id" : 156,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H15O9 (interacts with) C13H15O7",
        "interaction" : "interacts with",
        "SUID" : 37664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37889",
        "source" : "37659",
        "target" : "37888",
        "shared_name" : "C12H17O8 (interacts with) C11H17O6",
        "family_id" : 270,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H17O8 (interacts with) C11H17O6",
        "interaction" : "interacts with",
        "SUID" : 37889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37837",
        "source" : "37659",
        "target" : "37639",
        "shared_name" : "C12H17O8 (interacts with) C12H15O7",
        "family_id" : 222,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H17O8 (interacts with) C12H15O7",
        "interaction" : "interacts with",
        "SUID" : 37837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37660",
        "source" : "37659",
        "target" : "37639",
        "shared_name" : "C12H17O8 (interacts with) C12H15O7",
        "family_id" : 293,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H17O8 (interacts with) C12H15O7",
        "interaction" : "interacts with",
        "SUID" : 37660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37658",
        "source" : "37657",
        "target" : "37613",
        "shared_name" : "C18H15O13 (interacts with) C17H15O11",
        "family_id" : 164,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H15O13 (interacts with) C17H15O11",
        "interaction" : "interacts with",
        "SUID" : 37658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37656",
        "source" : "37655",
        "target" : "36848",
        "shared_name" : "C18H21O9 (interacts with) C17H21O7",
        "family_id" : 21,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O9 (interacts with) C17H21O7",
        "interaction" : "interacts with",
        "SUID" : 37656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37653",
        "source" : "37651",
        "target" : "36956",
        "shared_name" : "C17H21O10 (interacts with) C16H21O8",
        "family_id" : 119,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H21O10 (interacts with) C16H21O8",
        "interaction" : "interacts with",
        "SUID" : 37653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37755",
        "source" : "37639",
        "target" : "37403",
        "shared_name" : "C12H15O7 (interacts with) C12H13O6",
        "family_id" : 7,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H15O7 (interacts with) C12H13O6",
        "interaction" : "interacts with",
        "SUID" : 37755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37640",
        "source" : "37639",
        "target" : "37403",
        "shared_name" : "C12H15O7 (interacts with) C12H13O6",
        "family_id" : 222,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H15O7 (interacts with) C12H13O6",
        "interaction" : "interacts with",
        "SUID" : 37640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37624",
        "source" : "37623",
        "target" : "37613",
        "shared_name" : "C17H17O12 (interacts with) C17H15O11",
        "family_id" : 158,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H17O12 (interacts with) C17H15O11",
        "interaction" : "interacts with",
        "SUID" : 37624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38100",
        "source" : "37614",
        "target" : "37351",
        "shared_name" : "C17H13O10 (interacts with) C16H13O8",
        "family_id" : 164,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O10 (interacts with) C16H13O8",
        "interaction" : "interacts with",
        "SUID" : 38100,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37642",
        "source" : "37614",
        "target" : "37351",
        "shared_name" : "C17H13O10 (interacts with) C16H13O8",
        "family_id" : 158,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O10 (interacts with) C16H13O8",
        "interaction" : "interacts with",
        "SUID" : 37642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38059",
        "source" : "37613",
        "target" : "37614",
        "shared_name" : "C17H15O11 (interacts with) C17H13O10",
        "family_id" : 158,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O11 (interacts with) C17H13O10",
        "interaction" : "interacts with",
        "SUID" : 38059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37615",
        "source" : "37613",
        "target" : "37614",
        "shared_name" : "C17H15O11 (interacts with) C17H13O10",
        "family_id" : 164,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O11 (interacts with) C17H13O10",
        "interaction" : "interacts with",
        "SUID" : 37615,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37703",
        "source" : "37595",
        "target" : "37702",
        "shared_name" : "C12H9O9 (interacts with) C11H9O7",
        "family_id" : 155,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H9O9 (interacts with) C11H9O7",
        "interaction" : "interacts with",
        "SUID" : 37703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37596",
        "source" : "37595",
        "target" : "36954",
        "shared_name" : "C12H9O9 (interacts with) C12H7O8",
        "family_id" : 9,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H9O9 (interacts with) C12H7O8",
        "interaction" : "interacts with",
        "SUID" : 37596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38046",
        "source" : "37593",
        "target" : "37677",
        "shared_name" : "C17H21O11 (interacts with) C16H21O9",
        "family_id" : 301,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H21O11 (interacts with) C16H21O9",
        "interaction" : "interacts with",
        "SUID" : 38046,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37864",
        "source" : "37593",
        "target" : "37677",
        "shared_name" : "C17H21O11 (interacts with) C16H21O9",
        "family_id" : 15,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H21O11 (interacts with) C16H21O9",
        "interaction" : "interacts with",
        "SUID" : 37864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37594",
        "source" : "37593",
        "target" : "36842",
        "shared_name" : "C17H21O11 (interacts with) C17H19O10",
        "family_id" : 107,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O11 (interacts with) C17H19O10",
        "interaction" : "interacts with",
        "SUID" : 37594,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38054",
        "source" : "37586",
        "target" : "37663",
        "shared_name" : "C15H15O11 (interacts with) C14H15O9",
        "family_id" : 156,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O11 (interacts with) C14H15O9",
        "interaction" : "interacts with",
        "SUID" : 38054,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37901",
        "source" : "37586",
        "target" : "37663",
        "shared_name" : "C15H15O11 (interacts with) C14H15O9",
        "family_id" : 229,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O11 (interacts with) C14H15O9",
        "interaction" : "interacts with",
        "SUID" : 37901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37878",
        "source" : "37586",
        "target" : "37663",
        "shared_name" : "C15H15O11 (interacts with) C14H15O9",
        "family_id" : 339,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O11 (interacts with) C14H15O9",
        "interaction" : "interacts with",
        "SUID" : 37878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37698",
        "source" : "37586",
        "target" : "37663",
        "shared_name" : "C15H15O11 (interacts with) C14H15O9",
        "family_id" : 330,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O11 (interacts with) C14H15O9",
        "interaction" : "interacts with",
        "SUID" : 37698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37621",
        "source" : "37586",
        "target" : "37043",
        "shared_name" : "C15H15O11 (interacts with) C15H13O10",
        "family_id" : 110,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H15O11 (interacts with) C15H13O10",
        "interaction" : "interacts with",
        "SUID" : 37621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38056",
        "source" : "37585",
        "target" : "37586",
        "shared_name" : "C15H17O12 (interacts with) C15H15O11",
        "family_id" : 235,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O12 (interacts with) C15H15O11",
        "interaction" : "interacts with",
        "SUID" : 38056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37793",
        "source" : "37585",
        "target" : "37586",
        "shared_name" : "C15H17O12 (interacts with) C15H15O11",
        "family_id" : 330,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O12 (interacts with) C15H15O11",
        "interaction" : "interacts with",
        "SUID" : 37793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37587",
        "source" : "37585",
        "target" : "37586",
        "shared_name" : "C15H17O12 (interacts with) C15H15O11",
        "family_id" : 339,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O12 (interacts with) C15H15O11",
        "interaction" : "interacts with",
        "SUID" : 37587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37573",
        "source" : "37571",
        "target" : "37572",
        "shared_name" : "C11H15O8 (interacts with) C11H13O7",
        "family_id" : 11,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C11H15O8 (interacts with) C11H13O7",
        "interaction" : "interacts with",
        "SUID" : 37573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37900",
        "source" : "37566",
        "target" : "36944",
        "shared_name" : "C15H13O9 (interacts with) C15H11O8",
        "family_id" : 183,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H13O9 (interacts with) C15H11O8",
        "interaction" : "interacts with",
        "SUID" : 37900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37829",
        "source" : "37556",
        "target" : "36945",
        "shared_name" : "C16H9O9 (interacts with) C15H9O7",
        "family_id" : 154,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O9 (interacts with) C15H9O7",
        "interaction" : "interacts with",
        "SUID" : 37829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38000",
        "source" : "37531",
        "target" : "37655",
        "shared_name" : "C18H23O10 (interacts with) C18H21O9",
        "family_id" : 21,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O10 (interacts with) C18H21O9",
        "interaction" : "interacts with",
        "SUID" : 38000,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37920",
        "source" : "37531",
        "target" : "36847",
        "shared_name" : "C18H23O10 (interacts with) C17H23O8",
        "family_id" : 161,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O10 (interacts with) C17H23O8",
        "interaction" : "interacts with",
        "SUID" : 37920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37915",
        "source" : "37531",
        "target" : "36847",
        "shared_name" : "C18H23O10 (interacts with) C17H23O8",
        "family_id" : 167,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O10 (interacts with) C17H23O8",
        "interaction" : "interacts with",
        "SUID" : 37915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37782",
        "source" : "37531",
        "target" : "36847",
        "shared_name" : "C18H23O10 (interacts with) C17H23O8",
        "family_id" : 114,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O10 (interacts with) C17H23O8",
        "interaction" : "interacts with",
        "SUID" : 37782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37605",
        "source" : "37531",
        "target" : "36847",
        "shared_name" : "C18H23O10 (interacts with) C17H23O8",
        "family_id" : 3,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O10 (interacts with) C17H23O8",
        "interaction" : "interacts with",
        "SUID" : 37605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38156",
        "source" : "37530",
        "target" : "37531",
        "shared_name" : "C19H23O12 (interacts with) C18H23O10",
        "family_id" : 3,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O12 (interacts with) C18H23O10",
        "interaction" : "interacts with",
        "SUID" : 38156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38136",
        "source" : "37530",
        "target" : "37531",
        "shared_name" : "C19H23O12 (interacts with) C18H23O10",
        "family_id" : 21,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O12 (interacts with) C18H23O10",
        "interaction" : "interacts with",
        "SUID" : 38136,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37575",
        "source" : "37530",
        "target" : "37531",
        "shared_name" : "C19H23O12 (interacts with) C18H23O10",
        "family_id" : 161,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O12 (interacts with) C18H23O10",
        "interaction" : "interacts with",
        "SUID" : 37575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37532",
        "source" : "37530",
        "target" : "37531",
        "shared_name" : "C19H23O12 (interacts with) C18H23O10",
        "family_id" : 114,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O12 (interacts with) C18H23O10",
        "interaction" : "interacts with",
        "SUID" : 37532,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37549",
        "source" : "37523",
        "target" : "36962",
        "shared_name" : "C19H15O12 (interacts with) C18H15O10",
        "family_id" : 18,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H15O12 (interacts with) C18H15O10",
        "interaction" : "interacts with",
        "SUID" : 37549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37524",
        "source" : "37523",
        "target" : "37496",
        "shared_name" : "C19H15O12 (interacts with) C19H13O11",
        "family_id" : 331,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H15O12 (interacts with) C19H13O11",
        "interaction" : "interacts with",
        "SUID" : 37524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37919",
        "source" : "37517",
        "target" : "36909",
        "shared_name" : "C16H19O10 (interacts with) C15H19O8",
        "family_id" : 133,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O10 (interacts with) C15H19O8",
        "interaction" : "interacts with",
        "SUID" : 37919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37891",
        "source" : "37517",
        "target" : "36909",
        "shared_name" : "C16H19O10 (interacts with) C15H19O8",
        "family_id" : 189,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O10 (interacts with) C15H19O8",
        "interaction" : "interacts with",
        "SUID" : 37891,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37847",
        "source" : "37517",
        "target" : "36909",
        "shared_name" : "C16H19O10 (interacts with) C15H19O8",
        "family_id" : 195,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O10 (interacts with) C15H19O8",
        "interaction" : "interacts with",
        "SUID" : 37847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37511",
        "source" : "37510",
        "target" : "36832",
        "shared_name" : "C14H19O9 (interacts with) C14H17O8",
        "family_id" : 175,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H19O9 (interacts with) C14H17O8",
        "interaction" : "interacts with",
        "SUID" : 37511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38078",
        "source" : "37503",
        "target" : "38077",
        "shared_name" : "C18H15O9 (interacts with) C17H15O7",
        "family_id" : 168,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H15O9 (interacts with) C17H15O7",
        "interaction" : "interacts with",
        "SUID" : 38078,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37497",
        "source" : "37496",
        "target" : "36853",
        "shared_name" : "C19H13O11 (interacts with) C18H13O9",
        "family_id" : 331,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H13O11 (interacts with) C18H13O9",
        "interaction" : "interacts with",
        "SUID" : 37497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38005",
        "source" : "37483",
        "target" : "37409",
        "shared_name" : "C18H11O13 (interacts with) C17H11O11",
        "family_id" : 307,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H11O13 (interacts with) C17H11O11",
        "interaction" : "interacts with",
        "SUID" : 38005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37551",
        "source" : "37483",
        "target" : "37409",
        "shared_name" : "C18H11O13 (interacts with) C17H11O11",
        "family_id" : 341,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H11O13 (interacts with) C17H11O11",
        "interaction" : "interacts with",
        "SUID" : 37551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37484",
        "source" : "37483",
        "target" : "37409",
        "shared_name" : "C18H11O13 (interacts with) C17H11O11",
        "family_id" : 207,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H11O13 (interacts with) C17H11O11",
        "interaction" : "interacts with",
        "SUID" : 37484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37959",
        "source" : "37469",
        "target" : "37572",
        "shared_name" : "C12H13O9 (interacts with) C11H13O7",
        "family_id" : 273,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H13O9 (interacts with) C11H13O7",
        "interaction" : "interacts with",
        "SUID" : 37959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37795",
        "source" : "37469",
        "target" : "36929",
        "shared_name" : "C12H13O9 (interacts with) C12H11O8",
        "family_id" : 101,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H13O9 (interacts with) C12H11O8",
        "interaction" : "interacts with",
        "SUID" : 37795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37470",
        "source" : "37469",
        "target" : "36929",
        "shared_name" : "C12H13O9 (interacts with) C12H11O8",
        "family_id" : 196,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H13O9 (interacts with) C12H11O8",
        "interaction" : "interacts with",
        "SUID" : 37470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37529",
        "source" : "37463",
        "target" : "36865",
        "shared_name" : "C15H7O9 (interacts with) C14H7O7",
        "family_id" : 19,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H7O9 (interacts with) C14H7O7",
        "interaction" : "interacts with",
        "SUID" : 37529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37760",
        "source" : "37446",
        "target" : "36856",
        "shared_name" : "C14H11O8 (interacts with) C14H9O7",
        "family_id" : 30,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H11O8 (interacts with) C14H9O7",
        "interaction" : "interacts with",
        "SUID" : 37760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37707",
        "source" : "37446",
        "target" : "36856",
        "shared_name" : "C14H11O8 (interacts with) C14H9O7",
        "family_id" : 259,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H11O8 (interacts with) C14H9O7",
        "interaction" : "interacts with",
        "SUID" : 37707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37435",
        "source" : "37434",
        "target" : "37076",
        "shared_name" : "C19H17O11 (interacts with) C18H17O9",
        "family_id" : 283,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H17O11 (interacts with) C18H17O9",
        "interaction" : "interacts with",
        "SUID" : 37435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37547",
        "source" : "37429",
        "target" : "37392",
        "shared_name" : "C16H13O10 (interacts with) C15H13O8",
        "family_id" : 118,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O10 (interacts with) C15H13O8",
        "interaction" : "interacts with",
        "SUID" : 37547,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37430",
        "source" : "37429",
        "target" : "37184",
        "shared_name" : "C16H13O10 (interacts with) C16H11O9",
        "family_id" : 228,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H13O10 (interacts with) C16H11O9",
        "interaction" : "interacts with",
        "SUID" : 37430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37763",
        "source" : "37416",
        "target" : "37695",
        "shared_name" : "C13H17O7 (interacts with) C13H15O6",
        "family_id" : 204,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H17O7 (interacts with) C13H15O6",
        "interaction" : "interacts with",
        "SUID" : 37763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37696",
        "source" : "37416",
        "target" : "37695",
        "shared_name" : "C13H17O7 (interacts with) C13H15O6",
        "family_id" : 65,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H17O7 (interacts with) C13H15O6",
        "interaction" : "interacts with",
        "SUID" : 37696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37806",
        "source" : "37415",
        "target" : "37805",
        "shared_name" : "C13H19O8 (interacts with) C12H19O6",
        "family_id" : 209,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H19O8 (interacts with) C12H19O6",
        "interaction" : "interacts with",
        "SUID" : 37806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37417",
        "source" : "37415",
        "target" : "37416",
        "shared_name" : "C13H19O8 (interacts with) C13H17O7",
        "family_id" : 204,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H19O8 (interacts with) C13H17O7",
        "interaction" : "interacts with",
        "SUID" : 37417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38243",
        "source" : "37409",
        "target" : "37184",
        "shared_name" : "C17H11O11 (interacts with) C16H11O9",
        "family_id" : 207,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O11 (interacts with) C16H11O9",
        "interaction" : "interacts with",
        "SUID" : 38243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38195",
        "source" : "37409",
        "target" : "37184",
        "shared_name" : "C17H11O11 (interacts with) C16H11O9",
        "family_id" : 88,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O11 (interacts with) C16H11O9",
        "interaction" : "interacts with",
        "SUID" : 38195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38027",
        "source" : "37409",
        "target" : "37184",
        "shared_name" : "C17H11O11 (interacts with) C16H11O9",
        "family_id" : 326,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O11 (interacts with) C16H11O9",
        "interaction" : "interacts with",
        "SUID" : 38027,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37460",
        "source" : "37409",
        "target" : "37184",
        "shared_name" : "C17H11O11 (interacts with) C16H11O9",
        "family_id" : 187,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O11 (interacts with) C16H11O9",
        "interaction" : "interacts with",
        "SUID" : 37460,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37439",
        "source" : "37409",
        "target" : "37184",
        "shared_name" : "C17H11O11 (interacts with) C16H11O9",
        "family_id" : 307,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O11 (interacts with) C16H11O9",
        "interaction" : "interacts with",
        "SUID" : 37439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37410",
        "source" : "37409",
        "target" : "37184",
        "shared_name" : "C17H11O11 (interacts with) C16H11O9",
        "family_id" : 341,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O11 (interacts with) C16H11O9",
        "interaction" : "interacts with",
        "SUID" : 37410,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37574",
        "source" : "37407",
        "target" : "36932",
        "shared_name" : "C18H13O11 (interacts with) C17H9O10",
        "family_id" : 24,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H13O11 (interacts with) C17H9O10",
        "interaction" : "interacts with",
        "SUID" : 37574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37500",
        "source" : "37407",
        "target" : "36932",
        "shared_name" : "C18H13O11 (interacts with) C17H9O10",
        "family_id" : 34,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H13O11 (interacts with) C17H9O10",
        "interaction" : "interacts with",
        "SUID" : 37500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37408",
        "source" : "37407",
        "target" : "36932",
        "shared_name" : "C18H13O11 (interacts with) C17H9O10",
        "family_id" : 71,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H13O11 (interacts with) C17H9O10",
        "interaction" : "interacts with",
        "SUID" : 37408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37898",
        "source" : "37398",
        "target" : "37562",
        "shared_name" : "C12H11O9 (interacts with) C11H11O7",
        "family_id" : 126,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H11O9 (interacts with) C11H11O7",
        "interaction" : "interacts with",
        "SUID" : 37898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37399",
        "source" : "37398",
        "target" : "37155",
        "shared_name" : "C12H11O9 (interacts with) C12H9O8",
        "family_id" : 177,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H11O9 (interacts with) C12H9O8",
        "interaction" : "interacts with",
        "SUID" : 37399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38043",
        "source" : "37392",
        "target" : "37249",
        "shared_name" : "C15H13O8 (interacts with) C15H11O7",
        "family_id" : 118,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H13O8 (interacts with) C15H11O7",
        "interaction" : "interacts with",
        "SUID" : 38043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37394",
        "source" : "37392",
        "target" : "37393",
        "shared_name" : "C15H13O8 (interacts with) C14H13O6",
        "family_id" : 28,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H13O8 (interacts with) C14H13O6",
        "interaction" : "interacts with",
        "SUID" : 37394,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37390",
        "source" : "37389",
        "target" : "37274",
        "shared_name" : "C13H13O10 (interacts with) C12H13O8",
        "family_id" : 322,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H13O10 (interacts with) C12H13O8",
        "interaction" : "interacts with",
        "SUID" : 37390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38198",
        "source" : "37387",
        "target" : "36889",
        "shared_name" : "C18H23O9 (interacts with) C18H21O8",
        "family_id" : 17,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O9 (interacts with) C18H21O8",
        "interaction" : "interacts with",
        "SUID" : 38198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37509",
        "source" : "37387",
        "target" : "36889",
        "shared_name" : "C18H23O9 (interacts with) C18H21O8",
        "family_id" : 206,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O9 (interacts with) C18H21O8",
        "interaction" : "interacts with",
        "SUID" : 37509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37388",
        "source" : "37387",
        "target" : "36889",
        "shared_name" : "C18H23O9 (interacts with) C18H21O8",
        "family_id" : 320,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O9 (interacts with) C18H21O8",
        "interaction" : "interacts with",
        "SUID" : 37388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37802",
        "source" : "37384",
        "target" : "37270",
        "shared_name" : "C13H17O10 (interacts with) C13H15O9",
        "family_id" : 140,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H17O10 (interacts with) C13H15O9",
        "interaction" : "interacts with",
        "SUID" : 37802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37461",
        "source" : "37384",
        "target" : "37270",
        "shared_name" : "C13H17O10 (interacts with) C13H15O9",
        "family_id" : 238,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H17O10 (interacts with) C13H15O9",
        "interaction" : "interacts with",
        "SUID" : 37461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37385",
        "source" : "37384",
        "target" : "37270",
        "shared_name" : "C13H17O10 (interacts with) C13H15O9",
        "family_id" : 272,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H17O10 (interacts with) C13H15O9",
        "interaction" : "interacts with",
        "SUID" : 37385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38200",
        "source" : "37379",
        "target" : "36914",
        "shared_name" : "C13H15O8 (interacts with) C13H13O7",
        "family_id" : 295,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H15O8 (interacts with) C13H13O7",
        "interaction" : "interacts with",
        "SUID" : 38200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37846",
        "source" : "37379",
        "target" : "36914",
        "shared_name" : "C13H15O8 (interacts with) C13H13O7",
        "family_id" : 90,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H15O8 (interacts with) C13H13O7",
        "interaction" : "interacts with",
        "SUID" : 37846,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37744",
        "source" : "37379",
        "target" : "37071",
        "shared_name" : "C13H15O8 (interacts with) C12H15O6",
        "family_id" : 87,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H15O8 (interacts with) C12H15O6",
        "interaction" : "interacts with",
        "SUID" : 37744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37380",
        "source" : "37379",
        "target" : "37071",
        "shared_name" : "C13H15O8 (interacts with) C12H15O6",
        "family_id" : 25,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H15O8 (interacts with) C12H15O6",
        "interaction" : "interacts with",
        "SUID" : 37380,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37672",
        "source" : "37373",
        "target" : "37329",
        "shared_name" : "C14H7O10 (interacts with) C13H7O8",
        "family_id" : 185,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H7O10 (interacts with) C13H7O8",
        "interaction" : "interacts with",
        "SUID" : 37672,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37374",
        "source" : "37373",
        "target" : "37329",
        "shared_name" : "C14H7O10 (interacts with) C13H7O8",
        "family_id" : 315,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H7O10 (interacts with) C13H7O8",
        "interaction" : "interacts with",
        "SUID" : 37374,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38219",
        "source" : "37370",
        "target" : "37663",
        "shared_name" : "C14H17O10 (interacts with) C14H15O9",
        "family_id" : 212,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H17O10 (interacts with) C14H15O9",
        "interaction" : "interacts with",
        "SUID" : 38219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37669",
        "source" : "37370",
        "target" : "36906",
        "shared_name" : "C14H17O10 (interacts with) C13H17O8",
        "family_id" : 251,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H17O10 (interacts with) C13H17O8",
        "interaction" : "interacts with",
        "SUID" : 37669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37371",
        "source" : "37370",
        "target" : "36906",
        "shared_name" : "C14H17O10 (interacts with) C13H17O8",
        "family_id" : 300,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H17O10 (interacts with) C13H17O8",
        "interaction" : "interacts with",
        "SUID" : 37371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38083",
        "source" : "37363",
        "target" : "36994",
        "shared_name" : "C19H21O9 (interacts with) C18H21O7",
        "family_id" : 266,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O9 (interacts with) C18H21O7",
        "interaction" : "interacts with",
        "SUID" : 38083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37628",
        "source" : "37363",
        "target" : "36994",
        "shared_name" : "C19H21O9 (interacts with) C18H21O7",
        "family_id" : 245,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O9 (interacts with) C18H21O7",
        "interaction" : "interacts with",
        "SUID" : 37628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37519",
        "source" : "37363",
        "target" : "37078",
        "shared_name" : "C19H21O9 (interacts with) C19H19O8",
        "family_id" : 16,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O9 (interacts with) C19H19O8",
        "interaction" : "interacts with",
        "SUID" : 37519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37364",
        "source" : "37363",
        "target" : "37078",
        "shared_name" : "C19H21O9 (interacts with) C19H19O8",
        "family_id" : 128,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O9 (interacts with) C19H19O8",
        "interaction" : "interacts with",
        "SUID" : 37364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37994",
        "source" : "37355",
        "target" : "37122",
        "shared_name" : "C19H25O12 (interacts with) C19H23O11",
        "family_id" : 181,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O12 (interacts with) C19H23O11",
        "interaction" : "interacts with",
        "SUID" : 37994,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37928",
        "source" : "37355",
        "target" : "37122",
        "shared_name" : "C19H25O12 (interacts with) C19H23O11",
        "family_id" : 334,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O12 (interacts with) C19H23O11",
        "interaction" : "interacts with",
        "SUID" : 37928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37714",
        "source" : "37355",
        "target" : "37122",
        "shared_name" : "C19H25O12 (interacts with) C19H23O11",
        "family_id" : 124,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O12 (interacts with) C19H23O11",
        "interaction" : "interacts with",
        "SUID" : 37714,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37479",
        "source" : "37355",
        "target" : "37122",
        "shared_name" : "C19H25O12 (interacts with) C19H23O11",
        "family_id" : 304,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O12 (interacts with) C19H23O11",
        "interaction" : "interacts with",
        "SUID" : 37479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37406",
        "source" : "37355",
        "target" : "37122",
        "shared_name" : "C19H25O12 (interacts with) C19H23O11",
        "family_id" : 17,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O12 (interacts with) C19H23O11",
        "interaction" : "interacts with",
        "SUID" : 37406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37356",
        "source" : "37355",
        "target" : "37122",
        "shared_name" : "C19H25O12 (interacts with) C19H23O11",
        "family_id" : 206,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O12 (interacts with) C19H23O11",
        "interaction" : "interacts with",
        "SUID" : 37356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37821",
        "source" : "37351",
        "target" : "36998",
        "shared_name" : "C16H13O8 (interacts with) C16H11O7",
        "family_id" : 164,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H13O8 (interacts with) C16H11O7",
        "interaction" : "interacts with",
        "SUID" : 37821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37352",
        "source" : "37351",
        "target" : "36998",
        "shared_name" : "C16H13O8 (interacts with) C16H11O7",
        "family_id" : 158,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H13O8 (interacts with) C16H11O7",
        "interaction" : "interacts with",
        "SUID" : 37352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38095",
        "source" : "37349",
        "target" : "36817",
        "shared_name" : "C18H19O13 (interacts with) C17H19O11",
        "family_id" : 165,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O13 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 38095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37705",
        "source" : "37349",
        "target" : "36817",
        "shared_name" : "C18H19O13 (interacts with) C17H19O11",
        "family_id" : 291,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O13 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37559",
        "source" : "37349",
        "target" : "36817",
        "shared_name" : "C18H19O13 (interacts with) C17H19O11",
        "family_id" : 49,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O13 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37350",
        "source" : "37349",
        "target" : "36817",
        "shared_name" : "C18H19O13 (interacts with) C17H19O11",
        "family_id" : 8,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O13 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37350,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37346",
        "source" : "37344",
        "target" : "37345",
        "shared_name" : "C20H25O8 (interacts with) C19H25O6",
        "family_id" : 84,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O8 (interacts with) C19H25O6",
        "interaction" : "interacts with",
        "SUID" : 37346,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38209",
        "source" : "37338",
        "target" : "37446",
        "shared_name" : "C15H11O10 (interacts with) C14H11O8",
        "family_id" : 30,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O10 (interacts with) C14H11O8",
        "interaction" : "interacts with",
        "SUID" : 38209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37989",
        "source" : "37338",
        "target" : "37241",
        "shared_name" : "C15H11O10 (interacts with) C15H9O9",
        "family_id" : 220,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H11O10 (interacts with) C15H9O9",
        "interaction" : "interacts with",
        "SUID" : 37989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37447",
        "source" : "37338",
        "target" : "37446",
        "shared_name" : "C15H11O10 (interacts with) C14H11O8",
        "family_id" : 259,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O10 (interacts with) C14H11O8",
        "interaction" : "interacts with",
        "SUID" : 37447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38231",
        "source" : "37329",
        "target" : "37635",
        "shared_name" : "C13H7O8 (interacts with) C12H7O6",
        "family_id" : 324,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H7O8 (interacts with) C12H7O6",
        "interaction" : "interacts with",
        "SUID" : 38231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37876",
        "source" : "37329",
        "target" : "37635",
        "shared_name" : "C13H7O8 (interacts with) C12H7O6",
        "family_id" : 185,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H7O8 (interacts with) C12H7O6",
        "interaction" : "interacts with",
        "SUID" : 37876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37729",
        "source" : "37329",
        "target" : "37635",
        "shared_name" : "C13H7O8 (interacts with) C12H7O6",
        "family_id" : 2,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H7O8 (interacts with) C12H7O6",
        "interaction" : "interacts with",
        "SUID" : 37729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38226",
        "source" : "37327",
        "target" : "36892",
        "shared_name" : "C15H19O11 (interacts with) C15H17O10",
        "family_id" : 120,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O11 (interacts with) C15H17O10",
        "interaction" : "interacts with",
        "SUID" : 38226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38217",
        "source" : "37327",
        "target" : "36892",
        "shared_name" : "C15H19O11 (interacts with) C15H17O10",
        "family_id" : 100,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O11 (interacts with) C15H17O10",
        "interaction" : "interacts with",
        "SUID" : 38217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38033",
        "source" : "37327",
        "target" : "36892",
        "shared_name" : "C15H19O11 (interacts with) C15H17O10",
        "family_id" : 136,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O11 (interacts with) C15H17O10",
        "interaction" : "interacts with",
        "SUID" : 38033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38020",
        "source" : "37327",
        "target" : "36892",
        "shared_name" : "C15H19O11 (interacts with) C15H17O10",
        "family_id" : 190,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O11 (interacts with) C15H17O10",
        "interaction" : "interacts with",
        "SUID" : 38020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37973",
        "source" : "37327",
        "target" : "36892",
        "shared_name" : "C15H19O11 (interacts with) C15H17O10",
        "family_id" : 277,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O11 (interacts with) C15H17O10",
        "interaction" : "interacts with",
        "SUID" : 37973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37506",
        "source" : "37327",
        "target" : "36892",
        "shared_name" : "C15H19O11 (interacts with) C15H17O10",
        "family_id" : 319,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O11 (interacts with) C15H17O10",
        "interaction" : "interacts with",
        "SUID" : 37506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37328",
        "source" : "37327",
        "target" : "36892",
        "shared_name" : "C15H19O11 (interacts with) C15H17O10",
        "family_id" : 282,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O11 (interacts with) C15H17O10",
        "interaction" : "interacts with",
        "SUID" : 37328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37475",
        "source" : "37318",
        "target" : "37474",
        "shared_name" : "C20H19O10 (interacts with) C19H15O9",
        "family_id" : 265,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C20H19O10 (interacts with) C19H15O9",
        "interaction" : "interacts with",
        "SUID" : 37475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37341",
        "source" : "37318",
        "target" : "36838",
        "shared_name" : "C20H19O10 (interacts with) C20H17O9",
        "family_id" : 142,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H19O10 (interacts with) C20H17O9",
        "interaction" : "interacts with",
        "SUID" : 37341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37823",
        "source" : "37317",
        "target" : "37822",
        "shared_name" : "C21H19O12 (interacts with) C21H17O11",
        "family_id" : 89,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H19O12 (interacts with) C21H17O11",
        "interaction" : "interacts with",
        "SUID" : 37823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37319",
        "source" : "37317",
        "target" : "37318",
        "shared_name" : "C21H19O12 (interacts with) C20H19O10",
        "family_id" : 142,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H19O12 (interacts with) C20H19O10",
        "interaction" : "interacts with",
        "SUID" : 37319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37313",
        "source" : "37312",
        "target" : "37012",
        "shared_name" : "C19H19O10 (interacts with) C19H17O9",
        "family_id" : 99,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H19O10 (interacts with) C19H17O9",
        "interaction" : "interacts with",
        "SUID" : 37313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37661",
        "source" : "37302",
        "target" : "36877",
        "shared_name" : "C15H15O12 (interacts with) C14H15O10",
        "family_id" : 157,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O12 (interacts with) C14H15O10",
        "interaction" : "interacts with",
        "SUID" : 37661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37303",
        "source" : "37302",
        "target" : "37199",
        "shared_name" : "C15H15O12 (interacts with) C15H13O11",
        "family_id" : 306,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H15O12 (interacts with) C15H13O11",
        "interaction" : "interacts with",
        "SUID" : 37303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37733",
        "source" : "37298",
        "target" : "37026",
        "shared_name" : "C19H23O9 (interacts with) C18H23O7",
        "family_id" : 310,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O9 (interacts with) C18H23O7",
        "interaction" : "interacts with",
        "SUID" : 37733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37441",
        "source" : "37298",
        "target" : "37026",
        "shared_name" : "C19H23O9 (interacts with) C18H23O7",
        "family_id" : 86,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O9 (interacts with) C18H23O7",
        "interaction" : "interacts with",
        "SUID" : 37441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37299",
        "source" : "37298",
        "target" : "37175",
        "shared_name" : "C19H23O9 (interacts with) C19H21O8",
        "family_id" : 143,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O9 (interacts with) C19H21O8",
        "interaction" : "interacts with",
        "SUID" : 37299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38125",
        "source" : "37292",
        "target" : "37041",
        "shared_name" : "C16H17O11 (interacts with) C16H15O10",
        "family_id" : 316,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O11 (interacts with) C16H15O10",
        "interaction" : "interacts with",
        "SUID" : 38125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37699",
        "source" : "37292",
        "target" : "37041",
        "shared_name" : "C16H17O11 (interacts with) C16H15O10",
        "family_id" : 121,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O11 (interacts with) C16H15O10",
        "interaction" : "interacts with",
        "SUID" : 37699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37375",
        "source" : "37292",
        "target" : "37096",
        "shared_name" : "C16H17O11 (interacts with) C15H17O9",
        "family_id" : 109,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O11 (interacts with) C15H17O9",
        "interaction" : "interacts with",
        "SUID" : 37375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37294",
        "source" : "37292",
        "target" : "37096",
        "shared_name" : "C16H17O11 (interacts with) C15H17O9",
        "family_id" : 340,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O11 (interacts with) C15H17O9",
        "interaction" : "interacts with",
        "SUID" : 37294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37293",
        "source" : "37292",
        "target" : "37096",
        "shared_name" : "C16H17O11 (interacts with) C15H17O9",
        "family_id" : 232,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O11 (interacts with) C15H17O9",
        "interaction" : "interacts with",
        "SUID" : 37293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37288",
        "source" : "37286",
        "target" : "37287",
        "shared_name" : "C20H31O10 (interacts with) C20H29O9",
        "family_id" : 230,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H31O10 (interacts with) C20H29O9",
        "interaction" : "interacts with",
        "SUID" : 37288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37567",
        "source" : "37280",
        "target" : "37566",
        "shared_name" : "C16H13O11 (interacts with) C15H13O9",
        "family_id" : 183,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O11 (interacts with) C15H13O9",
        "interaction" : "interacts with",
        "SUID" : 37567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37498",
        "source" : "37280",
        "target" : "37046",
        "shared_name" : "C16H13O11 (interacts with) C16H11O10",
        "family_id" : 149,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H13O11 (interacts with) C16H11O10",
        "interaction" : "interacts with",
        "SUID" : 37498,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37281",
        "source" : "37279",
        "target" : "37280",
        "shared_name" : "C16H15O12 (interacts with) C16H13O11",
        "family_id" : 183,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H15O12 (interacts with) C16H13O11",
        "interaction" : "interacts with",
        "SUID" : 37281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37880",
        "source" : "37274",
        "target" : "37360",
        "shared_name" : "C12H13O8 (interacts with) C11H13O6",
        "family_id" : 221,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H13O8 (interacts with) C11H13O6",
        "interaction" : "interacts with",
        "SUID" : 37880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37377",
        "source" : "37274",
        "target" : "37376",
        "shared_name" : "C12H13O8 (interacts with) C12H11O7",
        "family_id" : 243,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H13O8 (interacts with) C12H11O7",
        "interaction" : "interacts with",
        "SUID" : 37377,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37361",
        "source" : "37274",
        "target" : "37360",
        "shared_name" : "C12H13O8 (interacts with) C11H13O6",
        "family_id" : 322,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H13O8 (interacts with) C11H13O6",
        "interaction" : "interacts with",
        "SUID" : 37361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38114",
        "source" : "37273",
        "target" : "37274",
        "shared_name" : "C12H15O9 (interacts with) C12H13O8",
        "family_id" : 243,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H15O9 (interacts with) C12H13O8",
        "interaction" : "interacts with",
        "SUID" : 38114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37748",
        "source" : "37273",
        "target" : "37747",
        "shared_name" : "C12H15O9 (interacts with) C11H15O7",
        "family_id" : 261,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H15O9 (interacts with) C11H15O7",
        "interaction" : "interacts with",
        "SUID" : 37748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37662",
        "source" : "37273",
        "target" : "37274",
        "shared_name" : "C12H15O9 (interacts with) C12H13O8",
        "family_id" : 147,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H15O9 (interacts with) C12H13O8",
        "interaction" : "interacts with",
        "SUID" : 37662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37275",
        "source" : "37273",
        "target" : "37274",
        "shared_name" : "C12H15O9 (interacts with) C12H13O8",
        "family_id" : 221,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H15O9 (interacts with) C12H13O8",
        "interaction" : "interacts with",
        "SUID" : 37275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38181",
        "source" : "37271",
        "target" : "37112",
        "shared_name" : "C13H13O8 (interacts with) C13H11O7",
        "family_id" : 56,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H13O8 (interacts with) C13H11O7",
        "interaction" : "interacts with",
        "SUID" : 38181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38075",
        "source" : "37271",
        "target" : "37403",
        "shared_name" : "C13H13O8 (interacts with) C12H13O6",
        "family_id" : 272,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H13O8 (interacts with) C12H13O6",
        "interaction" : "interacts with",
        "SUID" : 38075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37961",
        "source" : "37271",
        "target" : "37112",
        "shared_name" : "C13H13O8 (interacts with) C13H11O7",
        "family_id" : 33,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H13O8 (interacts with) C13H11O7",
        "interaction" : "interacts with",
        "SUID" : 37961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37459",
        "source" : "37271",
        "target" : "37112",
        "shared_name" : "C13H13O8 (interacts with) C13H11O7",
        "family_id" : 184,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H13O8 (interacts with) C13H11O7",
        "interaction" : "interacts with",
        "SUID" : 37459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37404",
        "source" : "37271",
        "target" : "37403",
        "shared_name" : "C13H13O8 (interacts with) C12H13O6",
        "family_id" : 14,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H13O8 (interacts with) C12H13O6",
        "interaction" : "interacts with",
        "SUID" : 37404,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38072",
        "source" : "37270",
        "target" : "37271",
        "shared_name" : "C13H15O9 (interacts with) C13H13O8",
        "family_id" : 272,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H15O9 (interacts with) C13H13O8",
        "interaction" : "interacts with",
        "SUID" : 38072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38002",
        "source" : "37270",
        "target" : "37639",
        "shared_name" : "C13H15O9 (interacts with) C12H15O7",
        "family_id" : 7,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H15O9 (interacts with) C12H15O7",
        "interaction" : "interacts with",
        "SUID" : 38002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37668",
        "source" : "37270",
        "target" : "37271",
        "shared_name" : "C13H15O9 (interacts with) C13H13O8",
        "family_id" : 140,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H15O9 (interacts with) C13H13O8",
        "interaction" : "interacts with",
        "SUID" : 37668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37272",
        "source" : "37270",
        "target" : "37271",
        "shared_name" : "C13H15O9 (interacts with) C13H13O8",
        "family_id" : 184,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H15O9 (interacts with) C13H13O8",
        "interaction" : "interacts with",
        "SUID" : 37272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38176",
        "source" : "37268",
        "target" : "36968",
        "shared_name" : "C17H9O12 (interacts with) C16H9O10",
        "family_id" : 62,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H9O12 (interacts with) C16H9O10",
        "interaction" : "interacts with",
        "SUID" : 38176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37269",
        "source" : "37268",
        "target" : "36968",
        "shared_name" : "C17H9O12 (interacts with) C16H9O10",
        "family_id" : 137,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H9O12 (interacts with) C16H9O10",
        "interaction" : "interacts with",
        "SUID" : 37269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37929",
        "source" : "37264",
        "target" : "37635",
        "shared_name" : "C12H9O7 (interacts with) C12H7O6",
        "family_id" : 105,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H9O7 (interacts with) C12H7O6",
        "interaction" : "interacts with",
        "SUID" : 37929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37636",
        "source" : "37264",
        "target" : "37635",
        "shared_name" : "C12H9O7 (interacts with) C12H7O6",
        "family_id" : 160,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H9O7 (interacts with) C12H7O6",
        "interaction" : "interacts with",
        "SUID" : 37636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38220",
        "source" : "37259",
        "target" : "36991",
        "shared_name" : "C16H13O12 (interacts with) C16H11O11",
        "family_id" : 202,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H13O12 (interacts with) C16H11O11",
        "interaction" : "interacts with",
        "SUID" : 38220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37354",
        "source" : "37259",
        "target" : "36991",
        "shared_name" : "C16H13O12 (interacts with) C16H11O11",
        "family_id" : 208,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H13O12 (interacts with) C16H11O11",
        "interaction" : "interacts with",
        "SUID" : 37354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37283",
        "source" : "37259",
        "target" : "37043",
        "shared_name" : "C16H13O12 (interacts with) C15H13O10",
        "family_id" : 250,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O12 (interacts with) C15H13O10",
        "interaction" : "interacts with",
        "SUID" : 37283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37260",
        "source" : "37259",
        "target" : "36991",
        "shared_name" : "C16H13O12 (interacts with) C16H11O11",
        "family_id" : 102,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H13O12 (interacts with) C16H11O11",
        "interaction" : "interacts with",
        "SUID" : 37260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38199",
        "source" : "37256",
        "target" : "36823",
        "shared_name" : "C16H17O9 (interacts with) C16H15O8",
        "family_id" : 54,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O9 (interacts with) C16H15O8",
        "interaction" : "interacts with",
        "SUID" : 38199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38131",
        "source" : "37256",
        "target" : "37214",
        "shared_name" : "C16H17O9 (interacts with) C15H17O7",
        "family_id" : 42,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O9 (interacts with) C15H17O7",
        "interaction" : "interacts with",
        "SUID" : 38131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38040",
        "source" : "37256",
        "target" : "36823",
        "shared_name" : "C16H17O9 (interacts with) C16H15O8",
        "family_id" : 146,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O9 (interacts with) C16H15O8",
        "interaction" : "interacts with",
        "SUID" : 38040,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37824",
        "source" : "37256",
        "target" : "36823",
        "shared_name" : "C16H17O9 (interacts with) C16H15O8",
        "family_id" : 129,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O9 (interacts with) C16H15O8",
        "interaction" : "interacts with",
        "SUID" : 37824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37419",
        "source" : "37256",
        "target" : "36823",
        "shared_name" : "C16H17O9 (interacts with) C16H15O8",
        "family_id" : 145,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O9 (interacts with) C16H15O8",
        "interaction" : "interacts with",
        "SUID" : 37419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37257",
        "source" : "37256",
        "target" : "36823",
        "shared_name" : "C16H17O9 (interacts with) C16H15O8",
        "family_id" : 287,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O9 (interacts with) C16H15O8",
        "interaction" : "interacts with",
        "SUID" : 37257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38182",
        "source" : "37252",
        "target" : "37253",
        "shared_name" : "C18H15O8 (interacts with) C17H15O6",
        "family_id" : 231,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H15O8 (interacts with) C17H15O6",
        "interaction" : "interacts with",
        "SUID" : 38182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37254",
        "source" : "37252",
        "target" : "37253",
        "shared_name" : "C18H15O8 (interacts with) C17H15O6",
        "family_id" : 311,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H15O8 (interacts with) C17H15O6",
        "interaction" : "interacts with",
        "SUID" : 37254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37955",
        "source" : "37249",
        "target" : "37457",
        "shared_name" : "C15H11O7 (interacts with) C15H9O6",
        "family_id" : 187,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H11O7 (interacts with) C15H9O6",
        "interaction" : "interacts with",
        "SUID" : 37955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37697",
        "source" : "37249",
        "target" : "37457",
        "shared_name" : "C15H11O7 (interacts with) C15H9O6",
        "family_id" : 228,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H11O7 (interacts with) C15H9O6",
        "interaction" : "interacts with",
        "SUID" : 37697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37505",
        "source" : "37249",
        "target" : "37457",
        "shared_name" : "C15H11O7 (interacts with) C15H9O6",
        "family_id" : 207,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H11O7 (interacts with) C15H9O6",
        "interaction" : "interacts with",
        "SUID" : 37505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38051",
        "source" : "37245",
        "target" : "36942",
        "shared_name" : "C18H17O13 (interacts with) C17H17O11",
        "family_id" : 287,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O13 (interacts with) C17H17O11",
        "interaction" : "interacts with",
        "SUID" : 38051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37840",
        "source" : "37245",
        "target" : "36942",
        "shared_name" : "C18H17O13 (interacts with) C17H17O11",
        "family_id" : 276,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O13 (interacts with) C17H17O11",
        "interaction" : "interacts with",
        "SUID" : 37840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37246",
        "source" : "37245",
        "target" : "36942",
        "shared_name" : "C18H17O13 (interacts with) C17H17O11",
        "family_id" : 146,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O13 (interacts with) C17H17O11",
        "interaction" : "interacts with",
        "SUID" : 37246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38135",
        "source" : "37241",
        "target" : "36901",
        "shared_name" : "C15H9O9 (interacts with) C15H7O8",
        "family_id" : 281,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H9O9 (interacts with) C15H7O8",
        "interaction" : "interacts with",
        "SUID" : 38135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38107",
        "source" : "37241",
        "target" : "36856",
        "shared_name" : "C15H9O9 (interacts with) C14H9O7",
        "family_id" : 55,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H9O9 (interacts with) C14H9O7",
        "interaction" : "interacts with",
        "SUID" : 38107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37485",
        "source" : "37241",
        "target" : "36901",
        "shared_name" : "C15H9O9 (interacts with) C15H7O8",
        "family_id" : 284,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H9O9 (interacts with) C15H7O8",
        "interaction" : "interacts with",
        "SUID" : 37485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37444",
        "source" : "37241",
        "target" : "36856",
        "shared_name" : "C15H9O9 (interacts with) C14H9O7",
        "family_id" : 220,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H9O9 (interacts with) C14H9O7",
        "interaction" : "interacts with",
        "SUID" : 37444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38030",
        "source" : "37240",
        "target" : "37835",
        "shared_name" : "C16H9O11 (interacts with) C16H7O10",
        "family_id" : 225,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H9O11 (interacts with) C16H7O10",
        "interaction" : "interacts with",
        "SUID" : 38030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37914",
        "source" : "37240",
        "target" : "37241",
        "shared_name" : "C16H9O11 (interacts with) C15H9O9",
        "family_id" : 284,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O11 (interacts with) C15H9O9",
        "interaction" : "interacts with",
        "SUID" : 37914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37836",
        "source" : "37240",
        "target" : "37835",
        "shared_name" : "C16H9O11 (interacts with) C16H7O10",
        "family_id" : 328,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H9O11 (interacts with) C16H7O10",
        "interaction" : "interacts with",
        "SUID" : 37836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37412",
        "source" : "37240",
        "target" : "37241",
        "shared_name" : "C16H9O11 (interacts with) C15H9O9",
        "family_id" : 55,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O11 (interacts with) C15H9O9",
        "interaction" : "interacts with",
        "SUID" : 37412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37242",
        "source" : "37240",
        "target" : "37241",
        "shared_name" : "C16H9O11 (interacts with) C15H9O9",
        "family_id" : 281,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O11 (interacts with) C15H9O9",
        "interaction" : "interacts with",
        "SUID" : 37242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37504",
        "source" : "37237",
        "target" : "37503",
        "shared_name" : "C19H15O11 (interacts with) C18H15O9",
        "family_id" : 168,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H15O11 (interacts with) C18H15O9",
        "interaction" : "interacts with",
        "SUID" : 37504,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37238",
        "source" : "37236",
        "target" : "37237",
        "shared_name" : "C20H19O12 (interacts with) C19H15O11",
        "family_id" : 168,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C20H19O12 (interacts with) C19H15O11",
        "interaction" : "interacts with",
        "SUID" : 37238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37849",
        "source" : "37233",
        "target" : "37329",
        "shared_name" : "C13H9O9 (interacts with) C13H7O8",
        "family_id" : 2,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H9O9 (interacts with) C13H7O8",
        "interaction" : "interacts with",
        "SUID" : 37849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37431",
        "source" : "37233",
        "target" : "37264",
        "shared_name" : "C13H9O9 (interacts with) C12H9O7",
        "family_id" : 160,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H9O9 (interacts with) C12H9O7",
        "interaction" : "interacts with",
        "SUID" : 37431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37330",
        "source" : "37233",
        "target" : "37329",
        "shared_name" : "C13H9O9 (interacts with) C13H7O8",
        "family_id" : 324,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H9O9 (interacts with) C13H7O8",
        "interaction" : "interacts with",
        "SUID" : 37330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37265",
        "source" : "37233",
        "target" : "37264",
        "shared_name" : "C13H9O9 (interacts with) C12H9O7",
        "family_id" : 105,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H9O9 (interacts with) C12H9O7",
        "interaction" : "interacts with",
        "SUID" : 37265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38080",
        "source" : "37232",
        "target" : "36929",
        "shared_name" : "C13H11O10 (interacts with) C12H11O8",
        "family_id" : 237,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H11O10 (interacts with) C12H11O8",
        "interaction" : "interacts with",
        "SUID" : 38080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37608",
        "source" : "37232",
        "target" : "37233",
        "shared_name" : "C13H11O10 (interacts with) C13H9O9",
        "family_id" : 160,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H11O10 (interacts with) C13H9O9",
        "interaction" : "interacts with",
        "SUID" : 37608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37234",
        "source" : "37232",
        "target" : "37233",
        "shared_name" : "C13H11O10 (interacts with) C13H9O9",
        "family_id" : 2,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H11O10 (interacts with) C13H9O9",
        "interaction" : "interacts with",
        "SUID" : 37234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37967",
        "source" : "37229",
        "target" : "37298",
        "shared_name" : "C20H23O11 (interacts with) C19H23O9",
        "family_id" : 310,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O11 (interacts with) C19H23O9",
        "interaction" : "interacts with",
        "SUID" : 37967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37353",
        "source" : "37229",
        "target" : "37298",
        "shared_name" : "C20H23O11 (interacts with) C19H23O9",
        "family_id" : 143,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O11 (interacts with) C19H23O9",
        "interaction" : "interacts with",
        "SUID" : 37353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37230",
        "source" : "37229",
        "target" : "37174",
        "shared_name" : "C20H23O11 (interacts with) C20H21O10",
        "family_id" : 333,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O11 (interacts with) C20H21O10",
        "interaction" : "interacts with",
        "SUID" : 37230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37602",
        "source" : "37224",
        "target" : "37026",
        "shared_name" : "C18H25O8 (interacts with) C18H23O7",
        "family_id" : 332,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H25O8 (interacts with) C18H23O7",
        "interaction" : "interacts with",
        "SUID" : 37602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37414",
        "source" : "37224",
        "target" : "37026",
        "shared_name" : "C18H25O8 (interacts with) C18H23O7",
        "family_id" : 52,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H25O8 (interacts with) C18H23O7",
        "interaction" : "interacts with",
        "SUID" : 37414,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37365",
        "source" : "37224",
        "target" : "37026",
        "shared_name" : "C18H25O8 (interacts with) C18H23O7",
        "family_id" : 323,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H25O8 (interacts with) C18H23O7",
        "interaction" : "interacts with",
        "SUID" : 37365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38050",
        "source" : "37214",
        "target" : "37215",
        "shared_name" : "C15H17O7 (interacts with) C14H17O5",
        "family_id" : 42,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O7 (interacts with) C14H17O5",
        "interaction" : "interacts with",
        "SUID" : 38050,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37216",
        "source" : "37214",
        "target" : "37215",
        "shared_name" : "C15H17O7 (interacts with) C14H17O5",
        "family_id" : 4,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O7 (interacts with) C14H17O5",
        "interaction" : "interacts with",
        "SUID" : 37216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37853",
        "source" : "37211",
        "target" : "36895",
        "shared_name" : "C15H19O7 (interacts with) C15H17O6",
        "family_id" : 144,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O7 (interacts with) C15H17O6",
        "interaction" : "interacts with",
        "SUID" : 37853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37781",
        "source" : "37211",
        "target" : "36895",
        "shared_name" : "C15H19O7 (interacts with) C15H17O6",
        "family_id" : 82,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O7 (interacts with) C15H17O6",
        "interaction" : "interacts with",
        "SUID" : 37781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37583",
        "source" : "37211",
        "target" : "37582",
        "shared_name" : "C15H19O7 (interacts with) C14H19O5",
        "family_id" : 303,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H19O7 (interacts with) C14H19O5",
        "interaction" : "interacts with",
        "SUID" : 37583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37538",
        "source" : "37211",
        "target" : "36895",
        "shared_name" : "C15H19O7 (interacts with) C15H17O6",
        "family_id" : 49,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O7 (interacts with) C15H17O6",
        "interaction" : "interacts with",
        "SUID" : 37538,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38120",
        "source" : "37208",
        "target" : "36823",
        "shared_name" : "C17H15O10 (interacts with) C16H15O8",
        "family_id" : 264,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H15O10 (interacts with) C16H15O8",
        "interaction" : "interacts with",
        "SUID" : 38120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37999",
        "source" : "37208",
        "target" : "36823",
        "shared_name" : "C17H15O10 (interacts with) C16H15O8",
        "family_id" : 205,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H15O10 (interacts with) C16H15O8",
        "interaction" : "interacts with",
        "SUID" : 37999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37913",
        "source" : "37208",
        "target" : "37184",
        "shared_name" : "C17H15O10 (interacts with) C16H11O9",
        "family_id" : 226,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C17H15O10 (interacts with) C16H11O9",
        "interaction" : "interacts with",
        "SUID" : 37913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37720",
        "source" : "37208",
        "target" : "36823",
        "shared_name" : "C17H15O10 (interacts with) C16H15O8",
        "family_id" : 294,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H15O10 (interacts with) C16H15O8",
        "interaction" : "interacts with",
        "SUID" : 37720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37472",
        "source" : "37208",
        "target" : "37184",
        "shared_name" : "C17H15O10 (interacts with) C16H11O9",
        "family_id" : 47,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C17H15O10 (interacts with) C16H11O9",
        "interaction" : "interacts with",
        "SUID" : 37472,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37209",
        "source" : "37208",
        "target" : "36823",
        "shared_name" : "C17H15O10 (interacts with) C16H15O8",
        "family_id" : 276,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H15O10 (interacts with) C16H15O8",
        "interaction" : "interacts with",
        "SUID" : 37209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38247",
        "source" : "37205",
        "target" : "36970",
        "shared_name" : "C19H25O9 (interacts with) C19H23O8",
        "family_id" : 50,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O9 (interacts with) C19H23O8",
        "interaction" : "interacts with",
        "SUID" : 38247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37778",
        "source" : "37205",
        "target" : "36970",
        "shared_name" : "C19H25O9 (interacts with) C19H23O8",
        "family_id" : 252,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O9 (interacts with) C19H23O8",
        "interaction" : "interacts with",
        "SUID" : 37778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37490",
        "source" : "37205",
        "target" : "36970",
        "shared_name" : "C19H25O9 (interacts with) C19H23O8",
        "family_id" : 78,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O9 (interacts with) C19H23O8",
        "interaction" : "interacts with",
        "SUID" : 37490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37413",
        "source" : "37205",
        "target" : "36970",
        "shared_name" : "C19H25O9 (interacts with) C19H23O8",
        "family_id" : 40,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O9 (interacts with) C19H23O8",
        "interaction" : "interacts with",
        "SUID" : 37413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37550",
        "source" : "37201",
        "target" : "37523",
        "shared_name" : "C19H17O13 (interacts with) C19H15O12",
        "family_id" : 18,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H17O13 (interacts with) C19H15O12",
        "interaction" : "interacts with",
        "SUID" : 37550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37202",
        "source" : "37201",
        "target" : "36873",
        "shared_name" : "C19H17O13 (interacts with) C18H17O11",
        "family_id" : 23,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H17O13 (interacts with) C18H17O11",
        "interaction" : "interacts with",
        "SUID" : 37202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37584",
        "source" : "37199",
        "target" : "36878",
        "shared_name" : "C15H13O11 (interacts with) C14H13O9",
        "family_id" : 306,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H13O11 (interacts with) C14H13O9",
        "interaction" : "interacts with",
        "SUID" : 37584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37339",
        "source" : "37199",
        "target" : "37338",
        "shared_name" : "C15H13O11 (interacts with) C15H11O10",
        "family_id" : 30,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H13O11 (interacts with) C15H11O10",
        "interaction" : "interacts with",
        "SUID" : 37339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37200",
        "source" : "37199",
        "target" : "36878",
        "shared_name" : "C15H13O11 (interacts with) C14H13O9",
        "family_id" : 267,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H13O11 (interacts with) C14H13O9",
        "interaction" : "interacts with",
        "SUID" : 37200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37581",
        "source" : "37197",
        "target" : "37205",
        "shared_name" : "C19H27O10 (interacts with) C19H25O9",
        "family_id" : 252,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H27O10 (interacts with) C19H25O9",
        "interaction" : "interacts with",
        "SUID" : 37581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37491",
        "source" : "37197",
        "target" : "37205",
        "shared_name" : "C19H27O10 (interacts with) C19H25O9",
        "family_id" : 50,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H27O10 (interacts with) C19H25O9",
        "interaction" : "interacts with",
        "SUID" : 37491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37206",
        "source" : "37197",
        "target" : "37205",
        "shared_name" : "C19H27O10 (interacts with) C19H25O9",
        "family_id" : 318,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H27O10 (interacts with) C19H25O9",
        "interaction" : "interacts with",
        "SUID" : 37206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37923",
        "source" : "37195",
        "target" : "36921",
        "shared_name" : "C18H21O10 (interacts with) C18H19O9",
        "family_id" : 174,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37790",
        "source" : "37195",
        "target" : "36867",
        "shared_name" : "C18H21O10 (interacts with) C17H21O8",
        "family_id" : 337,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O10 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 37790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37788",
        "source" : "37195",
        "target" : "36921",
        "shared_name" : "C18H21O10 (interacts with) C18H19O9",
        "family_id" : 44,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37617",
        "source" : "37195",
        "target" : "36921",
        "shared_name" : "C18H21O10 (interacts with) C18H19O9",
        "family_id" : 73,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37555",
        "source" : "37195",
        "target" : "36867",
        "shared_name" : "C18H21O10 (interacts with) C17H21O8",
        "family_id" : 117,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O10 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 37555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37545",
        "source" : "37195",
        "target" : "36921",
        "shared_name" : "C18H21O10 (interacts with) C18H19O9",
        "family_id" : 13,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37396",
        "source" : "37195",
        "target" : "36921",
        "shared_name" : "C18H21O10 (interacts with) C18H19O9",
        "family_id" : 72,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37196",
        "source" : "37195",
        "target" : "36921",
        "shared_name" : "C18H21O10 (interacts with) C18H19O9",
        "family_id" : 125,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37194",
        "source" : "37192",
        "target" : "37193",
        "shared_name" : "C15H19O6 (interacts with) C15H17O5",
        "family_id" : 15,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O6 (interacts with) C15H17O5",
        "interaction" : "interacts with",
        "SUID" : 37194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38244",
        "source" : "37184",
        "target" : "36933",
        "shared_name" : "C16H11O9 (interacts with) C16H9O8",
        "family_id" : 341,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H11O9 (interacts with) C16H9O8",
        "interaction" : "interacts with",
        "SUID" : 38244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38076",
        "source" : "37184",
        "target" : "37249",
        "shared_name" : "C16H11O9 (interacts with) C15H11O7",
        "family_id" : 207,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O9 (interacts with) C15H11O7",
        "interaction" : "interacts with",
        "SUID" : 38076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37974",
        "source" : "37184",
        "target" : "37249",
        "shared_name" : "C16H11O9 (interacts with) C15H11O7",
        "family_id" : 47,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O9 (interacts with) C15H11O7",
        "interaction" : "interacts with",
        "SUID" : 37974,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37893",
        "source" : "37184",
        "target" : "36933",
        "shared_name" : "C16H11O9 (interacts with) C16H9O8",
        "family_id" : 88,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H11O9 (interacts with) C16H9O8",
        "interaction" : "interacts with",
        "SUID" : 37893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37448",
        "source" : "37184",
        "target" : "36933",
        "shared_name" : "C16H11O9 (interacts with) C16H9O8",
        "family_id" : 307,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H11O9 (interacts with) C16H9O8",
        "interaction" : "interacts with",
        "SUID" : 37448,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37423",
        "source" : "37184",
        "target" : "37249",
        "shared_name" : "C16H11O9 (interacts with) C15H11O7",
        "family_id" : 228,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O9 (interacts with) C15H11O7",
        "interaction" : "interacts with",
        "SUID" : 37423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37250",
        "source" : "37184",
        "target" : "37249",
        "shared_name" : "C16H11O9 (interacts with) C15H11O7",
        "family_id" : 187,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O9 (interacts with) C15H11O7",
        "interaction" : "interacts with",
        "SUID" : 37250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37185",
        "source" : "37184",
        "target" : "36933",
        "shared_name" : "C16H11O9 (interacts with) C16H9O8",
        "family_id" : 326,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H11O9 (interacts with) C16H9O8",
        "interaction" : "interacts with",
        "SUID" : 37185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37975",
        "source" : "37181",
        "target" : "36824",
        "shared_name" : "C17H13O9 (interacts with) C16H13O7",
        "family_id" : 317,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O9 (interacts with) C16H13O7",
        "interaction" : "interacts with",
        "SUID" : 37975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37768",
        "source" : "37181",
        "target" : "36824",
        "shared_name" : "C17H13O9 (interacts with) C16H13O7",
        "family_id" : 152,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O9 (interacts with) C16H13O7",
        "interaction" : "interacts with",
        "SUID" : 37768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37807",
        "source" : "37180",
        "target" : "37181",
        "shared_name" : "C18H17O10 (interacts with) C17H13O9",
        "family_id" : 152,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H17O10 (interacts with) C17H13O9",
        "interaction" : "interacts with",
        "SUID" : 37807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37226",
        "source" : "37180",
        "target" : "37181",
        "shared_name" : "C18H17O10 (interacts with) C17H13O9",
        "family_id" : 247,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H17O10 (interacts with) C17H13O9",
        "interaction" : "interacts with",
        "SUID" : 37226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37182",
        "source" : "37180",
        "target" : "37181",
        "shared_name" : "C18H17O10 (interacts with) C17H13O9",
        "family_id" : 317,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H17O10 (interacts with) C17H13O9",
        "interaction" : "interacts with",
        "SUID" : 37182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38098",
        "source" : "37175",
        "target" : "38012",
        "shared_name" : "C19H21O8 (interacts with) C19H19O7",
        "family_id" : 333,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O8 (interacts with) C19H19O7",
        "interaction" : "interacts with",
        "SUID" : 38098,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38013",
        "source" : "37175",
        "target" : "38012",
        "shared_name" : "C19H21O8 (interacts with) C19H19O7",
        "family_id" : 143,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O8 (interacts with) C19H19O7",
        "interaction" : "interacts with",
        "SUID" : 38013,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37176",
        "source" : "37174",
        "target" : "37175",
        "shared_name" : "C20H21O10 (interacts with) C19H21O8",
        "family_id" : 333,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O10 (interacts with) C19H21O8",
        "interaction" : "interacts with",
        "SUID" : 37176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37172",
        "source" : "37171",
        "target" : "36897",
        "shared_name" : "C17H17O13 (interacts with) C17H15O12",
        "family_id" : 269,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H17O13 (interacts with) C17H15O12",
        "interaction" : "interacts with",
        "SUID" : 37172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37161",
        "source" : "37159",
        "target" : "37160",
        "shared_name" : "C19H11O10 (interacts with) C18H11O8",
        "family_id" : 194,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H11O10 (interacts with) C18H11O8",
        "interaction" : "interacts with",
        "SUID" : 37161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37701",
        "source" : "37155",
        "target" : "37306",
        "shared_name" : "C12H9O8 (interacts with) C11H9O6",
        "family_id" : 177,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H9O8 (interacts with) C11H9O6",
        "interaction" : "interacts with",
        "SUID" : 37701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37307",
        "source" : "37155",
        "target" : "37306",
        "shared_name" : "C12H9O8 (interacts with) C11H9O6",
        "family_id" : 79,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H9O8 (interacts with) C11H9O6",
        "interaction" : "interacts with",
        "SUID" : 37307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37157",
        "source" : "37155",
        "target" : "37156",
        "shared_name" : "C12H9O8 (interacts with) C12H7O7",
        "family_id" : 29,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H9O8 (interacts with) C12H7O7",
        "interaction" : "interacts with",
        "SUID" : 37157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38177",
        "source" : "37152",
        "target" : "37018",
        "shared_name" : "C16H21O11 (interacts with) C15H21O9",
        "family_id" : 215,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O11 (interacts with) C15H21O9",
        "interaction" : "interacts with",
        "SUID" : 38177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37997",
        "source" : "37152",
        "target" : "37517",
        "shared_name" : "C16H21O11 (interacts with) C16H19O10",
        "family_id" : 195,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O11 (interacts with) C16H19O10",
        "interaction" : "interacts with",
        "SUID" : 37997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37921",
        "source" : "37152",
        "target" : "37018",
        "shared_name" : "C16H21O11 (interacts with) C15H21O9",
        "family_id" : 262,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O11 (interacts with) C15H21O9",
        "interaction" : "interacts with",
        "SUID" : 37921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37592",
        "source" : "37152",
        "target" : "37018",
        "shared_name" : "C16H21O11 (interacts with) C15H21O9",
        "family_id" : 248,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O11 (interacts with) C15H21O9",
        "interaction" : "interacts with",
        "SUID" : 37592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37518",
        "source" : "37152",
        "target" : "37517",
        "shared_name" : "C16H21O11 (interacts with) C16H19O10",
        "family_id" : 189,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O11 (interacts with) C16H19O10",
        "interaction" : "interacts with",
        "SUID" : 37518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37324",
        "source" : "37152",
        "target" : "37018",
        "shared_name" : "C16H21O11 (interacts with) C15H21O9",
        "family_id" : 223,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O11 (interacts with) C15H21O9",
        "interaction" : "interacts with",
        "SUID" : 37324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37314",
        "source" : "37152",
        "target" : "37018",
        "shared_name" : "C16H21O11 (interacts with) C15H21O9",
        "family_id" : 4,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O11 (interacts with) C15H21O9",
        "interaction" : "interacts with",
        "SUID" : 37314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37153",
        "source" : "37152",
        "target" : "37018",
        "shared_name" : "C16H21O11 (interacts with) C15H21O9",
        "family_id" : 134,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O11 (interacts with) C15H21O9",
        "interaction" : "interacts with",
        "SUID" : 37153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37686",
        "source" : "37146",
        "target" : "37119",
        "shared_name" : "C14H13O11 (interacts with) C14H11O10",
        "family_id" : 213,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H13O11 (interacts with) C14H11O10",
        "interaction" : "interacts with",
        "SUID" : 37686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37147",
        "source" : "37146",
        "target" : "37119",
        "shared_name" : "C14H13O11 (interacts with) C14H11O10",
        "family_id" : 313,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H13O11 (interacts with) C14H11O10",
        "interaction" : "interacts with",
        "SUID" : 37147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37867",
        "source" : "37139",
        "target" : "36850",
        "shared_name" : "C15H11O11 (interacts with) C14H11O9",
        "family_id" : 69,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O11 (interacts with) C14H11O9",
        "interaction" : "interacts with",
        "SUID" : 37867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37565",
        "source" : "37139",
        "target" : "36850",
        "shared_name" : "C15H11O11 (interacts with) C14H11O9",
        "family_id" : 53,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O11 (interacts with) C14H11O9",
        "interaction" : "interacts with",
        "SUID" : 37565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37494",
        "source" : "37139",
        "target" : "36850",
        "shared_name" : "C15H11O11 (interacts with) C14H11O9",
        "family_id" : 308,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O11 (interacts with) C14H11O9",
        "interaction" : "interacts with",
        "SUID" : 37494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37943",
        "source" : "37138",
        "target" : "37114",
        "shared_name" : "C16H11O13 (interacts with) C16H9O12",
        "family_id" : 260,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H11O13 (interacts with) C16H9O12",
        "interaction" : "interacts with",
        "SUID" : 37943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37308",
        "source" : "37138",
        "target" : "37139",
        "shared_name" : "C16H11O13 (interacts with) C15H11O11",
        "family_id" : 69,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O13 (interacts with) C15H11O11",
        "interaction" : "interacts with",
        "SUID" : 37308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37140",
        "source" : "37138",
        "target" : "37139",
        "shared_name" : "C16H11O13 (interacts with) C15H11O11",
        "family_id" : 308,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O13 (interacts with) C15H11O11",
        "interaction" : "interacts with",
        "SUID" : 37140,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38021",
        "source" : "37133",
        "target" : "37064",
        "shared_name" : "C12H13O7 (interacts with) C12H11O6",
        "family_id" : 242,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H13O7 (interacts with) C12H11O6",
        "interaction" : "interacts with",
        "SUID" : 38021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37442",
        "source" : "37133",
        "target" : "37064",
        "shared_name" : "C12H13O7 (interacts with) C12H11O6",
        "family_id" : 92,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H13O7 (interacts with) C12H11O6",
        "interaction" : "interacts with",
        "SUID" : 37442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38007",
        "source" : "37124",
        "target" : "37218",
        "shared_name" : "C15H15O6 (interacts with) C15H13O5",
        "family_id" : 129,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H15O6 (interacts with) C15H13O5",
        "interaction" : "interacts with",
        "SUID" : 38007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37814",
        "source" : "37124",
        "target" : "37218",
        "shared_name" : "C15H15O6 (interacts with) C15H13O5",
        "family_id" : 146,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H15O6 (interacts with) C15H13O5",
        "interaction" : "interacts with",
        "SUID" : 37814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37632",
        "source" : "37124",
        "target" : "37218",
        "shared_name" : "C15H15O6 (interacts with) C15H13O5",
        "family_id" : 205,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H15O6 (interacts with) C15H13O5",
        "interaction" : "interacts with",
        "SUID" : 37632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37219",
        "source" : "37124",
        "target" : "37218",
        "shared_name" : "C15H15O6 (interacts with) C15H13O5",
        "family_id" : 276,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H15O6 (interacts with) C15H13O5",
        "interaction" : "interacts with",
        "SUID" : 37219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38161",
        "source" : "37122",
        "target" : "36996",
        "shared_name" : "C19H23O11 (interacts with) C19H21O10",
        "family_id" : 124,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O11 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 38161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38066",
        "source" : "37122",
        "target" : "36996",
        "shared_name" : "C19H23O11 (interacts with) C19H21O10",
        "family_id" : 197,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O11 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 38066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38039",
        "source" : "37122",
        "target" : "37387",
        "shared_name" : "C19H23O11 (interacts with) C18H23O9",
        "family_id" : 206,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O11 (interacts with) C18H23O9",
        "interaction" : "interacts with",
        "SUID" : 38039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37976",
        "source" : "37122",
        "target" : "36996",
        "shared_name" : "C19H23O11 (interacts with) C19H21O10",
        "family_id" : 334,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O11 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 37976,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37741",
        "source" : "37122",
        "target" : "37387",
        "shared_name" : "C19H23O11 (interacts with) C18H23O9",
        "family_id" : 320,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O11 (interacts with) C18H23O9",
        "interaction" : "interacts with",
        "SUID" : 37741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37638",
        "source" : "37122",
        "target" : "37387",
        "shared_name" : "C19H23O11 (interacts with) C18H23O9",
        "family_id" : 17,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O11 (interacts with) C18H23O9",
        "interaction" : "interacts with",
        "SUID" : 37638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37291",
        "source" : "37122",
        "target" : "36996",
        "shared_name" : "C19H23O11 (interacts with) C19H21O10",
        "family_id" : 181,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O11 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 37291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37217",
        "source" : "37122",
        "target" : "36996",
        "shared_name" : "C19H23O11 (interacts with) C19H21O10",
        "family_id" : 227,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O11 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 37217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37178",
        "source" : "37122",
        "target" : "36996",
        "shared_name" : "C19H23O11 (interacts with) C19H21O10",
        "family_id" : 304,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O11 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 37178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37905",
        "source" : "37119",
        "target" : "37063",
        "shared_name" : "C14H11O10 (interacts with) C13H11O8",
        "family_id" : 313,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H11O10 (interacts with) C13H11O8",
        "interaction" : "interacts with",
        "SUID" : 37905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37826",
        "source" : "37119",
        "target" : "37063",
        "shared_name" : "C14H11O10 (interacts with) C13H11O8",
        "family_id" : 213,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H11O10 (interacts with) C13H11O8",
        "interaction" : "interacts with",
        "SUID" : 37826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37244",
        "source" : "37119",
        "target" : "37063",
        "shared_name" : "C14H11O10 (interacts with) C13H11O8",
        "family_id" : 258,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H11O10 (interacts with) C13H11O8",
        "interaction" : "interacts with",
        "SUID" : 37244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37120",
        "source" : "37118",
        "target" : "37119",
        "shared_name" : "C15H11O12 (interacts with) C14H11O10",
        "family_id" : 258,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O12 (interacts with) C14H11O10",
        "interaction" : "interacts with",
        "SUID" : 37120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37508",
        "source" : "37115",
        "target" : "37463",
        "shared_name" : "C15H9O10 (interacts with) C15H7O9",
        "family_id" : 19,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H9O10 (interacts with) C15H7O9",
        "interaction" : "interacts with",
        "SUID" : 37508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37464",
        "source" : "37115",
        "target" : "37463",
        "shared_name" : "C15H9O10 (interacts with) C15H7O9",
        "family_id" : 178,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H9O10 (interacts with) C15H7O9",
        "interaction" : "interacts with",
        "SUID" : 37464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37451",
        "source" : "37115",
        "target" : "36851",
        "shared_name" : "C15H9O10 (interacts with) C14H9O8",
        "family_id" : 260,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H9O10 (interacts with) C14H9O8",
        "interaction" : "interacts with",
        "SUID" : 37451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37471",
        "source" : "37114",
        "target" : "37115",
        "shared_name" : "C16H9O12 (interacts with) C15H9O10",
        "family_id" : 178,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O12 (interacts with) C15H9O10",
        "interaction" : "interacts with",
        "SUID" : 37471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37203",
        "source" : "37114",
        "target" : "37115",
        "shared_name" : "C16H9O12 (interacts with) C15H9O10",
        "family_id" : 260,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O12 (interacts with) C15H9O10",
        "interaction" : "interacts with",
        "SUID" : 37203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37116",
        "source" : "37114",
        "target" : "37115",
        "shared_name" : "C16H9O12 (interacts with) C15H9O10",
        "family_id" : 19,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O12 (interacts with) C15H9O10",
        "interaction" : "interacts with",
        "SUID" : 37116,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38245",
        "source" : "37112",
        "target" : "37366",
        "shared_name" : "C13H11O7 (interacts with) C12H11O5",
        "family_id" : 69,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H11O7 (interacts with) C12H11O5",
        "interaction" : "interacts with",
        "SUID" : 38245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38090",
        "source" : "37112",
        "target" : "37366",
        "shared_name" : "C13H11O7 (interacts with) C12H11O5",
        "family_id" : 56,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H11O7 (interacts with) C12H11O5",
        "interaction" : "interacts with",
        "SUID" : 38090,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37870",
        "source" : "37112",
        "target" : "37366",
        "shared_name" : "C13H11O7 (interacts with) C12H11O5",
        "family_id" : 53,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H11O7 (interacts with) C12H11O5",
        "interaction" : "interacts with",
        "SUID" : 37870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37718",
        "source" : "37112",
        "target" : "37366",
        "shared_name" : "C13H11O7 (interacts with) C12H11O5",
        "family_id" : 10,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H11O7 (interacts with) C12H11O5",
        "interaction" : "interacts with",
        "SUID" : 37718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37367",
        "source" : "37112",
        "target" : "37366",
        "shared_name" : "C13H11O7 (interacts with) C12H11O5",
        "family_id" : 184,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H11O7 (interacts with) C12H11O5",
        "interaction" : "interacts with",
        "SUID" : 37367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38211",
        "source" : "37110",
        "target" : "37192",
        "shared_name" : "C16H19O8 (interacts with) C15H19O6",
        "family_id" : 68,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O8 (interacts with) C15H19O6",
        "interaction" : "interacts with",
        "SUID" : 38211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38064",
        "source" : "37110",
        "target" : "36883",
        "shared_name" : "C16H19O8 (interacts with) C16H17O7",
        "family_id" : 301,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O8 (interacts with) C16H17O7",
        "interaction" : "interacts with",
        "SUID" : 38064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37580",
        "source" : "37110",
        "target" : "36883",
        "shared_name" : "C16H19O8 (interacts with) C16H17O7",
        "family_id" : 70,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O8 (interacts with) C16H17O7",
        "interaction" : "interacts with",
        "SUID" : 37580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38246",
        "source" : "37101",
        "target" : "36920",
        "shared_name" : "C19H21O12 (interacts with) C19H19O11",
        "family_id" : 159,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O12 (interacts with) C19H19O11",
        "interaction" : "interacts with",
        "SUID" : 38246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38123",
        "source" : "37101",
        "target" : "36920",
        "shared_name" : "C19H21O12 (interacts with) C19H19O11",
        "family_id" : 297,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O12 (interacts with) C19H19O11",
        "interaction" : "interacts with",
        "SUID" : 38123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37963",
        "source" : "37101",
        "target" : "37195",
        "shared_name" : "C19H21O12 (interacts with) C18H21O10",
        "family_id" : 174,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O12 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 37963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37933",
        "source" : "37101",
        "target" : "37195",
        "shared_name" : "C19H21O12 (interacts with) C18H21O10",
        "family_id" : 117,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O12 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 37933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37924",
        "source" : "37101",
        "target" : "37195",
        "shared_name" : "C19H21O12 (interacts with) C18H21O10",
        "family_id" : 73,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O12 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 37924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37897",
        "source" : "37101",
        "target" : "36920",
        "shared_name" : "C19H21O12 (interacts with) C19H19O11",
        "family_id" : 113,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O12 (interacts with) C19H19O11",
        "interaction" : "interacts with",
        "SUID" : 37897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37855",
        "source" : "37101",
        "target" : "37195",
        "shared_name" : "C19H21O12 (interacts with) C18H21O10",
        "family_id" : 13,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O12 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 37855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37730",
        "source" : "37101",
        "target" : "37195",
        "shared_name" : "C19H21O12 (interacts with) C18H21O10",
        "family_id" : 337,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O12 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 37730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37713",
        "source" : "37101",
        "target" : "37195",
        "shared_name" : "C19H21O12 (interacts with) C18H21O10",
        "family_id" : 72,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O12 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 37713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37675",
        "source" : "37101",
        "target" : "36920",
        "shared_name" : "C19H21O12 (interacts with) C19H19O11",
        "family_id" : 335,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O12 (interacts with) C19H19O11",
        "interaction" : "interacts with",
        "SUID" : 37675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37620",
        "source" : "37101",
        "target" : "36920",
        "shared_name" : "C19H21O12 (interacts with) C19H19O11",
        "family_id" : 180,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O12 (interacts with) C19H19O11",
        "interaction" : "interacts with",
        "SUID" : 37620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37243",
        "source" : "37101",
        "target" : "36920",
        "shared_name" : "C19H21O12 (interacts with) C19H19O11",
        "family_id" : 96,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O12 (interacts with) C19H19O11",
        "interaction" : "interacts with",
        "SUID" : 37243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37103",
        "source" : "37101",
        "target" : "36920",
        "shared_name" : "C19H21O12 (interacts with) C19H19O11",
        "family_id" : 5,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O12 (interacts with) C19H19O11",
        "interaction" : "interacts with",
        "SUID" : 37103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38206",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 297,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 38206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38194",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 96,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 38194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38192",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 337,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 38192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38188",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 335,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 38188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38149",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 174,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 38149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38096",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 13,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 38096,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37977",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 159,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 37977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37820",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 72,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 37820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37727",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 180,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 37727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37670",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 5,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 37670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37618",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 73,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 37618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37597",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 113,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 37597,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37102",
        "source" : "37100",
        "target" : "37101",
        "shared_name" : "C19H23O13 (interacts with) C19H21O12",
        "family_id" : 117,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O13 (interacts with) C19H21O12",
        "interaction" : "interacts with",
        "SUID" : 37102,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37946",
        "source" : "37097",
        "target" : "36844",
        "shared_name" : "C14H17O7 (interacts with) C14H15O6",
        "family_id" : 63,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H17O7 (interacts with) C14H15O6",
        "interaction" : "interacts with",
        "SUID" : 37946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37525",
        "source" : "37097",
        "target" : "36844",
        "shared_name" : "C14H17O7 (interacts with) C14H15O6",
        "family_id" : 232,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H17O7 (interacts with) C14H15O6",
        "interaction" : "interacts with",
        "SUID" : 37525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38038",
        "source" : "37096",
        "target" : "37097",
        "shared_name" : "C15H17O9 (interacts with) C14H17O7",
        "family_id" : 63,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O9 (interacts with) C14H17O7",
        "interaction" : "interacts with",
        "SUID" : 38038,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37926",
        "source" : "37096",
        "target" : "37052",
        "shared_name" : "C15H17O9 (interacts with) C15H15O8",
        "family_id" : 340,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O9 (interacts with) C15H15O8",
        "interaction" : "interacts with",
        "SUID" : 37926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37438",
        "source" : "37096",
        "target" : "37052",
        "shared_name" : "C15H17O9 (interacts with) C15H15O8",
        "family_id" : 109,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O9 (interacts with) C15H15O8",
        "interaction" : "interacts with",
        "SUID" : 37438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37258",
        "source" : "37096",
        "target" : "37052",
        "shared_name" : "C15H17O9 (interacts with) C15H15O8",
        "family_id" : 253,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O9 (interacts with) C15H15O8",
        "interaction" : "interacts with",
        "SUID" : 37258,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37098",
        "source" : "37096",
        "target" : "37097",
        "shared_name" : "C15H17O9 (interacts with) C14H17O7",
        "family_id" : 232,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O9 (interacts with) C14H17O7",
        "interaction" : "interacts with",
        "SUID" : 37098,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37207",
        "source" : "37093",
        "target" : "36970",
        "shared_name" : "C20H23O10 (interacts with) C19H23O8",
        "family_id" : 218,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O10 (interacts with) C19H23O8",
        "interaction" : "interacts with",
        "SUID" : 37207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37094",
        "source" : "37093",
        "target" : "36970",
        "shared_name" : "C20H23O10 (interacts with) C19H23O8",
        "family_id" : 83,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O10 (interacts with) C19H23O8",
        "interaction" : "interacts with",
        "SUID" : 37094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37925",
        "source" : "37091",
        "target" : "37344",
        "shared_name" : "C20H27O9 (interacts with) C20H25O8",
        "family_id" : 84,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H27O9 (interacts with) C20H25O8",
        "interaction" : "interacts with",
        "SUID" : 37925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37092",
        "source" : "37090",
        "target" : "37091",
        "shared_name" : "C21H27O11 (interacts with) C20H27O9",
        "family_id" : 84,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H27O11 (interacts with) C20H27O9",
        "interaction" : "interacts with",
        "SUID" : 37092,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38087",
        "source" : "37088",
        "target" : "36811",
        "shared_name" : "C20H19O11 (interacts with) C19H19O9",
        "family_id" : 239,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H19O11 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 38087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37325",
        "source" : "37088",
        "target" : "36811",
        "shared_name" : "C20H19O11 (interacts with) C19H19O9",
        "family_id" : 131,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H19O11 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 37325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37239",
        "source" : "37088",
        "target" : "36811",
        "shared_name" : "C20H19O11 (interacts with) C19H19O9",
        "family_id" : 219,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H19O11 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 37239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37089",
        "source" : "37088",
        "target" : "36811",
        "shared_name" : "C20H19O11 (interacts with) C19H19O9",
        "family_id" : 311,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H19O11 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 37089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37647",
        "source" : "37084",
        "target" : "36948",
        "shared_name" : "C17H25O10 (interacts with) C17H23O9",
        "family_id" : 151,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H25O10 (interacts with) C17H23O9",
        "interaction" : "interacts with",
        "SUID" : 37647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37544",
        "source" : "37084",
        "target" : "36948",
        "shared_name" : "C17H25O10 (interacts with) C17H23O9",
        "family_id" : 12,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H25O10 (interacts with) C17H23O9",
        "interaction" : "interacts with",
        "SUID" : 37544,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37507",
        "source" : "37084",
        "target" : "36948",
        "shared_name" : "C17H25O10 (interacts with) C17H23O9",
        "family_id" : 36,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H25O10 (interacts with) C17H23O9",
        "interaction" : "interacts with",
        "SUID" : 37507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37383",
        "source" : "37084",
        "target" : "36948",
        "shared_name" : "C17H25O10 (interacts with) C17H23O9",
        "family_id" : 166,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H25O10 (interacts with) C17H23O9",
        "interaction" : "interacts with",
        "SUID" : 37383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37107",
        "source" : "37084",
        "target" : "36948",
        "shared_name" : "C17H25O10 (interacts with) C17H23O9",
        "family_id" : 309,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H25O10 (interacts with) C17H23O9",
        "interaction" : "interacts with",
        "SUID" : 37107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37085",
        "source" : "37084",
        "target" : "36948",
        "shared_name" : "C17H25O10 (interacts with) C17H23O9",
        "family_id" : 289,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H25O10 (interacts with) C17H23O9",
        "interaction" : "interacts with",
        "SUID" : 37085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37563",
        "source" : "37081",
        "target" : "37562",
        "shared_name" : "C11H13O8 (interacts with) C11H11O7",
        "family_id" : 6,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C11H13O8 (interacts with) C11H11O7",
        "interaction" : "interacts with",
        "SUID" : 37563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37083",
        "source" : "37081",
        "target" : "37082",
        "shared_name" : "C11H13O8 (interacts with) C10H13O6",
        "family_id" : 32,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C11H13O8 (interacts with) C10H13O6",
        "interaction" : "interacts with",
        "SUID" : 37083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37080",
        "source" : "37078",
        "target" : "37079",
        "shared_name" : "C19H19O8 (interacts with) C18H19O6",
        "family_id" : 16,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O8 (interacts with) C18H19O6",
        "interaction" : "interacts with",
        "SUID" : 37080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37825",
        "source" : "37076",
        "target" : "37005",
        "shared_name" : "C18H17O9 (interacts with) C17H17O7",
        "family_id" : 283,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O9 (interacts with) C17H17O7",
        "interaction" : "interacts with",
        "SUID" : 37825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37743",
        "source" : "37076",
        "target" : "37252",
        "shared_name" : "C18H17O9 (interacts with) C18H15O8",
        "family_id" : 231,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H17O9 (interacts with) C18H15O8",
        "interaction" : "interacts with",
        "SUID" : 37743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37665",
        "source" : "37076",
        "target" : "37005",
        "shared_name" : "C18H17O9 (interacts with) C17H17O7",
        "family_id" : 296,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O9 (interacts with) C17H17O7",
        "interaction" : "interacts with",
        "SUID" : 37665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37539",
        "source" : "37076",
        "target" : "37005",
        "shared_name" : "C18H17O9 (interacts with) C17H17O7",
        "family_id" : 103,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O9 (interacts with) C17H17O7",
        "interaction" : "interacts with",
        "SUID" : 37539,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37418",
        "source" : "37076",
        "target" : "37005",
        "shared_name" : "C18H17O9 (interacts with) C17H17O7",
        "family_id" : 216,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O9 (interacts with) C17H17O7",
        "interaction" : "interacts with",
        "SUID" : 37418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37282",
        "source" : "37076",
        "target" : "37005",
        "shared_name" : "C18H17O9 (interacts with) C17H17O7",
        "family_id" : 76,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O9 (interacts with) C17H17O7",
        "interaction" : "interacts with",
        "SUID" : 37282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37143",
        "source" : "37076",
        "target" : "37005",
        "shared_name" : "C18H17O9 (interacts with) C17H17O7",
        "family_id" : 211,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O9 (interacts with) C17H17O7",
        "interaction" : "interacts with",
        "SUID" : 37143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38042",
        "source" : "37075",
        "target" : "37076",
        "shared_name" : "C18H19O10 (interacts with) C18H17O9",
        "family_id" : 231,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O10 (interacts with) C18H17O9",
        "interaction" : "interacts with",
        "SUID" : 38042,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37886",
        "source" : "37075",
        "target" : "37004",
        "shared_name" : "C18H19O10 (interacts with) C17H19O8",
        "family_id" : 201,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O10 (interacts with) C17H19O8",
        "interaction" : "interacts with",
        "SUID" : 37886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37868",
        "source" : "37075",
        "target" : "37004",
        "shared_name" : "C18H19O10 (interacts with) C17H19O8",
        "family_id" : 61,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O10 (interacts with) C17H19O8",
        "interaction" : "interacts with",
        "SUID" : 37868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37773",
        "source" : "37075",
        "target" : "37076",
        "shared_name" : "C18H19O10 (interacts with) C18H17O9",
        "family_id" : 216,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O10 (interacts with) C18H17O9",
        "interaction" : "interacts with",
        "SUID" : 37773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37666",
        "source" : "37075",
        "target" : "37076",
        "shared_name" : "C18H19O10 (interacts with) C18H17O9",
        "family_id" : 76,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O10 (interacts with) C18H17O9",
        "interaction" : "interacts with",
        "SUID" : 37666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37077",
        "source" : "37075",
        "target" : "37076",
        "shared_name" : "C18H19O10 (interacts with) C18H17O9",
        "family_id" : 211,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O10 (interacts with) C18H17O9",
        "interaction" : "interacts with",
        "SUID" : 37077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38104",
        "source" : "37073",
        "target" : "36841",
        "shared_name" : "C18H21O13 (interacts with) C18H19O12",
        "family_id" : 312,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O13 (interacts with) C18H19O12",
        "interaction" : "interacts with",
        "SUID" : 38104,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37683",
        "source" : "37073",
        "target" : "36841",
        "shared_name" : "C18H21O13 (interacts with) C18H19O12",
        "family_id" : 288,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O13 (interacts with) C18H19O12",
        "interaction" : "interacts with",
        "SUID" : 37683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37648",
        "source" : "37073",
        "target" : "36841",
        "shared_name" : "C18H21O13 (interacts with) C18H19O12",
        "family_id" : 244,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O13 (interacts with) C18H19O12",
        "interaction" : "interacts with",
        "SUID" : 37648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37173",
        "source" : "37073",
        "target" : "36841",
        "shared_name" : "C18H21O13 (interacts with) C18H19O12",
        "family_id" : 256,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O13 (interacts with) C18H19O12",
        "interaction" : "interacts with",
        "SUID" : 37173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37074",
        "source" : "37073",
        "target" : "36841",
        "shared_name" : "C18H21O13 (interacts with) C18H19O12",
        "family_id" : 115,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O13 (interacts with) C18H19O12",
        "interaction" : "interacts with",
        "SUID" : 37074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38210",
        "source" : "37070",
        "target" : "37769",
        "shared_name" : "C12H17O7 (interacts with) C11H17O5",
        "family_id" : 81,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H17O7 (interacts with) C11H17O5",
        "interaction" : "interacts with",
        "SUID" : 38210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37770",
        "source" : "37070",
        "target" : "37769",
        "shared_name" : "C12H17O7 (interacts with) C11H17O5",
        "family_id" : 123,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H17O7 (interacts with) C11H17O5",
        "interaction" : "interacts with",
        "SUID" : 37770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37072",
        "source" : "37070",
        "target" : "37071",
        "shared_name" : "C12H17O7 (interacts with) C12H15O6",
        "family_id" : 329,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H17O7 (interacts with) C12H15O6",
        "interaction" : "interacts with",
        "SUID" : 37072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38019",
        "source" : "37067",
        "target" : "37068",
        "shared_name" : "C18H17O8 (interacts with) C17H17O6",
        "family_id" : 72,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O8 (interacts with) C17H17O6",
        "interaction" : "interacts with",
        "SUID" : 38019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37590",
        "source" : "37067",
        "target" : "37068",
        "shared_name" : "C18H17O8 (interacts with) C17H17O6",
        "family_id" : 299,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O8 (interacts with) C17H17O6",
        "interaction" : "interacts with",
        "SUID" : 37590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37381",
        "source" : "37067",
        "target" : "37068",
        "shared_name" : "C18H17O8 (interacts with) C17H17O6",
        "family_id" : 77,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O8 (interacts with) C17H17O6",
        "interaction" : "interacts with",
        "SUID" : 37381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37321",
        "source" : "37067",
        "target" : "37068",
        "shared_name" : "C18H17O8 (interacts with) C17H17O6",
        "family_id" : 125,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O8 (interacts with) C17H17O6",
        "interaction" : "interacts with",
        "SUID" : 37321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37166",
        "source" : "37067",
        "target" : "37068",
        "shared_name" : "C18H17O8 (interacts with) C17H17O6",
        "family_id" : 46,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O8 (interacts with) C17H17O6",
        "interaction" : "interacts with",
        "SUID" : 37166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37069",
        "source" : "37067",
        "target" : "37068",
        "shared_name" : "C18H17O8 (interacts with) C17H17O6",
        "family_id" : 159,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O8 (interacts with) C17H17O6",
        "interaction" : "interacts with",
        "SUID" : 37069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38150",
        "source" : "37063",
        "target" : "37064",
        "shared_name" : "C13H11O8 (interacts with) C12H11O6",
        "family_id" : 258,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H11O8 (interacts with) C12H11O6",
        "interaction" : "interacts with",
        "SUID" : 38150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37869",
        "source" : "37063",
        "target" : "37064",
        "shared_name" : "C13H11O8 (interacts with) C12H11O6",
        "family_id" : 91,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H11O8 (interacts with) C12H11O6",
        "interaction" : "interacts with",
        "SUID" : 37869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37804",
        "source" : "37063",
        "target" : "37803",
        "shared_name" : "C13H11O8 (interacts with) C13H9O7",
        "family_id" : 213,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H11O8 (interacts with) C13H9O7",
        "interaction" : "interacts with",
        "SUID" : 37804,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37065",
        "source" : "37063",
        "target" : "37064",
        "shared_name" : "C13H11O8 (interacts with) C12H11O6",
        "family_id" : 313,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H11O8 (interacts with) C12H11O6",
        "interaction" : "interacts with",
        "SUID" : 37065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38202",
        "source" : "37060",
        "target" : "38201",
        "shared_name" : "C18H25O9 (interacts with) C17H25O7",
        "family_id" : 141,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H25O9 (interacts with) C17H25O7",
        "interaction" : "interacts with",
        "SUID" : 38202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38157",
        "source" : "37055",
        "target" : "37224",
        "shared_name" : "C19H25O10 (interacts with) C18H25O8",
        "family_id" : 332,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H25O10 (interacts with) C18H25O8",
        "interaction" : "interacts with",
        "SUID" : 38157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37940",
        "source" : "37055",
        "target" : "37224",
        "shared_name" : "C19H25O10 (interacts with) C18H25O8",
        "family_id" : 323,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H25O10 (interacts with) C18H25O8",
        "interaction" : "interacts with",
        "SUID" : 37940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37473",
        "source" : "37055",
        "target" : "37298",
        "shared_name" : "C19H25O10 (interacts with) C19H23O9",
        "family_id" : 86,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O10 (interacts with) C19H23O9",
        "interaction" : "interacts with",
        "SUID" : 37473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37225",
        "source" : "37055",
        "target" : "37224",
        "shared_name" : "C19H25O10 (interacts with) C18H25O8",
        "family_id" : 52,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H25O10 (interacts with) C18H25O8",
        "interaction" : "interacts with",
        "SUID" : 37225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38205",
        "source" : "37054",
        "target" : "37229",
        "shared_name" : "C20H25O12 (interacts with) C20H23O11",
        "family_id" : 143,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O12 (interacts with) C20H23O11",
        "interaction" : "interacts with",
        "SUID" : 38205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38082",
        "source" : "37054",
        "target" : "37055",
        "shared_name" : "C20H25O12 (interacts with) C19H25O10",
        "family_id" : 52,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O12 (interacts with) C19H25O10",
        "interaction" : "interacts with",
        "SUID" : 38082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37909",
        "source" : "37054",
        "target" : "37055",
        "shared_name" : "C20H25O12 (interacts with) C19H25O10",
        "family_id" : 332,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O12 (interacts with) C19H25O10",
        "interaction" : "interacts with",
        "SUID" : 37909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37558",
        "source" : "37054",
        "target" : "37229",
        "shared_name" : "C20H25O12 (interacts with) C20H23O11",
        "family_id" : 310,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O12 (interacts with) C20H23O11",
        "interaction" : "interacts with",
        "SUID" : 37558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37486",
        "source" : "37054",
        "target" : "37055",
        "shared_name" : "C20H25O12 (interacts with) C19H25O10",
        "family_id" : 323,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O12 (interacts with) C19H25O10",
        "interaction" : "interacts with",
        "SUID" : 37486,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37320",
        "source" : "37054",
        "target" : "37229",
        "shared_name" : "C20H25O12 (interacts with) C20H23O11",
        "family_id" : 333,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O12 (interacts with) C20H23O11",
        "interaction" : "interacts with",
        "SUID" : 37320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37056",
        "source" : "37054",
        "target" : "37055",
        "shared_name" : "C20H25O12 (interacts with) C19H25O10",
        "family_id" : 86,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O12 (interacts with) C19H25O10",
        "interaction" : "interacts with",
        "SUID" : 37056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37954",
        "source" : "37052",
        "target" : "36844",
        "shared_name" : "C15H15O8 (interacts with) C14H15O6",
        "family_id" : 253,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O8 (interacts with) C14H15O6",
        "interaction" : "interacts with",
        "SUID" : 37954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37726",
        "source" : "37052",
        "target" : "36844",
        "shared_name" : "C15H15O8 (interacts with) C14H15O6",
        "family_id" : 275,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O8 (interacts with) C14H15O6",
        "interaction" : "interacts with",
        "SUID" : 37726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37667",
        "source" : "37052",
        "target" : "36844",
        "shared_name" : "C15H15O8 (interacts with) C14H15O6",
        "family_id" : 121,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O8 (interacts with) C14H15O6",
        "interaction" : "interacts with",
        "SUID" : 37667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37644",
        "source" : "37052",
        "target" : "36844",
        "shared_name" : "C15H15O8 (interacts with) C14H15O6",
        "family_id" : 75,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O8 (interacts with) C14H15O6",
        "interaction" : "interacts with",
        "SUID" : 37644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37145",
        "source" : "37052",
        "target" : "37010",
        "shared_name" : "C15H15O8 (interacts with) C15H13O7",
        "family_id" : 109,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H15O8 (interacts with) C15H13O7",
        "interaction" : "interacts with",
        "SUID" : 37145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37137",
        "source" : "37052",
        "target" : "37010",
        "shared_name" : "C15H15O8 (interacts with) C15H13O7",
        "family_id" : 316,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H15O8 (interacts with) C15H13O7",
        "interaction" : "interacts with",
        "SUID" : 37137,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37135",
        "source" : "37052",
        "target" : "36966",
        "shared_name" : "C15H15O8 (interacts with) C14H11O7",
        "family_id" : 22,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C15H15O8 (interacts with) C14H11O7",
        "interaction" : "interacts with",
        "SUID" : 37135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37109",
        "source" : "37052",
        "target" : "36844",
        "shared_name" : "C15H15O8 (interacts with) C14H15O6",
        "family_id" : 340,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O8 (interacts with) C14H15O6",
        "interaction" : "interacts with",
        "SUID" : 37109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38015",
        "source" : "37050",
        "target" : "38014",
        "shared_name" : "C12H15O8 (interacts with) C11H15O6",
        "family_id" : 20,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H15O8 (interacts with) C11H15O6",
        "interaction" : "interacts with",
        "SUID" : 38015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37134",
        "source" : "37050",
        "target" : "37133",
        "shared_name" : "C12H15O8 (interacts with) C12H13O7",
        "family_id" : 92,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H15O8 (interacts with) C12H13O7",
        "interaction" : "interacts with",
        "SUID" : 37134,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38174",
        "source" : "37046",
        "target" : "36944",
        "shared_name" : "C16H11O10 (interacts with) C15H11O8",
        "family_id" : 149,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O10 (interacts with) C15H11O8",
        "interaction" : "interacts with",
        "SUID" : 38174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38129",
        "source" : "37046",
        "target" : "36944",
        "shared_name" : "C16H11O10 (interacts with) C15H11O8",
        "family_id" : 325,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O10 (interacts with) C15H11O8",
        "interaction" : "interacts with",
        "SUID" : 38129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37815",
        "source" : "37046",
        "target" : "37556",
        "shared_name" : "C16H11O10 (interacts with) C16H9O9",
        "family_id" : 154,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H11O10 (interacts with) C16H9O9",
        "interaction" : "interacts with",
        "SUID" : 37815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37749",
        "source" : "37046",
        "target" : "36944",
        "shared_name" : "C16H11O10 (interacts with) C15H11O8",
        "family_id" : 153,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O10 (interacts with) C15H11O8",
        "interaction" : "interacts with",
        "SUID" : 37749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37561",
        "source" : "37046",
        "target" : "36944",
        "shared_name" : "C16H11O10 (interacts with) C15H11O8",
        "family_id" : 130,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O10 (interacts with) C15H11O8",
        "interaction" : "interacts with",
        "SUID" : 37561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37557",
        "source" : "37046",
        "target" : "37556",
        "shared_name" : "C16H11O10 (interacts with) C16H9O9",
        "family_id" : 122,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H11O10 (interacts with) C16H9O9",
        "interaction" : "interacts with",
        "SUID" : 37557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38203",
        "source" : "37045",
        "target" : "37046",
        "shared_name" : "C17H11O12 (interacts with) C16H11O10",
        "family_id" : 130,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O12 (interacts with) C16H11O10",
        "interaction" : "interacts with",
        "SUID" : 38203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38189",
        "source" : "37045",
        "target" : "37046",
        "shared_name" : "C17H11O12 (interacts with) C16H11O10",
        "family_id" : 154,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O12 (interacts with) C16H11O10",
        "interaction" : "interacts with",
        "SUID" : 38189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37965",
        "source" : "37045",
        "target" : "37046",
        "shared_name" : "C17H11O12 (interacts with) C16H11O10",
        "family_id" : 325,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O12 (interacts with) C16H11O10",
        "interaction" : "interacts with",
        "SUID" : 37965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37535",
        "source" : "37045",
        "target" : "37046",
        "shared_name" : "C17H11O12 (interacts with) C16H11O10",
        "family_id" : 122,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O12 (interacts with) C16H11O10",
        "interaction" : "interacts with",
        "SUID" : 37535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37047",
        "source" : "37045",
        "target" : "37046",
        "shared_name" : "C17H11O12 (interacts with) C16H11O10",
        "family_id" : 153,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O12 (interacts with) C16H11O10",
        "interaction" : "interacts with",
        "SUID" : 37047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37712",
        "source" : "37043",
        "target" : "36916",
        "shared_name" : "C15H13O10 (interacts with) C15H11O9",
        "family_id" : 250,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H13O10 (interacts with) C15H11O9",
        "interaction" : "interacts with",
        "SUID" : 37712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37044",
        "source" : "37043",
        "target" : "36916",
        "shared_name" : "C15H13O10 (interacts with) C15H11O9",
        "family_id" : 110,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H13O10 (interacts with) C15H11O9",
        "interaction" : "interacts with",
        "SUID" : 37044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38079",
        "source" : "37041",
        "target" : "37052",
        "shared_name" : "C16H15O10 (interacts with) C15H15O8",
        "family_id" : 316,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O10 (interacts with) C15H15O8",
        "interaction" : "interacts with",
        "SUID" : 38079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37978",
        "source" : "37041",
        "target" : "36870",
        "shared_name" : "C16H15O10 (interacts with) C16H13O9",
        "family_id" : 172,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H15O10 (interacts with) C16H13O9",
        "interaction" : "interacts with",
        "SUID" : 37978,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37971",
        "source" : "37041",
        "target" : "37052",
        "shared_name" : "C16H15O10 (interacts with) C15H15O8",
        "family_id" : 75,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O10 (interacts with) C15H15O8",
        "interaction" : "interacts with",
        "SUID" : 37971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37953",
        "source" : "37041",
        "target" : "37052",
        "shared_name" : "C16H15O10 (interacts with) C15H15O8",
        "family_id" : 121,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O10 (interacts with) C15H15O8",
        "interaction" : "interacts with",
        "SUID" : 37953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37872",
        "source" : "37041",
        "target" : "36870",
        "shared_name" : "C16H15O10 (interacts with) C16H13O9",
        "family_id" : 269,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H15O10 (interacts with) C16H13O9",
        "interaction" : "interacts with",
        "SUID" : 37872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38016",
        "source" : "37037",
        "target" : "37205",
        "shared_name" : "C20H25O11 (interacts with) C19H25O9",
        "family_id" : 40,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O11 (interacts with) C19H25O9",
        "interaction" : "interacts with",
        "SUID" : 38016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37903",
        "source" : "37037",
        "target" : "37093",
        "shared_name" : "C20H25O11 (interacts with) C20H23O10",
        "family_id" : 217,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O11 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 37903,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37801",
        "source" : "37037",
        "target" : "37205",
        "shared_name" : "C20H25O11 (interacts with) C19H25O9",
        "family_id" : 35,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O11 (interacts with) C19H25O9",
        "interaction" : "interacts with",
        "SUID" : 37801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37746",
        "source" : "37037",
        "target" : "37093",
        "shared_name" : "C20H25O11 (interacts with) C20H23O10",
        "family_id" : 83,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O11 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 37746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37700",
        "source" : "37037",
        "target" : "37205",
        "shared_name" : "C20H25O11 (interacts with) C19H25O9",
        "family_id" : 78,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O11 (interacts with) C19H25O9",
        "interaction" : "interacts with",
        "SUID" : 37700,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37223",
        "source" : "37037",
        "target" : "37093",
        "shared_name" : "C20H25O11 (interacts with) C20H23O10",
        "family_id" : 218,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O11 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 37223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38089",
        "source" : "37036",
        "target" : "37037",
        "shared_name" : "C20H27O12 (interacts with) C20H25O11",
        "family_id" : 83,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H27O12 (interacts with) C20H25O11",
        "interaction" : "interacts with",
        "SUID" : 38089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38084",
        "source" : "37036",
        "target" : "37037",
        "shared_name" : "C20H27O12 (interacts with) C20H25O11",
        "family_id" : 169,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H27O12 (interacts with) C20H25O11",
        "interaction" : "interacts with",
        "SUID" : 38084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38035",
        "source" : "37036",
        "target" : "37197",
        "shared_name" : "C20H27O12 (interacts with) C19H27O10",
        "family_id" : 318,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H27O12 (interacts with) C19H27O10",
        "interaction" : "interacts with",
        "SUID" : 38035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37871",
        "source" : "37036",
        "target" : "37197",
        "shared_name" : "C20H27O12 (interacts with) C19H27O10",
        "family_id" : 50,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H27O12 (interacts with) C19H27O10",
        "interaction" : "interacts with",
        "SUID" : 37871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37786",
        "source" : "37036",
        "target" : "37037",
        "shared_name" : "C20H27O12 (interacts with) C20H25O11",
        "family_id" : 35,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H27O12 (interacts with) C20H25O11",
        "interaction" : "interacts with",
        "SUID" : 37786,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37750",
        "source" : "37036",
        "target" : "37037",
        "shared_name" : "C20H27O12 (interacts with) C20H25O11",
        "family_id" : 218,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H27O12 (interacts with) C20H25O11",
        "interaction" : "interacts with",
        "SUID" : 37750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37527",
        "source" : "37036",
        "target" : "37197",
        "shared_name" : "C20H27O12 (interacts with) C19H27O10",
        "family_id" : 64,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H27O12 (interacts with) C19H27O10",
        "interaction" : "interacts with",
        "SUID" : 37527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37476",
        "source" : "37036",
        "target" : "37037",
        "shared_name" : "C20H27O12 (interacts with) C20H25O11",
        "family_id" : 78,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H27O12 (interacts with) C20H25O11",
        "interaction" : "interacts with",
        "SUID" : 37476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37198",
        "source" : "37036",
        "target" : "37197",
        "shared_name" : "C20H27O12 (interacts with) C19H27O10",
        "family_id" : 252,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H27O12 (interacts with) C19H27O10",
        "interaction" : "interacts with",
        "SUID" : 37198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37095",
        "source" : "37036",
        "target" : "37037",
        "shared_name" : "C20H27O12 (interacts with) C20H25O11",
        "family_id" : 40,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H27O12 (interacts with) C20H25O11",
        "interaction" : "interacts with",
        "SUID" : 37095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37038",
        "source" : "37036",
        "target" : "37037",
        "shared_name" : "C20H27O12 (interacts with) C20H25O11",
        "family_id" : 217,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H27O12 (interacts with) C20H25O11",
        "interaction" : "interacts with",
        "SUID" : 37038,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38032",
        "source" : "37030",
        "target" : "37063",
        "shared_name" : "C13H13O9 (interacts with) C13H11O8",
        "family_id" : 91,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H13O9 (interacts with) C13H11O8",
        "interaction" : "interacts with",
        "SUID" : 38032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37845",
        "source" : "37030",
        "target" : "37133",
        "shared_name" : "C13H13O9 (interacts with) C12H13O7",
        "family_id" : 242,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H13O9 (interacts with) C12H13O7",
        "interaction" : "interacts with",
        "SUID" : 37845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37610",
        "source" : "37029",
        "target" : "37030",
        "shared_name" : "C13H15O10 (interacts with) C13H13O9",
        "family_id" : 242,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H15O10 (interacts with) C13H13O9",
        "interaction" : "interacts with",
        "SUID" : 37610,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37165",
        "source" : "37029",
        "target" : "37050",
        "shared_name" : "C13H15O10 (interacts with) C12H15O8",
        "family_id" : 20,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H15O10 (interacts with) C12H15O8",
        "interaction" : "interacts with",
        "SUID" : 37165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37117",
        "source" : "37029",
        "target" : "37030",
        "shared_name" : "C13H15O10 (interacts with) C13H13O9",
        "family_id" : 43,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H15O10 (interacts with) C13H13O9",
        "interaction" : "interacts with",
        "SUID" : 37117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37051",
        "source" : "37029",
        "target" : "37050",
        "shared_name" : "C13H15O10 (interacts with) C12H15O8",
        "family_id" : 92,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H15O10 (interacts with) C12H15O8",
        "interaction" : "interacts with",
        "SUID" : 37051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37031",
        "source" : "37029",
        "target" : "37030",
        "shared_name" : "C13H15O10 (interacts with) C13H13O9",
        "family_id" : 91,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H15O10 (interacts with) C13H13O9",
        "interaction" : "interacts with",
        "SUID" : 37031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38166",
        "source" : "37026",
        "target" : "38165",
        "shared_name" : "C18H23O7 (interacts with) C18H21O6",
        "family_id" : 332,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O7 (interacts with) C18H21O6",
        "interaction" : "interacts with",
        "SUID" : 38166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38003",
        "source" : "37026",
        "target" : "37027",
        "shared_name" : "C18H23O7 (interacts with) C17H23O5",
        "family_id" : 86,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O7 (interacts with) C17H23O5",
        "interaction" : "interacts with",
        "SUID" : 38003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37386",
        "source" : "37026",
        "target" : "37027",
        "shared_name" : "C18H23O7 (interacts with) C17H23O5",
        "family_id" : 310,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O7 (interacts with) C17H23O5",
        "interaction" : "interacts with",
        "SUID" : 37386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37028",
        "source" : "37026",
        "target" : "37027",
        "shared_name" : "C18H23O7 (interacts with) C17H23O5",
        "family_id" : 52,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O7 (interacts with) C17H23O5",
        "interaction" : "interacts with",
        "SUID" : 37028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38148",
        "source" : "37024",
        "target" : "37434",
        "shared_name" : "C19H19O12 (interacts with) C19H17O11",
        "family_id" : 283,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H19O12 (interacts with) C19H17O11",
        "interaction" : "interacts with",
        "SUID" : 38148,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37979",
        "source" : "37024",
        "target" : "37075",
        "shared_name" : "C19H19O12 (interacts with) C18H19O10",
        "family_id" : 231,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O12 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 37979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37935",
        "source" : "37024",
        "target" : "37075",
        "shared_name" : "C19H19O12 (interacts with) C18H19O10",
        "family_id" : 76,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O12 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 37935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38162",
        "source" : "37023",
        "target" : "36984",
        "shared_name" : "C19H21O13 (interacts with) C18H21O11",
        "family_id" : 216,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O13 (interacts with) C18H21O11",
        "interaction" : "interacts with",
        "SUID" : 38162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38101",
        "source" : "37023",
        "target" : "36984",
        "shared_name" : "C19H21O13 (interacts with) C18H21O11",
        "family_id" : 61,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O13 (interacts with) C18H21O11",
        "interaction" : "interacts with",
        "SUID" : 38101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37947",
        "source" : "37023",
        "target" : "36984",
        "shared_name" : "C19H21O13 (interacts with) C18H21O11",
        "family_id" : 211,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O13 (interacts with) C18H21O11",
        "interaction" : "interacts with",
        "SUID" : 37947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37927",
        "source" : "37023",
        "target" : "36984",
        "shared_name" : "C19H21O13 (interacts with) C18H21O11",
        "family_id" : 241,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O13 (interacts with) C18H21O11",
        "interaction" : "interacts with",
        "SUID" : 37927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37540",
        "source" : "37023",
        "target" : "36984",
        "shared_name" : "C19H21O13 (interacts with) C18H21O11",
        "family_id" : 201,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O13 (interacts with) C18H21O11",
        "interaction" : "interacts with",
        "SUID" : 37540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37267",
        "source" : "37023",
        "target" : "36984",
        "shared_name" : "C19H21O13 (interacts with) C18H21O11",
        "family_id" : 338,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O13 (interacts with) C18H21O11",
        "interaction" : "interacts with",
        "SUID" : 37267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37062",
        "source" : "37023",
        "target" : "37024",
        "shared_name" : "C19H21O13 (interacts with) C19H19O12",
        "family_id" : 76,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O13 (interacts with) C19H19O12",
        "interaction" : "interacts with",
        "SUID" : 37062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37048",
        "source" : "37023",
        "target" : "36984",
        "shared_name" : "C19H21O13 (interacts with) C18H21O11",
        "family_id" : 285,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O13 (interacts with) C18H21O11",
        "interaction" : "interacts with",
        "SUID" : 37048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37025",
        "source" : "37023",
        "target" : "37024",
        "shared_name" : "C19H21O13 (interacts with) C19H19O12",
        "family_id" : 283,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O13 (interacts with) C19H19O12",
        "interaction" : "interacts with",
        "SUID" : 37025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38106",
        "source" : "37021",
        "target" : "36956",
        "shared_name" : "C16H23O9 (interacts with) C16H21O8",
        "family_id" : 336,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H23O9 (interacts with) C16H21O8",
        "interaction" : "interacts with",
        "SUID" : 38106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38068",
        "source" : "37021",
        "target" : "36956",
        "shared_name" : "C16H23O9 (interacts with) C16H21O8",
        "family_id" : 249,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H23O9 (interacts with) C16H21O8",
        "interaction" : "interacts with",
        "SUID" : 38068,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38004",
        "source" : "37021",
        "target" : "36956",
        "shared_name" : "C16H23O9 (interacts with) C16H21O8",
        "family_id" : 191,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H23O9 (interacts with) C16H21O8",
        "interaction" : "interacts with",
        "SUID" : 38004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37857",
        "source" : "37021",
        "target" : "36956",
        "shared_name" : "C16H23O9 (interacts with) C16H21O8",
        "family_id" : 254,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H23O9 (interacts with) C16H21O8",
        "interaction" : "interacts with",
        "SUID" : 37857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37674",
        "source" : "37021",
        "target" : "36956",
        "shared_name" : "C16H23O9 (interacts with) C16H21O8",
        "family_id" : 290,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H23O9 (interacts with) C16H21O8",
        "interaction" : "interacts with",
        "SUID" : 37674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37902",
        "source" : "37020",
        "target" : "37021",
        "shared_name" : "C17H23O11 (interacts with) C16H23O9",
        "family_id" : 249,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H23O11 (interacts with) C16H23O9",
        "interaction" : "interacts with",
        "SUID" : 37902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37779",
        "source" : "37020",
        "target" : "37021",
        "shared_name" : "C17H23O11 (interacts with) C16H23O9",
        "family_id" : 290,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H23O11 (interacts with) C16H23O9",
        "interaction" : "interacts with",
        "SUID" : 37779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37689",
        "source" : "37020",
        "target" : "37021",
        "shared_name" : "C17H23O11 (interacts with) C16H23O9",
        "family_id" : 254,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H23O11 (interacts with) C16H23O9",
        "interaction" : "interacts with",
        "SUID" : 37689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37537",
        "source" : "37020",
        "target" : "37021",
        "shared_name" : "C17H23O11 (interacts with) C16H23O9",
        "family_id" : 191,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H23O11 (interacts with) C16H23O9",
        "interaction" : "interacts with",
        "SUID" : 37537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37289",
        "source" : "37020",
        "target" : "37021",
        "shared_name" : "C17H23O11 (interacts with) C16H23O9",
        "family_id" : 336,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H23O11 (interacts with) C16H23O9",
        "interaction" : "interacts with",
        "SUID" : 37289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37022",
        "source" : "37020",
        "target" : "37021",
        "shared_name" : "C17H23O11 (interacts with) C16H23O9",
        "family_id" : 163,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H23O11 (interacts with) C16H23O9",
        "interaction" : "interacts with",
        "SUID" : 37022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38236",
        "source" : "37018",
        "target" : "36909",
        "shared_name" : "C15H21O9 (interacts with) C15H19O8",
        "family_id" : 4,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O9 (interacts with) C15H19O8",
        "interaction" : "interacts with",
        "SUID" : 38236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37996",
        "source" : "37018",
        "target" : "36909",
        "shared_name" : "C15H21O9 (interacts with) C15H19O8",
        "family_id" : 262,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O9 (interacts with) C15H19O8",
        "interaction" : "interacts with",
        "SUID" : 37996,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37261",
        "source" : "37018",
        "target" : "36909",
        "shared_name" : "C15H21O9 (interacts with) C15H19O8",
        "family_id" : 248,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O9 (interacts with) C15H19O8",
        "interaction" : "interacts with",
        "SUID" : 37261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37251",
        "source" : "37018",
        "target" : "36909",
        "shared_name" : "C15H21O9 (interacts with) C15H19O8",
        "family_id" : 134,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O9 (interacts with) C15H19O8",
        "interaction" : "interacts with",
        "SUID" : 37251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37019",
        "source" : "37018",
        "target" : "36909",
        "shared_name" : "C15H21O9 (interacts with) C15H19O8",
        "family_id" : 215,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O9 (interacts with) C15H19O8",
        "interaction" : "interacts with",
        "SUID" : 37019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37818",
        "source" : "37015",
        "target" : "36860",
        "shared_name" : "C18H11O12 (interacts with) C17H11O10",
        "family_id" : 171,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H11O12 (interacts with) C17H11O10",
        "interaction" : "interacts with",
        "SUID" : 37818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37378",
        "source" : "37015",
        "target" : "36860",
        "shared_name" : "C18H11O12 (interacts with) C17H11O10",
        "family_id" : 263,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H11O12 (interacts with) C17H11O10",
        "interaction" : "interacts with",
        "SUID" : 37378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37016",
        "source" : "37015",
        "target" : "36860",
        "shared_name" : "C18H11O12 (interacts with) C17H11O10",
        "family_id" : 57,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H11O12 (interacts with) C17H11O10",
        "interaction" : "interacts with",
        "SUID" : 37016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37014",
        "source" : "37012",
        "target" : "37013",
        "shared_name" : "C19H17O9 (interacts with) C18H17O7",
        "family_id" : 99,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H17O9 (interacts with) C18H17O7",
        "interaction" : "interacts with",
        "SUID" : 37014,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38218",
        "source" : "37010",
        "target" : "36845",
        "shared_name" : "C15H13O7 (interacts with) C14H13O5",
        "family_id" : 109,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H13O7 (interacts with) C14H13O5",
        "interaction" : "interacts with",
        "SUID" : 38218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37936",
        "source" : "37010",
        "target" : "37513",
        "shared_name" : "C15H13O7 (interacts with) C15H11O6",
        "family_id" : 269,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H13O7 (interacts with) C15H11O6",
        "interaction" : "interacts with",
        "SUID" : 37936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37690",
        "source" : "37010",
        "target" : "37513",
        "shared_name" : "C15H13O7 (interacts with) C15H11O6",
        "family_id" : 172,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H13O7 (interacts with) C15H11O6",
        "interaction" : "interacts with",
        "SUID" : 37690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37515",
        "source" : "37010",
        "target" : "36845",
        "shared_name" : "C15H13O7 (interacts with) C14H13O5",
        "family_id" : 316,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H13O7 (interacts with) C14H13O5",
        "interaction" : "interacts with",
        "SUID" : 37515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37514",
        "source" : "37010",
        "target" : "37513",
        "shared_name" : "C15H13O7 (interacts with) C15H11O6",
        "family_id" : 0,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H13O7 (interacts with) C15H11O6",
        "interaction" : "interacts with",
        "SUID" : 37514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37761",
        "source" : "37007",
        "target" : "36833",
        "shared_name" : "C15H15O9 (interacts with) C14H15O7",
        "family_id" : 100,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O9 (interacts with) C14H15O7",
        "interaction" : "interacts with",
        "SUID" : 37761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37673",
        "source" : "37007",
        "target" : "36833",
        "shared_name" : "C15H15O9 (interacts with) C14H15O7",
        "family_id" : 58,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O9 (interacts with) C14H15O7",
        "interaction" : "interacts with",
        "SUID" : 37673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37629",
        "source" : "37007",
        "target" : "36833",
        "shared_name" : "C15H15O9 (interacts with) C14H15O7",
        "family_id" : 319,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O9 (interacts with) C14H15O7",
        "interaction" : "interacts with",
        "SUID" : 37629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37480",
        "source" : "37007",
        "target" : "37392",
        "shared_name" : "C15H15O9 (interacts with) C15H13O8",
        "family_id" : 28,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H15O9 (interacts with) C15H13O8",
        "interaction" : "interacts with",
        "SUID" : 37480,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38163",
        "source" : "37005",
        "target" : "37253",
        "shared_name" : "C17H17O7 (interacts with) C17H15O6",
        "family_id" : 283,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H17O7 (interacts with) C17H15O6",
        "interaction" : "interacts with",
        "SUID" : 38163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38044",
        "source" : "37005",
        "target" : "36887",
        "shared_name" : "C17H17O7 (interacts with) C16H17O5",
        "family_id" : 201,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O7 (interacts with) C16H17O5",
        "interaction" : "interacts with",
        "SUID" : 38044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37988",
        "source" : "37005",
        "target" : "37253",
        "shared_name" : "C17H17O7 (interacts with) C17H15O6",
        "family_id" : 216,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H17O7 (interacts with) C17H15O6",
        "interaction" : "interacts with",
        "SUID" : 37988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37904",
        "source" : "37005",
        "target" : "36887",
        "shared_name" : "C17H17O7 (interacts with) C16H17O5",
        "family_id" : 103,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O7 (interacts with) C16H17O5",
        "interaction" : "interacts with",
        "SUID" : 37904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37881",
        "source" : "37005",
        "target" : "37253",
        "shared_name" : "C17H17O7 (interacts with) C17H15O6",
        "family_id" : 76,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H17O7 (interacts with) C17H15O6",
        "interaction" : "interacts with",
        "SUID" : 37881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37688",
        "source" : "37005",
        "target" : "36887",
        "shared_name" : "C17H17O7 (interacts with) C16H17O5",
        "family_id" : 285,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O7 (interacts with) C16H17O5",
        "interaction" : "interacts with",
        "SUID" : 37688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37144",
        "source" : "37005",
        "target" : "36887",
        "shared_name" : "C17H17O7 (interacts with) C16H17O5",
        "family_id" : 211,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O7 (interacts with) C16H17O5",
        "interaction" : "interacts with",
        "SUID" : 37144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38193",
        "source" : "37004",
        "target" : "36886",
        "shared_name" : "C17H19O8 (interacts with) C16H19O6",
        "family_id" : 61,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O8 (interacts with) C16H19O6",
        "interaction" : "interacts with",
        "SUID" : 38193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37591",
        "source" : "37004",
        "target" : "37005",
        "shared_name" : "C17H19O8 (interacts with) C17H17O7",
        "family_id" : 201,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O8 (interacts with) C17H17O7",
        "interaction" : "interacts with",
        "SUID" : 37591,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37151",
        "source" : "37004",
        "target" : "36886",
        "shared_name" : "C17H19O8 (interacts with) C16H19O6",
        "family_id" : 338,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O8 (interacts with) C16H19O6",
        "interaction" : "interacts with",
        "SUID" : 37151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37006",
        "source" : "37004",
        "target" : "37005",
        "shared_name" : "C17H19O8 (interacts with) C17H17O7",
        "family_id" : 285,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O8 (interacts with) C17H17O7",
        "interaction" : "interacts with",
        "SUID" : 37006,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37906",
        "source" : "37002",
        "target" : "36923",
        "shared_name" : "C19H15O13 (interacts with) C18H15O11",
        "family_id" : 60,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H15O13 (interacts with) C18H15O11",
        "interaction" : "interacts with",
        "SUID" : 37906,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37003",
        "source" : "37002",
        "target" : "36923",
        "shared_name" : "C19H15O13 (interacts with) C18H15O11",
        "family_id" : 116,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H15O13 (interacts with) C18H15O11",
        "interaction" : "interacts with",
        "SUID" : 37003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37931",
        "source" : "36998",
        "target" : "36999",
        "shared_name" : "C16H11O7 (interacts with) C15H11O5",
        "family_id" : 164,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O7 (interacts with) C15H11O5",
        "interaction" : "interacts with",
        "SUID" : 37931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37000",
        "source" : "36998",
        "target" : "36999",
        "shared_name" : "C16H11O7 (interacts with) C15H11O5",
        "family_id" : 158,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O7 (interacts with) C15H11O5",
        "interaction" : "interacts with",
        "SUID" : 37000,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38055",
        "source" : "36996",
        "target" : "37076",
        "shared_name" : "C19H21O10 (interacts with) C18H17O9",
        "family_id" : 103,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C19H21O10 (interacts with) C18H17O9",
        "interaction" : "interacts with",
        "SUID" : 38055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38001",
        "source" : "36996",
        "target" : "36811",
        "shared_name" : "C19H21O10 (interacts with) C19H19O9",
        "family_id" : 233,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O10 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 38001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37957",
        "source" : "36996",
        "target" : "36811",
        "shared_name" : "C19H21O10 (interacts with) C19H19O9",
        "family_id" : 181,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O10 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 37957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37948",
        "source" : "36996",
        "target" : "37076",
        "shared_name" : "C19H21O10 (interacts with) C18H17O9",
        "family_id" : 296,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C19H21O10 (interacts with) C18H17O9",
        "interaction" : "interacts with",
        "SUID" : 37948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37887",
        "source" : "36996",
        "target" : "36811",
        "shared_name" : "C19H21O10 (interacts with) C19H19O9",
        "family_id" : 304,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O10 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 37887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37796",
        "source" : "36996",
        "target" : "36889",
        "shared_name" : "C19H21O10 (interacts with) C18H21O8",
        "family_id" : 124,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O10 (interacts with) C18H21O8",
        "interaction" : "interacts with",
        "SUID" : 37796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37787",
        "source" : "36996",
        "target" : "36811",
        "shared_name" : "C19H21O10 (interacts with) C19H19O9",
        "family_id" : 150,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O10 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 37787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37560",
        "source" : "36996",
        "target" : "36889",
        "shared_name" : "C19H21O10 (interacts with) C18H21O8",
        "family_id" : 67,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O10 (interacts with) C18H21O8",
        "interaction" : "interacts with",
        "SUID" : 37560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37502",
        "source" : "36996",
        "target" : "36889",
        "shared_name" : "C19H21O10 (interacts with) C18H21O8",
        "family_id" : 334,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O10 (interacts with) C18H21O8",
        "interaction" : "interacts with",
        "SUID" : 37502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37300",
        "source" : "36996",
        "target" : "36811",
        "shared_name" : "C19H21O10 (interacts with) C19H19O9",
        "family_id" : 186,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O10 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 37300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37278",
        "source" : "36996",
        "target" : "36889",
        "shared_name" : "C19H21O10 (interacts with) C18H21O8",
        "family_id" : 227,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O10 (interacts with) C18H21O8",
        "interaction" : "interacts with",
        "SUID" : 37278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37204",
        "source" : "36996",
        "target" : "36811",
        "shared_name" : "C19H21O10 (interacts with) C19H19O9",
        "family_id" : 98,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O10 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 37204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37149",
        "source" : "36996",
        "target" : "36811",
        "shared_name" : "C19H21O10 (interacts with) C19H19O9",
        "family_id" : 197,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O10 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 37149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37087",
        "source" : "36996",
        "target" : "37076",
        "shared_name" : "C19H21O10 (interacts with) C18H17O9",
        "family_id" : 240,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C19H21O10 (interacts with) C18H17O9",
        "interaction" : "interacts with",
        "SUID" : 37087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37945",
        "source" : "36994",
        "target" : "37079",
        "shared_name" : "C18H21O7 (interacts with) C18H19O6",
        "family_id" : 271,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O7 (interacts with) C18H19O6",
        "interaction" : "interacts with",
        "SUID" : 37945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37737",
        "source" : "36994",
        "target" : "37079",
        "shared_name" : "C18H21O7 (interacts with) C18H19O6",
        "family_id" : 266,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O7 (interacts with) C18H19O6",
        "interaction" : "interacts with",
        "SUID" : 37737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37568",
        "source" : "36994",
        "target" : "37322",
        "shared_name" : "C18H21O7 (interacts with) C17H21O5",
        "family_id" : 200,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O7 (interacts with) C17H21O5",
        "interaction" : "interacts with",
        "SUID" : 37568,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37323",
        "source" : "36994",
        "target" : "37322",
        "shared_name" : "C18H21O7 (interacts with) C17H21O5",
        "family_id" : 245,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O7 (interacts with) C17H21O5",
        "interaction" : "interacts with",
        "SUID" : 37323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37534",
        "source" : "36993",
        "target" : "36994",
        "shared_name" : "C18H23O8 (interacts with) C18H21O7",
        "family_id" : 271,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O8 (interacts with) C18H21O7",
        "interaction" : "interacts with",
        "SUID" : 37534,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36995",
        "source" : "36993",
        "target" : "36994",
        "shared_name" : "C18H23O8 (interacts with) C18H21O7",
        "family_id" : 200,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O8 (interacts with) C18H21O7",
        "interaction" : "interacts with",
        "SUID" : 36995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38031",
        "source" : "36991",
        "target" : "36916",
        "shared_name" : "C16H11O11 (interacts with) C15H11O9",
        "family_id" : 132,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O11 (interacts with) C15H11O9",
        "interaction" : "interacts with",
        "SUID" : 38031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37960",
        "source" : "36991",
        "target" : "36916",
        "shared_name" : "C16H11O11 (interacts with) C15H11O9",
        "family_id" : 202,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O11 (interacts with) C15H11O9",
        "interaction" : "interacts with",
        "SUID" : 37960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37569",
        "source" : "36991",
        "target" : "36916",
        "shared_name" : "C16H11O11 (interacts with) C15H11O9",
        "family_id" : 208,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O11 (interacts with) C15H11O9",
        "interaction" : "interacts with",
        "SUID" : 37569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37263",
        "source" : "36991",
        "target" : "36916",
        "shared_name" : "C16H11O11 (interacts with) C15H11O9",
        "family_id" : 102,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O11 (interacts with) C15H11O9",
        "interaction" : "interacts with",
        "SUID" : 37263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36992",
        "source" : "36991",
        "target" : "36916",
        "shared_name" : "C16H11O11 (interacts with) C15H11O9",
        "family_id" : 314,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O11 (interacts with) C15H11O9",
        "interaction" : "interacts with",
        "SUID" : 36992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38113",
        "source" : "36985",
        "target" : "37771",
        "shared_name" : "C17H21O9 (interacts with) C16H21O7",
        "family_id" : 241,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H21O9 (interacts with) C16H21O7",
        "interaction" : "interacts with",
        "SUID" : 38113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38105",
        "source" : "36985",
        "target" : "37004",
        "shared_name" : "C17H21O9 (interacts with) C17H19O8",
        "family_id" : 338,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O9 (interacts with) C17H19O8",
        "interaction" : "interacts with",
        "SUID" : 38105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37411",
        "source" : "36985",
        "target" : "37004",
        "shared_name" : "C17H21O9 (interacts with) C17H19O8",
        "family_id" : 285,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O9 (interacts with) C17H19O8",
        "interaction" : "interacts with",
        "SUID" : 37411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37732",
        "source" : "36984",
        "target" : "37075",
        "shared_name" : "C18H21O11 (interacts with) C18H19O10",
        "family_id" : 216,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O11 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 37732,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37649",
        "source" : "36984",
        "target" : "36985",
        "shared_name" : "C18H21O11 (interacts with) C17H21O9",
        "family_id" : 338,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O11 (interacts with) C17H21O9",
        "interaction" : "interacts with",
        "SUID" : 37649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37548",
        "source" : "36984",
        "target" : "37075",
        "shared_name" : "C18H21O11 (interacts with) C18H19O10",
        "family_id" : 201,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O11 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 37548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37541",
        "source" : "36984",
        "target" : "37075",
        "shared_name" : "C18H21O11 (interacts with) C18H19O10",
        "family_id" : 211,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O11 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 37541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37536",
        "source" : "36984",
        "target" : "36985",
        "shared_name" : "C18H21O11 (interacts with) C17H21O9",
        "family_id" : 241,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O11 (interacts with) C17H21O9",
        "interaction" : "interacts with",
        "SUID" : 37536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37336",
        "source" : "36984",
        "target" : "37075",
        "shared_name" : "C18H21O11 (interacts with) C18H19O10",
        "family_id" : 61,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O11 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 37336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36986",
        "source" : "36984",
        "target" : "36985",
        "shared_name" : "C18H21O11 (interacts with) C17H21O9",
        "family_id" : 285,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O11 (interacts with) C17H21O9",
        "interaction" : "interacts with",
        "SUID" : 36986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37944",
        "source" : "36982",
        "target" : "37271",
        "shared_name" : "C14H13O10 (interacts with) C13H13O8",
        "family_id" : 14,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H13O10 (interacts with) C13H13O8",
        "interaction" : "interacts with",
        "SUID" : 37944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37637",
        "source" : "36982",
        "target" : "36850",
        "shared_name" : "C14H13O10 (interacts with) C14H11O9",
        "family_id" : 10,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H13O10 (interacts with) C14H11O9",
        "interaction" : "interacts with",
        "SUID" : 37637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37578",
        "source" : "36982",
        "target" : "37271",
        "shared_name" : "C14H13O10 (interacts with) C13H13O8",
        "family_id" : 56,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H13O10 (interacts with) C13H13O8",
        "interaction" : "interacts with",
        "SUID" : 37578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37499",
        "source" : "36981",
        "target" : "36982",
        "shared_name" : "C15H13O12 (interacts with) C14H13O10",
        "family_id" : 10,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H13O12 (interacts with) C14H13O10",
        "interaction" : "interacts with",
        "SUID" : 37499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37255",
        "source" : "36981",
        "target" : "37139",
        "shared_name" : "C15H13O12 (interacts with) C15H11O11",
        "family_id" : 53,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H13O12 (interacts with) C15H11O11",
        "interaction" : "interacts with",
        "SUID" : 37255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37049",
        "source" : "36981",
        "target" : "36982",
        "shared_name" : "C15H13O12 (interacts with) C14H13O10",
        "family_id" : 56,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H13O12 (interacts with) C14H13O10",
        "interaction" : "interacts with",
        "SUID" : 37049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36983",
        "source" : "36981",
        "target" : "36982",
        "shared_name" : "C15H13O12 (interacts with) C14H13O10",
        "family_id" : 14,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H13O12 (interacts with) C14H13O10",
        "interaction" : "interacts with",
        "SUID" : 36983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38134",
        "source" : "36979",
        "target" : "36996",
        "shared_name" : "C20H21O12 (interacts with) C19H21O10",
        "family_id" : 67,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O12 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 38134,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38037",
        "source" : "36979",
        "target" : "36996",
        "shared_name" : "C20H21O12 (interacts with) C19H21O10",
        "family_id" : 186,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O12 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 38037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38008",
        "source" : "36979",
        "target" : "36996",
        "shared_name" : "C20H21O12 (interacts with) C19H21O10",
        "family_id" : 150,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O12 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 38008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37964",
        "source" : "36979",
        "target" : "37088",
        "shared_name" : "C20H21O12 (interacts with) C20H19O11",
        "family_id" : 219,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H21O12 (interacts with) C20H19O11",
        "interaction" : "interacts with",
        "SUID" : 37964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37634",
        "source" : "36979",
        "target" : "37088",
        "shared_name" : "C20H21O12 (interacts with) C20H19O11",
        "family_id" : 131,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H21O12 (interacts with) C20H19O11",
        "interaction" : "interacts with",
        "SUID" : 37634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37521",
        "source" : "36979",
        "target" : "37088",
        "shared_name" : "C20H21O12 (interacts with) C20H19O11",
        "family_id" : 239,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H21O12 (interacts with) C20H19O11",
        "interaction" : "interacts with",
        "SUID" : 37521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37456",
        "source" : "36979",
        "target" : "36996",
        "shared_name" : "C20H21O12 (interacts with) C19H21O10",
        "family_id" : 233,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O12 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 37456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36997",
        "source" : "36979",
        "target" : "36996",
        "shared_name" : "C20H21O12 (interacts with) C19H21O10",
        "family_id" : 98,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O12 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 36997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38197",
        "source" : "36978",
        "target" : "36979",
        "shared_name" : "C20H23O13 (interacts with) C20H21O12",
        "family_id" : 239,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O13 (interacts with) C20H21O12",
        "interaction" : "interacts with",
        "SUID" : 38197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38092",
        "source" : "36978",
        "target" : "36979",
        "shared_name" : "C20H23O13 (interacts with) C20H21O12",
        "family_id" : 131,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O13 (interacts with) C20H21O12",
        "interaction" : "interacts with",
        "SUID" : 38092,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37776",
        "source" : "36978",
        "target" : "36979",
        "shared_name" : "C20H23O13 (interacts with) C20H21O12",
        "family_id" : 233,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O13 (interacts with) C20H21O12",
        "interaction" : "interacts with",
        "SUID" : 37776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37774",
        "source" : "36978",
        "target" : "37122",
        "shared_name" : "C20H23O13 (interacts with) C19H23O11",
        "family_id" : 197,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O13 (interacts with) C19H23O11",
        "interaction" : "interacts with",
        "SUID" : 37774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37754",
        "source" : "36978",
        "target" : "36979",
        "shared_name" : "C20H23O13 (interacts with) C20H21O12",
        "family_id" : 219,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O13 (interacts with) C20H21O12",
        "interaction" : "interacts with",
        "SUID" : 37754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37428",
        "source" : "36978",
        "target" : "36979",
        "shared_name" : "C20H23O13 (interacts with) C20H21O12",
        "family_id" : 98,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O13 (interacts with) C20H21O12",
        "interaction" : "interacts with",
        "SUID" : 37428,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37305",
        "source" : "36978",
        "target" : "37122",
        "shared_name" : "C20H23O13 (interacts with) C19H23O11",
        "family_id" : 227,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O13 (interacts with) C19H23O11",
        "interaction" : "interacts with",
        "SUID" : 37305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37127",
        "source" : "36978",
        "target" : "36979",
        "shared_name" : "C20H23O13 (interacts with) C20H21O12",
        "family_id" : 67,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O13 (interacts with) C20H21O12",
        "interaction" : "interacts with",
        "SUID" : 37127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37123",
        "source" : "36978",
        "target" : "37122",
        "shared_name" : "C20H23O13 (interacts with) C19H23O11",
        "family_id" : 320,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O13 (interacts with) C19H23O11",
        "interaction" : "interacts with",
        "SUID" : 37123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36980",
        "source" : "36978",
        "target" : "36979",
        "shared_name" : "C20H23O13 (interacts with) C20H21O12",
        "family_id" : 186,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O13 (interacts with) C20H21O12",
        "interaction" : "interacts with",
        "SUID" : 36980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37487",
        "source" : "36975",
        "target" : "36976",
        "shared_name" : "C17H13O8 (interacts with) C16H13O6",
        "family_id" : 257,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O8 (interacts with) C16H13O6",
        "interaction" : "interacts with",
        "SUID" : 37487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36977",
        "source" : "36975",
        "target" : "36976",
        "shared_name" : "C17H13O8 (interacts with) C16H13O6",
        "family_id" : 38,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O8 (interacts with) C16H13O6",
        "interaction" : "interacts with",
        "SUID" : 36977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38173",
        "source" : "36970",
        "target" : "36971",
        "shared_name" : "C19H23O8 (interacts with) C19H21O7",
        "family_id" : 78,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O8 (interacts with) C19H21O7",
        "interaction" : "interacts with",
        "SUID" : 38173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37400",
        "source" : "36970",
        "target" : "36971",
        "shared_name" : "C19H23O8 (interacts with) C19H21O7",
        "family_id" : 50,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O8 (interacts with) C19H21O7",
        "interaction" : "interacts with",
        "SUID" : 37400,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36972",
        "source" : "36970",
        "target" : "36971",
        "shared_name" : "C19H23O8 (interacts with) C19H21O7",
        "family_id" : 83,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O8 (interacts with) C19H21O7",
        "interaction" : "interacts with",
        "SUID" : 36972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37017",
        "source" : "36968",
        "target" : "36814",
        "shared_name" : "C16H9O10 (interacts with) C15H9O8",
        "family_id" : 62,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O10 (interacts with) C15H9O8",
        "interaction" : "interacts with",
        "SUID" : 37017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36969",
        "source" : "36968",
        "target" : "36814",
        "shared_name" : "C16H9O10 (interacts with) C15H9O8",
        "family_id" : 137,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O10 (interacts with) C15H9O8",
        "interaction" : "interacts with",
        "SUID" : 36969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37725",
        "source" : "36966",
        "target" : "36815",
        "shared_name" : "C14H11O7 (interacts with) C14H9O6",
        "family_id" : 132,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H11O7 (interacts with) C14H9O6",
        "interaction" : "interacts with",
        "SUID" : 37725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37693",
        "source" : "36966",
        "target" : "36815",
        "shared_name" : "C14H11O7 (interacts with) C14H9O6",
        "family_id" : 250,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H11O7 (interacts with) C14H9O6",
        "interaction" : "interacts with",
        "SUID" : 37693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37641",
        "source" : "36966",
        "target" : "36815",
        "shared_name" : "C14H11O7 (interacts with) C14H9O6",
        "family_id" : 208,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H11O7 (interacts with) C14H9O6",
        "interaction" : "interacts with",
        "SUID" : 37641,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37420",
        "source" : "36966",
        "target" : "36815",
        "shared_name" : "C14H11O7 (interacts with) C14H9O6",
        "family_id" : 110,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H11O7 (interacts with) C14H9O6",
        "interaction" : "interacts with",
        "SUID" : 37420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36967",
        "source" : "36965",
        "target" : "36966",
        "shared_name" : "C14H13O8 (interacts with) C14H11O7",
        "family_id" : 229,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H13O8 (interacts with) C14H11O7",
        "interaction" : "interacts with",
        "SUID" : 36967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37262",
        "source" : "36962",
        "target" : "36821",
        "shared_name" : "C18H15O10 (interacts with) C17H15O8",
        "family_id" : 18,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H15O10 (interacts with) C17H15O8",
        "interaction" : "interacts with",
        "SUID" : 37262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37040",
        "source" : "36962",
        "target" : "36821",
        "shared_name" : "C18H15O10 (interacts with) C17H15O8",
        "family_id" : 182,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H15O10 (interacts with) C17H15O8",
        "interaction" : "interacts with",
        "SUID" : 37040,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36963",
        "source" : "36962",
        "target" : "36821",
        "shared_name" : "C18H15O10 (interacts with) C17H15O8",
        "family_id" : 23,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H15O10 (interacts with) C17H15O8",
        "interaction" : "interacts with",
        "SUID" : 36963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37987",
        "source" : "36960",
        "target" : "36853",
        "shared_name" : "C19H17O10 (interacts with) C18H13O9",
        "family_id" : 214,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C19H17O10 (interacts with) C18H13O9",
        "interaction" : "interacts with",
        "SUID" : 37987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37856",
        "source" : "36960",
        "target" : "36853",
        "shared_name" : "C19H17O10 (interacts with) C18H13O9",
        "family_id" : 80,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C19H17O10 (interacts with) C18H13O9",
        "interaction" : "interacts with",
        "SUID" : 37856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37335",
        "source" : "36960",
        "target" : "37067",
        "shared_name" : "C19H17O10 (interacts with) C18H17O8",
        "family_id" : 299,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H17O10 (interacts with) C18H17O8",
        "interaction" : "interacts with",
        "SUID" : 37335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37179",
        "source" : "36960",
        "target" : "37067",
        "shared_name" : "C19H17O10 (interacts with) C18H17O8",
        "family_id" : 77,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H17O10 (interacts with) C18H17O8",
        "interaction" : "interacts with",
        "SUID" : 37179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37170",
        "source" : "36960",
        "target" : "36853",
        "shared_name" : "C19H17O10 (interacts with) C18H13O9",
        "family_id" : 85,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C19H17O10 (interacts with) C18H13O9",
        "interaction" : "interacts with",
        "SUID" : 37170,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37401",
        "source" : "36959",
        "target" : "36960",
        "shared_name" : "C20H17O12 (interacts with) C19H17O10",
        "family_id" : 77,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H17O12 (interacts with) C19H17O10",
        "interaction" : "interacts with",
        "SUID" : 37401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36961",
        "source" : "36959",
        "target" : "36960",
        "shared_name" : "C20H17O12 (interacts with) C19H17O10",
        "family_id" : 214,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H17O12 (interacts with) C19H17O10",
        "interaction" : "interacts with",
        "SUID" : 36961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38058",
        "source" : "36957",
        "target" : "38057",
        "shared_name" : "C15H21O6 (interacts with) C15H19O5",
        "family_id" : 191,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O6 (interacts with) C15H19O5",
        "interaction" : "interacts with",
        "SUID" : 38058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37808",
        "source" : "36956",
        "target" : "36835",
        "shared_name" : "C16H21O8 (interacts with) C16H19O7",
        "family_id" : 249,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O8 (interacts with) C16H19O7",
        "interaction" : "interacts with",
        "SUID" : 37808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37603",
        "source" : "36956",
        "target" : "36957",
        "shared_name" : "C16H21O8 (interacts with) C15H21O6",
        "family_id" : 336,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O8 (interacts with) C15H21O6",
        "interaction" : "interacts with",
        "SUID" : 37603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37106",
        "source" : "36956",
        "target" : "36835",
        "shared_name" : "C16H21O8 (interacts with) C16H19O7",
        "family_id" : 254,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O8 (interacts with) C16H19O7",
        "interaction" : "interacts with",
        "SUID" : 37106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36987",
        "source" : "36956",
        "target" : "36835",
        "shared_name" : "C16H21O8 (interacts with) C16H19O7",
        "family_id" : 119,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O8 (interacts with) C16H19O7",
        "interaction" : "interacts with",
        "SUID" : 36987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36958",
        "source" : "36956",
        "target" : "36957",
        "shared_name" : "C16H21O8 (interacts with) C15H21O6",
        "family_id" : 191,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O8 (interacts with) C15H21O6",
        "interaction" : "interacts with",
        "SUID" : 36958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38151",
        "source" : "36954",
        "target" : "37421",
        "shared_name" : "C12H7O8 (interacts with) C11H7O6",
        "family_id" : 108,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H7O8 (interacts with) C11H7O6",
        "interaction" : "interacts with",
        "SUID" : 38151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37692",
        "source" : "36954",
        "target" : "37691",
        "shared_name" : "C12H7O8 (interacts with) C12H5O7",
        "family_id" : 199,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C12H7O8 (interacts with) C12H5O7",
        "interaction" : "interacts with",
        "SUID" : 37692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37422",
        "source" : "36954",
        "target" : "37421",
        "shared_name" : "C12H7O8 (interacts with) C11H7O6",
        "family_id" : 9,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H7O8 (interacts with) C11H7O6",
        "interaction" : "interacts with",
        "SUID" : 37422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37546",
        "source" : "36953",
        "target" : "36954",
        "shared_name" : "C13H7O10 (interacts with) C12H7O8",
        "family_id" : 199,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H7O10 (interacts with) C12H7O8",
        "interaction" : "interacts with",
        "SUID" : 37546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36955",
        "source" : "36953",
        "target" : "36954",
        "shared_name" : "C13H7O10 (interacts with) C12H7O8",
        "family_id" : 108,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H7O10 (interacts with) C12H7O8",
        "interaction" : "interacts with",
        "SUID" : 36955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38213",
        "source" : "36950",
        "target" : "36951",
        "shared_name" : "C16H15O7 (interacts with) C15H15O5",
        "family_id" : 170,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O7 (interacts with) C15H15O5",
        "interaction" : "interacts with",
        "SUID" : 38213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38152",
        "source" : "36950",
        "target" : "36951",
        "shared_name" : "C16H15O7 (interacts with) C15H15O5",
        "family_id" : 39,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O7 (interacts with) C15H15O5",
        "interaction" : "interacts with",
        "SUID" : 38152,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37910",
        "source" : "36950",
        "target" : "36951",
        "shared_name" : "C16H15O7 (interacts with) C15H15O5",
        "family_id" : 8,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O7 (interacts with) C15H15O5",
        "interaction" : "interacts with",
        "SUID" : 37910,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36952",
        "source" : "36950",
        "target" : "36951",
        "shared_name" : "C16H15O7 (interacts with) C15H15O5",
        "family_id" : 60,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O7 (interacts with) C15H15O5",
        "interaction" : "interacts with",
        "SUID" : 36952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38045",
        "source" : "36948",
        "target" : "36826",
        "shared_name" : "C17H23O9 (interacts with) C16H23O7",
        "family_id" : 203,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H23O9 (interacts with) C16H23O7",
        "interaction" : "interacts with",
        "SUID" : 38045,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37622",
        "source" : "36948",
        "target" : "36867",
        "shared_name" : "C17H23O9 (interacts with) C17H21O8",
        "family_id" : 289,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H23O9 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 37622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37553",
        "source" : "36948",
        "target" : "36867",
        "shared_name" : "C17H23O9 (interacts with) C17H21O8",
        "family_id" : 151,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H23O9 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 37553,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37468",
        "source" : "36948",
        "target" : "36867",
        "shared_name" : "C17H23O9 (interacts with) C17H21O8",
        "family_id" : 12,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H23O9 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 37468,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37190",
        "source" : "36948",
        "target" : "36826",
        "shared_name" : "C17H23O9 (interacts with) C16H23O7",
        "family_id" : 309,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H23O9 (interacts with) C16H23O7",
        "interaction" : "interacts with",
        "SUID" : 37190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36988",
        "source" : "36948",
        "target" : "36867",
        "shared_name" : "C17H23O9 (interacts with) C17H21O8",
        "family_id" : 36,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H23O9 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 36988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37706",
        "source" : "36947",
        "target" : "37195",
        "shared_name" : "C18H23O11 (interacts with) C18H21O10",
        "family_id" : 44,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O11 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 37706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36949",
        "source" : "36947",
        "target" : "36948",
        "shared_name" : "C18H23O11 (interacts with) C17H23O9",
        "family_id" : 203,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O11 (interacts with) C17H23O9",
        "interaction" : "interacts with",
        "SUID" : 36949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37922",
        "source" : "36944",
        "target" : "37276",
        "shared_name" : "C15H11O8 (interacts with) C14H11O6",
        "family_id" : 130,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O8 (interacts with) C14H11O6",
        "interaction" : "interacts with",
        "SUID" : 37922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37694",
        "source" : "36944",
        "target" : "37276",
        "shared_name" : "C15H11O8 (interacts with) C14H11O6",
        "family_id" : 183,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O8 (interacts with) C14H11O6",
        "interaction" : "interacts with",
        "SUID" : 37694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37277",
        "source" : "36944",
        "target" : "37276",
        "shared_name" : "C15H11O8 (interacts with) C14H11O6",
        "family_id" : 149,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O8 (interacts with) C14H11O6",
        "interaction" : "interacts with",
        "SUID" : 37277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36946",
        "source" : "36944",
        "target" : "36945",
        "shared_name" : "C15H11O8 (interacts with) C15H9O7",
        "family_id" : 325,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H11O8 (interacts with) C15H9O7",
        "interaction" : "interacts with",
        "SUID" : 36946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38187",
        "source" : "36942",
        "target" : "37256",
        "shared_name" : "C17H17O11 (interacts with) C16H17O9",
        "family_id" : 129,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O11 (interacts with) C16H17O9",
        "interaction" : "interacts with",
        "SUID" : 38187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38185",
        "source" : "36942",
        "target" : "37256",
        "shared_name" : "C17H17O11 (interacts with) C16H17O9",
        "family_id" : 287,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O11 (interacts with) C16H17O9",
        "interaction" : "interacts with",
        "SUID" : 38185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38184",
        "source" : "36942",
        "target" : "37208",
        "shared_name" : "C17H17O11 (interacts with) C17H15O10",
        "family_id" : 264,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H17O11 (interacts with) C17H15O10",
        "interaction" : "interacts with",
        "SUID" : 38184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38158",
        "source" : "36942",
        "target" : "37256",
        "shared_name" : "C17H17O11 (interacts with) C16H17O9",
        "family_id" : 54,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O11 (interacts with) C16H17O9",
        "interaction" : "interacts with",
        "SUID" : 38158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37993",
        "source" : "36942",
        "target" : "37256",
        "shared_name" : "C17H17O11 (interacts with) C16H17O9",
        "family_id" : 146,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O11 (interacts with) C16H17O9",
        "interaction" : "interacts with",
        "SUID" : 37993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37794",
        "source" : "36942",
        "target" : "37208",
        "shared_name" : "C17H17O11 (interacts with) C17H15O10",
        "family_id" : 276,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H17O11 (interacts with) C17H15O10",
        "interaction" : "interacts with",
        "SUID" : 37794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37783",
        "source" : "36942",
        "target" : "37256",
        "shared_name" : "C17H17O11 (interacts with) C16H17O9",
        "family_id" : 145,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O11 (interacts with) C16H17O9",
        "interaction" : "interacts with",
        "SUID" : 37783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37290",
        "source" : "36942",
        "target" : "37256",
        "shared_name" : "C17H17O11 (interacts with) C16H17O9",
        "family_id" : 42,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O11 (interacts with) C16H17O9",
        "interaction" : "interacts with",
        "SUID" : 37290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38191",
        "source" : "36941",
        "target" : "36926",
        "shared_name" : "C18H21O12 (interacts with) C18H19O11",
        "family_id" : 127,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O12 (interacts with) C18H19O11",
        "interaction" : "interacts with",
        "SUID" : 38191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37990",
        "source" : "36941",
        "target" : "36942",
        "shared_name" : "C18H21O12 (interacts with) C17H17O11",
        "family_id" : 129,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H21O12 (interacts with) C17H17O11",
        "interaction" : "interacts with",
        "SUID" : 37990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37652",
        "source" : "36941",
        "target" : "37651",
        "shared_name" : "C18H21O12 (interacts with) C17H21O10",
        "family_id" : 119,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O12 (interacts with) C17H21O10",
        "interaction" : "interacts with",
        "SUID" : 37652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37039",
        "source" : "36941",
        "target" : "36942",
        "shared_name" : "C18H21O12 (interacts with) C17H17O11",
        "family_id" : 145,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H21O12 (interacts with) C17H17O11",
        "interaction" : "interacts with",
        "SUID" : 37039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36974",
        "source" : "36941",
        "target" : "36942",
        "shared_name" : "C18H21O12 (interacts with) C17H17O11",
        "family_id" : 42,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H21O12 (interacts with) C17H17O11",
        "interaction" : "interacts with",
        "SUID" : 36974,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36943",
        "source" : "36941",
        "target" : "36942",
        "shared_name" : "C18H21O12 (interacts with) C17H17O11",
        "family_id" : 54,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H21O12 (interacts with) C17H17O11",
        "interaction" : "interacts with",
        "SUID" : 36943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38119",
        "source" : "36938",
        "target" : "37409",
        "shared_name" : "C17H13O12 (interacts with) C17H11O11",
        "family_id" : 187,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H13O12 (interacts with) C17H11O11",
        "interaction" : "interacts with",
        "SUID" : 38119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38071",
        "source" : "36938",
        "target" : "37409",
        "shared_name" : "C17H13O12 (interacts with) C17H11O11",
        "family_id" : 88,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H13O12 (interacts with) C17H11O11",
        "interaction" : "interacts with",
        "SUID" : 38071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37839",
        "source" : "36938",
        "target" : "37429",
        "shared_name" : "C17H13O12 (interacts with) C16H13O10",
        "family_id" : 228,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O12 (interacts with) C16H13O10",
        "interaction" : "interacts with",
        "SUID" : 37839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37800",
        "source" : "36938",
        "target" : "37409",
        "shared_name" : "C17H13O12 (interacts with) C17H11O11",
        "family_id" : 326,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H13O12 (interacts with) C17H11O11",
        "interaction" : "interacts with",
        "SUID" : 37800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38212",
        "source" : "36937",
        "target" : "37483",
        "shared_name" : "C18H13O14 (interacts with) C18H11O13",
        "family_id" : 207,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H13O14 (interacts with) C18H11O13",
        "interaction" : "interacts with",
        "SUID" : 38212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36939",
        "source" : "36937",
        "target" : "36938",
        "shared_name" : "C18H13O14 (interacts with) C17H13O12",
        "family_id" : 187,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H13O14 (interacts with) C17H13O12",
        "interaction" : "interacts with",
        "SUID" : 36939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38117",
        "source" : "36933",
        "target" : "37457",
        "shared_name" : "C16H9O8 (interacts with) C15H9O6",
        "family_id" : 326,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O8 (interacts with) C15H9O6",
        "interaction" : "interacts with",
        "SUID" : 38117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37907",
        "source" : "36933",
        "target" : "37457",
        "shared_name" : "C16H9O8 (interacts with) C15H9O6",
        "family_id" : 24,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O8 (interacts with) C15H9O6",
        "interaction" : "interacts with",
        "SUID" : 37907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37458",
        "source" : "36933",
        "target" : "37457",
        "shared_name" : "C16H9O8 (interacts with) C15H9O6",
        "family_id" : 341,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H9O8 (interacts with) C15H9O6",
        "interaction" : "interacts with",
        "SUID" : 37458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37890",
        "source" : "36932",
        "target" : "36933",
        "shared_name" : "C17H9O10 (interacts with) C16H9O8",
        "family_id" : 24,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H9O10 (interacts with) C16H9O8",
        "interaction" : "interacts with",
        "SUID" : 37890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36934",
        "source" : "36932",
        "target" : "36933",
        "shared_name" : "C17H9O10 (interacts with) C16H9O8",
        "family_id" : 34,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H9O10 (interacts with) C16H9O8",
        "interaction" : "interacts with",
        "SUID" : 36934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38169",
        "source" : "36929",
        "target" : "36930",
        "shared_name" : "C12H11O8 (interacts with) C11H11O6",
        "family_id" : 237,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H11O8 (interacts with) C11H11O6",
        "interaction" : "interacts with",
        "SUID" : 38169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36931",
        "source" : "36929",
        "target" : "36930",
        "shared_name" : "C12H11O8 (interacts with) C11H11O6",
        "family_id" : 196,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C12H11O8 (interacts with) C11H11O6",
        "interaction" : "interacts with",
        "SUID" : 36931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38183",
        "source" : "36927",
        "target" : "36835",
        "shared_name" : "C17H19O9 (interacts with) C16H19O7",
        "family_id" : 127,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O9 (interacts with) C16H19O7",
        "interaction" : "interacts with",
        "SUID" : 38183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37841",
        "source" : "36926",
        "target" : "37208",
        "shared_name" : "C18H19O11 (interacts with) C17H15O10",
        "family_id" : 294,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H19O11 (interacts with) C17H15O10",
        "interaction" : "interacts with",
        "SUID" : 37841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37684",
        "source" : "36926",
        "target" : "37208",
        "shared_name" : "C18H19O11 (interacts with) C17H15O10",
        "family_id" : 205,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H19O11 (interacts with) C17H15O10",
        "interaction" : "interacts with",
        "SUID" : 37684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36928",
        "source" : "36926",
        "target" : "36927",
        "shared_name" : "C18H19O11 (interacts with) C17H19O9",
        "family_id" : 127,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O11 (interacts with) C17H19O9",
        "interaction" : "interacts with",
        "SUID" : 36928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38207",
        "source" : "36924",
        "target" : "36975",
        "shared_name" : "C17H15O9 (interacts with) C17H13O8",
        "family_id" : 173,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O9 (interacts with) C17H13O8",
        "interaction" : "interacts with",
        "SUID" : 38207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38154",
        "source" : "36924",
        "target" : "36975",
        "shared_name" : "C17H15O9 (interacts with) C17H13O8",
        "family_id" : 38,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O9 (interacts with) C17H13O8",
        "interaction" : "interacts with",
        "SUID" : 38154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37645",
        "source" : "36924",
        "target" : "36950",
        "shared_name" : "C17H15O9 (interacts with) C16H15O7",
        "family_id" : 165,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H15O9 (interacts with) C16H15O7",
        "interaction" : "interacts with",
        "SUID" : 37645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37588",
        "source" : "36924",
        "target" : "36950",
        "shared_name" : "C17H15O9 (interacts with) C16H15O7",
        "family_id" : 60,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H15O9 (interacts with) C16H15O7",
        "interaction" : "interacts with",
        "SUID" : 37588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37177",
        "source" : "36924",
        "target" : "36975",
        "shared_name" : "C17H15O9 (interacts with) C17H13O8",
        "family_id" : 257,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O9 (interacts with) C17H13O8",
        "interaction" : "interacts with",
        "SUID" : 37177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37685",
        "source" : "36923",
        "target" : "36860",
        "shared_name" : "C18H15O11 (interacts with) C17H11O10",
        "family_id" : 321,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H15O11 (interacts with) C17H11O10",
        "interaction" : "interacts with",
        "SUID" : 37685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37501",
        "source" : "36923",
        "target" : "36924",
        "shared_name" : "C18H15O11 (interacts with) C17H15O9",
        "family_id" : 60,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H15O11 (interacts with) C17H15O9",
        "interaction" : "interacts with",
        "SUID" : 37501,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37424",
        "source" : "36923",
        "target" : "36924",
        "shared_name" : "C18H15O11 (interacts with) C17H15O9",
        "family_id" : 173,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H15O11 (interacts with) C17H15O9",
        "interaction" : "interacts with",
        "SUID" : 37424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37222",
        "source" : "36923",
        "target" : "36860",
        "shared_name" : "C18H15O11 (interacts with) C17H11O10",
        "family_id" : 116,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C18H15O11 (interacts with) C17H11O10",
        "interaction" : "interacts with",
        "SUID" : 37222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36925",
        "source" : "36923",
        "target" : "36924",
        "shared_name" : "C18H15O11 (interacts with) C17H15O9",
        "family_id" : 38,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H15O11 (interacts with) C17H15O9",
        "interaction" : "interacts with",
        "SUID" : 36925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38242",
        "source" : "36921",
        "target" : "36868",
        "shared_name" : "C18H19O9 (interacts with) C17H19O7",
        "family_id" : 162,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O9 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 38242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38234",
        "source" : "36921",
        "target" : "37067",
        "shared_name" : "C18H19O9 (interacts with) C18H17O8",
        "family_id" : 73,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O9 (interacts with) C18H17O8",
        "interaction" : "interacts with",
        "SUID" : 38234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38047",
        "source" : "36921",
        "target" : "36868",
        "shared_name" : "C18H19O9 (interacts with) C17H19O7",
        "family_id" : 335,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O9 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 38047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37958",
        "source" : "36921",
        "target" : "36868",
        "shared_name" : "C18H19O9 (interacts with) C17H19O7",
        "family_id" : 13,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O9 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 37958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37719",
        "source" : "36921",
        "target" : "36868",
        "shared_name" : "C18H19O9 (interacts with) C17H19O7",
        "family_id" : 44,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O9 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 37719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37676",
        "source" : "36921",
        "target" : "36868",
        "shared_name" : "C18H19O9 (interacts with) C17H19O7",
        "family_id" : 139,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O9 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 37676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37599",
        "source" : "36921",
        "target" : "37067",
        "shared_name" : "C18H19O9 (interacts with) C18H17O8",
        "family_id" : 96,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O9 (interacts with) C18H17O8",
        "interaction" : "interacts with",
        "SUID" : 37599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37526",
        "source" : "36921",
        "target" : "36868",
        "shared_name" : "C18H19O9 (interacts with) C17H19O7",
        "family_id" : 5,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O9 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 37526,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37337",
        "source" : "36921",
        "target" : "37067",
        "shared_name" : "C18H19O9 (interacts with) C18H17O8",
        "family_id" : 125,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O9 (interacts with) C18H17O8",
        "interaction" : "interacts with",
        "SUID" : 37337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37310",
        "source" : "36921",
        "target" : "37067",
        "shared_name" : "C18H19O9 (interacts with) C18H17O8",
        "family_id" : 159,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O9 (interacts with) C18H17O8",
        "interaction" : "interacts with",
        "SUID" : 37310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37210",
        "source" : "36921",
        "target" : "36868",
        "shared_name" : "C18H19O9 (interacts with) C17H19O7",
        "family_id" : 297,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O9 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 37210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37191",
        "source" : "36921",
        "target" : "37067",
        "shared_name" : "C18H19O9 (interacts with) C18H17O8",
        "family_id" : 46,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O9 (interacts with) C18H17O8",
        "interaction" : "interacts with",
        "SUID" : 37191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37154",
        "source" : "36921",
        "target" : "37067",
        "shared_name" : "C18H19O9 (interacts with) C18H17O8",
        "family_id" : 72,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O9 (interacts with) C18H17O8",
        "interaction" : "interacts with",
        "SUID" : 37154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38130",
        "source" : "36920",
        "target" : "36921",
        "shared_name" : "C19H19O11 (interacts with) C18H19O9",
        "family_id" : 5,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O11 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 38130,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38065",
        "source" : "36920",
        "target" : "36960",
        "shared_name" : "C19H19O11 (interacts with) C19H17O10",
        "family_id" : 299,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H19O11 (interacts with) C19H17O10",
        "interaction" : "interacts with",
        "SUID" : 38065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38009",
        "source" : "36920",
        "target" : "36921",
        "shared_name" : "C19H19O11 (interacts with) C18H19O9",
        "family_id" : 297,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O11 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 38009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37982",
        "source" : "36920",
        "target" : "36921",
        "shared_name" : "C19H19O11 (interacts with) C18H19O9",
        "family_id" : 159,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O11 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37883",
        "source" : "36920",
        "target" : "36921",
        "shared_name" : "C19H19O11 (interacts with) C18H19O9",
        "family_id" : 96,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O11 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37186",
        "source" : "36920",
        "target" : "36921",
        "shared_name" : "C19H19O11 (interacts with) C18H19O9",
        "family_id" : 113,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O11 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37001",
        "source" : "36920",
        "target" : "36921",
        "shared_name" : "C19H19O11 (interacts with) C18H19O9",
        "family_id" : 46,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O11 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36922",
        "source" : "36920",
        "target" : "36921",
        "shared_name" : "C19H19O11 (interacts with) C18H19O9",
        "family_id" : 335,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O11 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 36922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38170",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 37,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 38170,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37884",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 94,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37736",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 39,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37687",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 286,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37650",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 144,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37601",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 210,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37221",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 170,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37136",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 246,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37136,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37131",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 236,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37066",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 192,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37057",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 198,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 37057,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36919",
        "source" : "36918",
        "target" : "36817",
        "shared_name" : "C17H21O12 (interacts with) C17H19O11",
        "family_id" : 303,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O12 (interacts with) C17H19O11",
        "interaction" : "interacts with",
        "SUID" : 36919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38112",
        "source" : "36916",
        "target" : "36814",
        "shared_name" : "C15H11O9 (interacts with) C15H9O8",
        "family_id" : 102,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H11O9 (interacts with) C15H9O8",
        "interaction" : "interacts with",
        "SUID" : 38112,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37882",
        "source" : "36916",
        "target" : "36966",
        "shared_name" : "C15H11O9 (interacts with) C14H11O7",
        "family_id" : 250,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O9 (interacts with) C14H11O7",
        "interaction" : "interacts with",
        "SUID" : 37882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37834",
        "source" : "36916",
        "target" : "36966",
        "shared_name" : "C15H11O9 (interacts with) C14H11O7",
        "family_id" : 208,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O9 (interacts with) C14H11O7",
        "interaction" : "interacts with",
        "SUID" : 37834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37478",
        "source" : "36916",
        "target" : "36966",
        "shared_name" : "C15H11O9 (interacts with) C14H11O7",
        "family_id" : 132,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O9 (interacts with) C14H11O7",
        "interaction" : "interacts with",
        "SUID" : 37478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37315",
        "source" : "36916",
        "target" : "36966",
        "shared_name" : "C15H11O9 (interacts with) C14H11O7",
        "family_id" : 110,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H11O9 (interacts with) C14H11O7",
        "interaction" : "interacts with",
        "SUID" : 37315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37108",
        "source" : "36916",
        "target" : "36814",
        "shared_name" : "C15H11O9 (interacts with) C15H9O8",
        "family_id" : 202,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H11O9 (interacts with) C15H9O8",
        "interaction" : "interacts with",
        "SUID" : 37108,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36917",
        "source" : "36916",
        "target" : "36814",
        "shared_name" : "C15H11O9 (interacts with) C15H9O8",
        "family_id" : 314,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H11O9 (interacts with) C15H9O8",
        "interaction" : "interacts with",
        "SUID" : 36917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38240",
        "source" : "36914",
        "target" : "37576",
        "shared_name" : "C13H13O7 (interacts with) C12H13O5",
        "family_id" : 157,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H13O7 (interacts with) C12H13O5",
        "interaction" : "interacts with",
        "SUID" : 38240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38238",
        "source" : "36914",
        "target" : "37576",
        "shared_name" : "C13H13O7 (interacts with) C12H13O5",
        "family_id" : 267,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H13O7 (interacts with) C12H13O5",
        "interaction" : "interacts with",
        "SUID" : 38238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38232",
        "source" : "36914",
        "target" : "37576",
        "shared_name" : "C13H13O7 (interacts with) C12H13O5",
        "family_id" : 90,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H13O7 (interacts with) C12H13O5",
        "interaction" : "interacts with",
        "SUID" : 38232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37799",
        "source" : "36914",
        "target" : "37576",
        "shared_name" : "C13H13O7 (interacts with) C12H13O5",
        "family_id" : 295,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H13O7 (interacts with) C12H13O5",
        "interaction" : "interacts with",
        "SUID" : 37799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37577",
        "source" : "36914",
        "target" : "37576",
        "shared_name" : "C13H13O7 (interacts with) C12H13O5",
        "family_id" : 306,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H13O7 (interacts with) C12H13O5",
        "interaction" : "interacts with",
        "SUID" : 37577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37034",
        "source" : "36914",
        "target" : "37033",
        "shared_name" : "C13H13O7 (interacts with) C13H11O6",
        "family_id" : 59,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H13O7 (interacts with) C13H11O6",
        "interaction" : "interacts with",
        "SUID" : 37034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38208",
        "source" : "36912",
        "target" : "36903",
        "shared_name" : "C20H25O13 (interacts with) C19H25O11",
        "family_id" : 245,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O13 (interacts with) C19H25O11",
        "interaction" : "interacts with",
        "SUID" : 38208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38116",
        "source" : "36912",
        "target" : "36903",
        "shared_name" : "C20H25O13 (interacts with) C19H25O11",
        "family_id" : 266,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O13 (interacts with) C19H25O11",
        "interaction" : "interacts with",
        "SUID" : 38116,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38111",
        "source" : "36912",
        "target" : "36903",
        "shared_name" : "C20H25O13 (interacts with) C19H25O11",
        "family_id" : 268,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O13 (interacts with) C19H25O11",
        "interaction" : "interacts with",
        "SUID" : 38111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37873",
        "source" : "36912",
        "target" : "36903",
        "shared_name" : "C20H25O13 (interacts with) C19H25O11",
        "family_id" : 179,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O13 (interacts with) C19H25O11",
        "interaction" : "interacts with",
        "SUID" : 37873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37753",
        "source" : "36912",
        "target" : "36903",
        "shared_name" : "C20H25O13 (interacts with) C19H25O11",
        "family_id" : 31,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O13 (interacts with) C19H25O11",
        "interaction" : "interacts with",
        "SUID" : 37753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37704",
        "source" : "36912",
        "target" : "36903",
        "shared_name" : "C20H25O13 (interacts with) C19H25O11",
        "family_id" : 93,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O13 (interacts with) C19H25O11",
        "interaction" : "interacts with",
        "SUID" : 37704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37564",
        "source" : "36912",
        "target" : "36903",
        "shared_name" : "C20H25O13 (interacts with) C19H25O11",
        "family_id" : 16,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O13 (interacts with) C19H25O11",
        "interaction" : "interacts with",
        "SUID" : 37564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37126",
        "source" : "36912",
        "target" : "36903",
        "shared_name" : "C20H25O13 (interacts with) C19H25O11",
        "family_id" : 200,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O13 (interacts with) C19H25O11",
        "interaction" : "interacts with",
        "SUID" : 37126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36913",
        "source" : "36912",
        "target" : "36903",
        "shared_name" : "C20H25O13 (interacts with) C19H25O11",
        "family_id" : 271,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O13 (interacts with) C19H25O11",
        "interaction" : "interacts with",
        "SUID" : 36913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38086",
        "source" : "36910",
        "target" : "37215",
        "shared_name" : "C14H19O6 (interacts with) C14H17O5",
        "family_id" : 134,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H19O6 (interacts with) C14H17O5",
        "interaction" : "interacts with",
        "SUID" : 38086,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37812",
        "source" : "36910",
        "target" : "37215",
        "shared_name" : "C14H19O6 (interacts with) C14H17O5",
        "family_id" : 195,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H19O6 (interacts with) C14H17O5",
        "interaction" : "interacts with",
        "SUID" : 37812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37452",
        "source" : "36910",
        "target" : "37215",
        "shared_name" : "C14H19O6 (interacts with) C14H17O5",
        "family_id" : 133,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H19O6 (interacts with) C14H17O5",
        "interaction" : "interacts with",
        "SUID" : 37452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38074",
        "source" : "36909",
        "target" : "36910",
        "shared_name" : "C15H19O8 (interacts with) C14H19O6",
        "family_id" : 134,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H19O8 (interacts with) C14H19O6",
        "interaction" : "interacts with",
        "SUID" : 38074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37764",
        "source" : "36909",
        "target" : "36910",
        "shared_name" : "C15H19O8 (interacts with) C14H19O6",
        "family_id" : 248,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H19O8 (interacts with) C14H19O6",
        "interaction" : "interacts with",
        "SUID" : 37764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37619",
        "source" : "36909",
        "target" : "37214",
        "shared_name" : "C15H19O8 (interacts with) C15H17O7",
        "family_id" : 215,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O8 (interacts with) C15H17O7",
        "interaction" : "interacts with",
        "SUID" : 37619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37445",
        "source" : "36909",
        "target" : "37214",
        "shared_name" : "C15H19O8 (interacts with) C15H17O7",
        "family_id" : 4,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O8 (interacts with) C15H17O7",
        "interaction" : "interacts with",
        "SUID" : 37445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37440",
        "source" : "36909",
        "target" : "36910",
        "shared_name" : "C15H19O8 (interacts with) C14H19O6",
        "family_id" : 133,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H19O8 (interacts with) C14H19O6",
        "interaction" : "interacts with",
        "SUID" : 37440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36973",
        "source" : "36909",
        "target" : "36910",
        "shared_name" : "C15H19O8 (interacts with) C14H19O6",
        "family_id" : 195,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H19O8 (interacts with) C14H19O6",
        "interaction" : "interacts with",
        "SUID" : 36973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36911",
        "source" : "36909",
        "target" : "36910",
        "shared_name" : "C15H19O8 (interacts with) C14H19O6",
        "family_id" : 189,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H19O8 (interacts with) C14H19O6",
        "interaction" : "interacts with",
        "SUID" : 36911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37995",
        "source" : "36907",
        "target" : "37734",
        "shared_name" : "C13H15O7 (interacts with) C12H15O5",
        "family_id" : 251,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H15O7 (interacts with) C12H15O5",
        "interaction" : "interacts with",
        "SUID" : 37995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37817",
        "source" : "36907",
        "target" : "37734",
        "shared_name" : "C13H15O7 (interacts with) C12H15O5",
        "family_id" : 156,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H15O7 (interacts with) C12H15O5",
        "interaction" : "interacts with",
        "SUID" : 37817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37735",
        "source" : "36907",
        "target" : "37734",
        "shared_name" : "C13H15O7 (interacts with) C12H15O5",
        "family_id" : 212,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H15O7 (interacts with) C12H15O5",
        "interaction" : "interacts with",
        "SUID" : 37735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38061",
        "source" : "36906",
        "target" : "38060",
        "shared_name" : "C13H17O8 (interacts with) C12H17O6",
        "family_id" : 300,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H17O8 (interacts with) C12H17O6",
        "interaction" : "interacts with",
        "SUID" : 38061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36908",
        "source" : "36906",
        "target" : "36907",
        "shared_name" : "C13H17O8 (interacts with) C13H15O7",
        "family_id" : 251,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C13H17O8 (interacts with) C13H15O7",
        "interaction" : "interacts with",
        "SUID" : 36908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38221",
        "source" : "36904",
        "target" : "37363",
        "shared_name" : "C19H23O10 (interacts with) C19H21O9",
        "family_id" : 16,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O10 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 38221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38070",
        "source" : "36904",
        "target" : "37363",
        "shared_name" : "C19H23O10 (interacts with) C19H21O9",
        "family_id" : 266,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O10 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 38070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38063",
        "source" : "36904",
        "target" : "37363",
        "shared_name" : "C19H23O10 (interacts with) C19H21O9",
        "family_id" : 268,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O10 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 38063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37934",
        "source" : "36904",
        "target" : "37363",
        "shared_name" : "C19H23O10 (interacts with) C19H21O9",
        "family_id" : 128,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O10 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 37934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37631",
        "source" : "36904",
        "target" : "37363",
        "shared_name" : "C19H23O10 (interacts with) C19H21O9",
        "family_id" : 245,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O10 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 37631,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37528",
        "source" : "36904",
        "target" : "36993",
        "shared_name" : "C19H23O10 (interacts with) C18H23O8",
        "family_id" : 271,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O10 (interacts with) C18H23O8",
        "interaction" : "interacts with",
        "SUID" : 37528,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37382",
        "source" : "36904",
        "target" : "36993",
        "shared_name" : "C19H23O10 (interacts with) C18H23O8",
        "family_id" : 200,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O10 (interacts with) C18H23O8",
        "interaction" : "interacts with",
        "SUID" : 37382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37326",
        "source" : "36904",
        "target" : "36921",
        "shared_name" : "C19H23O10 (interacts with) C18H19O9",
        "family_id" : 139,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C19H23O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37132",
        "source" : "36904",
        "target" : "36993",
        "shared_name" : "C19H23O10 (interacts with) C18H23O8",
        "family_id" : 179,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O10 (interacts with) C18H23O8",
        "interaction" : "interacts with",
        "SUID" : 37132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37086",
        "source" : "36904",
        "target" : "36921",
        "shared_name" : "C19H23O10 (interacts with) C18H19O9",
        "family_id" : 162,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C19H23O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 37086,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38022",
        "source" : "36903",
        "target" : "36904",
        "shared_name" : "C19H25O11 (interacts with) C19H23O10",
        "family_id" : 271,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O11 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 38022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37810",
        "source" : "36903",
        "target" : "36904",
        "shared_name" : "C19H25O11 (interacts with) C19H23O10",
        "family_id" : 268,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O11 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 37810,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37716",
        "source" : "36903",
        "target" : "36904",
        "shared_name" : "C19H25O11 (interacts with) C19H23O10",
        "family_id" : 200,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O11 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 37716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37542",
        "source" : "36903",
        "target" : "36904",
        "shared_name" : "C19H25O11 (interacts with) C19H23O10",
        "family_id" : 179,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O11 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 37542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37449",
        "source" : "36903",
        "target" : "36904",
        "shared_name" : "C19H25O11 (interacts with) C19H23O10",
        "family_id" : 31,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O11 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 37449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37372",
        "source" : "36903",
        "target" : "36904",
        "shared_name" : "C19H25O11 (interacts with) C19H23O10",
        "family_id" : 266,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O11 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 37372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37188",
        "source" : "36903",
        "target" : "36904",
        "shared_name" : "C19H25O11 (interacts with) C19H23O10",
        "family_id" : 16,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O11 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 37188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37061",
        "source" : "36903",
        "target" : "37060",
        "shared_name" : "C19H25O11 (interacts with) C18H25O9",
        "family_id" : 141,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H25O11 (interacts with) C18H25O9",
        "interaction" : "interacts with",
        "SUID" : 37061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36905",
        "source" : "36903",
        "target" : "36904",
        "shared_name" : "C19H25O11 (interacts with) C19H23O10",
        "family_id" : 245,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O11 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 36905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37609",
        "source" : "36901",
        "target" : "36857",
        "shared_name" : "C15H7O8 (interacts with) C14H7O6",
        "family_id" : 284,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H7O8 (interacts with) C14H7O6",
        "interaction" : "interacts with",
        "SUID" : 37609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36902",
        "source" : "36901",
        "target" : "36857",
        "shared_name" : "C15H7O8 (interacts with) C14H7O6",
        "family_id" : 225,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H7O8 (interacts with) C14H7O6",
        "interaction" : "interacts with",
        "SUID" : 36902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38178",
        "source" : "36899",
        "target" : "36894",
        "shared_name" : "C16H19O9 (interacts with) C16H17O8",
        "family_id" : 236,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O9 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 38178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38164",
        "source" : "36899",
        "target" : "36894",
        "shared_name" : "C16H19O9 (interacts with) C16H17O8",
        "family_id" : 286,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O9 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 38164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38069",
        "source" : "36899",
        "target" : "37211",
        "shared_name" : "C16H19O9 (interacts with) C15H19O7",
        "family_id" : 49,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O9 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 38069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38028",
        "source" : "36899",
        "target" : "37211",
        "shared_name" : "C16H19O9 (interacts with) C15H19O7",
        "family_id" : 144,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O9 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 38028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38023",
        "source" : "36899",
        "target" : "36894",
        "shared_name" : "C16H19O9 (interacts with) C16H17O8",
        "family_id" : 8,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O9 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 38023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37932",
        "source" : "36899",
        "target" : "36894",
        "shared_name" : "C16H19O9 (interacts with) C16H17O8",
        "family_id" : 291,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O9 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 37932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37405",
        "source" : "36899",
        "target" : "37211",
        "shared_name" : "C16H19O9 (interacts with) C15H19O7",
        "family_id" : 303,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O9 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 37405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37343",
        "source" : "36899",
        "target" : "36894",
        "shared_name" : "C16H19O9 (interacts with) C16H17O8",
        "family_id" : 198,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O9 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 37343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37247",
        "source" : "36899",
        "target" : "36894",
        "shared_name" : "C16H19O9 (interacts with) C16H17O8",
        "family_id" : 170,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O9 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 37247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37212",
        "source" : "36899",
        "target" : "37211",
        "shared_name" : "C16H19O9 (interacts with) C15H19O7",
        "family_id" : 37,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O9 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 37212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37053",
        "source" : "36899",
        "target" : "37052",
        "shared_name" : "C16H19O9 (interacts with) C15H15O8",
        "family_id" : 275,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C16H19O9 (interacts with) C15H15O8",
        "interaction" : "interacts with",
        "SUID" : 37053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37813",
        "source" : "36897",
        "target" : "36991",
        "shared_name" : "C17H15O12 (interacts with) C16H11O11",
        "family_id" : 132,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C17H15O12 (interacts with) C16H11O11",
        "interaction" : "interacts with",
        "SUID" : 37813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37777",
        "source" : "36897",
        "target" : "36859",
        "shared_name" : "C17H15O12 (interacts with) C17H13O11",
        "family_id" : 0,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O12 (interacts with) C17H13O11",
        "interaction" : "interacts with",
        "SUID" : 37777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37533",
        "source" : "36897",
        "target" : "36859",
        "shared_name" : "C17H15O12 (interacts with) C17H13O11",
        "family_id" : 97,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O12 (interacts with) C17H13O11",
        "interaction" : "interacts with",
        "SUID" : 37533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37433",
        "source" : "36897",
        "target" : "37041",
        "shared_name" : "C17H15O12 (interacts with) C16H15O10",
        "family_id" : 269,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H15O12 (interacts with) C16H15O10",
        "interaction" : "interacts with",
        "SUID" : 37433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37432",
        "source" : "36897",
        "target" : "36859",
        "shared_name" : "C17H15O12 (interacts with) C17H13O11",
        "family_id" : 305,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O12 (interacts with) C17H13O11",
        "interaction" : "interacts with",
        "SUID" : 37432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37248",
        "source" : "36897",
        "target" : "37041",
        "shared_name" : "C17H15O12 (interacts with) C16H15O10",
        "family_id" : 172,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H15O12 (interacts with) C16H15O10",
        "interaction" : "interacts with",
        "SUID" : 37248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37130",
        "source" : "36897",
        "target" : "36859",
        "shared_name" : "C17H15O12 (interacts with) C17H13O11",
        "family_id" : 278,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O12 (interacts with) C17H13O11",
        "interaction" : "interacts with",
        "SUID" : 37130,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37035",
        "source" : "36897",
        "target" : "36859",
        "shared_name" : "C17H15O12 (interacts with) C17H13O11",
        "family_id" : 111,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O12 (interacts with) C17H13O11",
        "interaction" : "interacts with",
        "SUID" : 37035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36898",
        "source" : "36897",
        "target" : "36859",
        "shared_name" : "C17H15O12 (interacts with) C17H13O11",
        "family_id" : 148,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O12 (interacts with) C17H13O11",
        "interaction" : "interacts with",
        "SUID" : 36898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38133",
        "source" : "36895",
        "target" : "36951",
        "shared_name" : "C15H17O6 (interacts with) C15H15O5",
        "family_id" : 144,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O6 (interacts with) C15H15O5",
        "interaction" : "interacts with",
        "SUID" : 38133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38017",
        "source" : "36895",
        "target" : "36951",
        "shared_name" : "C15H17O6 (interacts with) C15H15O5",
        "family_id" : 49,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O6 (interacts with) C15H15O5",
        "interaction" : "interacts with",
        "SUID" : 38017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37340",
        "source" : "36895",
        "target" : "36951",
        "shared_name" : "C15H17O6 (interacts with) C15H15O5",
        "family_id" : 94,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O6 (interacts with) C15H15O5",
        "interaction" : "interacts with",
        "SUID" : 37340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37128",
        "source" : "36895",
        "target" : "36951",
        "shared_name" : "C15H17O6 (interacts with) C15H15O5",
        "family_id" : 236,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O6 (interacts with) C15H15O5",
        "interaction" : "interacts with",
        "SUID" : 37128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38179",
        "source" : "36894",
        "target" : "36950",
        "shared_name" : "C16H17O8 (interacts with) C16H15O7",
        "family_id" : 8,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O8 (interacts with) C16H15O7",
        "interaction" : "interacts with",
        "SUID" : 38179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37589",
        "source" : "36894",
        "target" : "36950",
        "shared_name" : "C16H17O8 (interacts with) C16H15O7",
        "family_id" : 246,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O8 (interacts with) C16H15O7",
        "interaction" : "interacts with",
        "SUID" : 37589,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37579",
        "source" : "36894",
        "target" : "36950",
        "shared_name" : "C16H17O8 (interacts with) C16H15O7",
        "family_id" : 39,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O8 (interacts with) C16H15O7",
        "interaction" : "interacts with",
        "SUID" : 37579,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37520",
        "source" : "36894",
        "target" : "36950",
        "shared_name" : "C16H17O8 (interacts with) C16H15O7",
        "family_id" : 198,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O8 (interacts with) C16H15O7",
        "interaction" : "interacts with",
        "SUID" : 37520,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37391",
        "source" : "36894",
        "target" : "36895",
        "shared_name" : "C16H17O8 (interacts with) C15H17O6",
        "family_id" : 236,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O8 (interacts with) C15H17O6",
        "interaction" : "interacts with",
        "SUID" : 37391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37333",
        "source" : "36894",
        "target" : "36895",
        "shared_name" : "C16H17O8 (interacts with) C15H17O6",
        "family_id" : 210,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O8 (interacts with) C15H17O6",
        "interaction" : "interacts with",
        "SUID" : 37333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37297",
        "source" : "36894",
        "target" : "36950",
        "shared_name" : "C16H17O8 (interacts with) C16H15O7",
        "family_id" : 291,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O8 (interacts with) C16H15O7",
        "interaction" : "interacts with",
        "SUID" : 37297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37220",
        "source" : "36894",
        "target" : "36895",
        "shared_name" : "C16H17O8 (interacts with) C15H17O6",
        "family_id" : 286,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O8 (interacts with) C15H17O6",
        "interaction" : "interacts with",
        "SUID" : 37220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36964",
        "source" : "36894",
        "target" : "36950",
        "shared_name" : "C16H17O8 (interacts with) C16H15O7",
        "family_id" : 170,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O8 (interacts with) C16H15O7",
        "interaction" : "interacts with",
        "SUID" : 36964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36896",
        "source" : "36894",
        "target" : "36895",
        "shared_name" : "C16H17O8 (interacts with) C15H17O6",
        "family_id" : 94,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O8 (interacts with) C15H17O6",
        "interaction" : "interacts with",
        "SUID" : 36896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37972",
        "source" : "36892",
        "target" : "37007",
        "shared_name" : "C15H17O10 (interacts with) C15H15O9",
        "family_id" : 28,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O10 (interacts with) C15H15O9",
        "interaction" : "interacts with",
        "SUID" : 37972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37930",
        "source" : "36892",
        "target" : "36832",
        "shared_name" : "C15H17O10 (interacts with) C14H17O8",
        "family_id" : 120,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O10 (interacts with) C14H17O8",
        "interaction" : "interacts with",
        "SUID" : 37930,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37830",
        "source" : "36892",
        "target" : "36832",
        "shared_name" : "C15H17O10 (interacts with) C14H17O8",
        "family_id" : 277,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O10 (interacts with) C14H17O8",
        "interaction" : "interacts with",
        "SUID" : 37830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37708",
        "source" : "36892",
        "target" : "36832",
        "shared_name" : "C15H17O10 (interacts with) C14H17O8",
        "family_id" : 282,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O10 (interacts with) C14H17O8",
        "interaction" : "interacts with",
        "SUID" : 37708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37643",
        "source" : "36892",
        "target" : "37007",
        "shared_name" : "C15H17O10 (interacts with) C15H15O9",
        "family_id" : 100,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O10 (interacts with) C15H15O9",
        "interaction" : "interacts with",
        "SUID" : 37643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37606",
        "source" : "36892",
        "target" : "37007",
        "shared_name" : "C15H17O10 (interacts with) C15H15O9",
        "family_id" : 58,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O10 (interacts with) C15H15O9",
        "interaction" : "interacts with",
        "SUID" : 37606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37426",
        "source" : "36892",
        "target" : "36832",
        "shared_name" : "C15H17O10 (interacts with) C14H17O8",
        "family_id" : 327,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O10 (interacts with) C14H17O8",
        "interaction" : "interacts with",
        "SUID" : 37426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37425",
        "source" : "36892",
        "target" : "36832",
        "shared_name" : "C15H17O10 (interacts with) C14H17O8",
        "family_id" : 136,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O10 (interacts with) C14H17O8",
        "interaction" : "interacts with",
        "SUID" : 37425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37295",
        "source" : "36892",
        "target" : "36832",
        "shared_name" : "C15H17O10 (interacts with) C14H17O8",
        "family_id" : 292,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O10 (interacts with) C14H17O8",
        "interaction" : "interacts with",
        "SUID" : 37295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37008",
        "source" : "36892",
        "target" : "37007",
        "shared_name" : "C15H17O10 (interacts with) C15H15O9",
        "family_id" : 319,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O10 (interacts with) C15H15O9",
        "interaction" : "interacts with",
        "SUID" : 37008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37858",
        "source" : "36891",
        "target" : "36892",
        "shared_name" : "C16H17O12 (interacts with) C15H17O10",
        "family_id" : 327,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O12 (interacts with) C15H17O10",
        "interaction" : "interacts with",
        "SUID" : 37858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37489",
        "source" : "36891",
        "target" : "36892",
        "shared_name" : "C16H17O12 (interacts with) C15H17O10",
        "family_id" : 58,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O12 (interacts with) C15H17O10",
        "interaction" : "interacts with",
        "SUID" : 37489,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37304",
        "source" : "36891",
        "target" : "36892",
        "shared_name" : "C16H17O12 (interacts with) C15H17O10",
        "family_id" : 292,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O12 (interacts with) C15H17O10",
        "interaction" : "interacts with",
        "SUID" : 37304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36893",
        "source" : "36891",
        "target" : "36892",
        "shared_name" : "C16H17O12 (interacts with) C15H17O10",
        "family_id" : 28,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O12 (interacts with) C15H17O10",
        "interaction" : "interacts with",
        "SUID" : 36893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38227",
        "source" : "36889",
        "target" : "37709",
        "shared_name" : "C18H21O8 (interacts with) C17H21O6",
        "family_id" : 206,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O8 (interacts with) C17H21O6",
        "interaction" : "interacts with",
        "SUID" : 38227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38225",
        "source" : "36889",
        "target" : "36812",
        "shared_name" : "C18H21O8 (interacts with) C18H19O7",
        "family_id" : 67,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O8 (interacts with) C18H19O7",
        "interaction" : "interacts with",
        "SUID" : 38225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38186",
        "source" : "36889",
        "target" : "36812",
        "shared_name" : "C18H21O8 (interacts with) C18H19O7",
        "family_id" : 320,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O8 (interacts with) C18H19O7",
        "interaction" : "interacts with",
        "SUID" : 38186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37710",
        "source" : "36889",
        "target" : "37709",
        "shared_name" : "C18H21O8 (interacts with) C17H21O6",
        "family_id" : 334,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O8 (interacts with) C17H21O6",
        "interaction" : "interacts with",
        "SUID" : 37710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37600",
        "source" : "36889",
        "target" : "36812",
        "shared_name" : "C18H21O8 (interacts with) C18H19O7",
        "family_id" : 124,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O8 (interacts with) C18H19O7",
        "interaction" : "interacts with",
        "SUID" : 37600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37187",
        "source" : "36889",
        "target" : "36812",
        "shared_name" : "C18H21O8 (interacts with) C18H19O7",
        "family_id" : 227,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O8 (interacts with) C18H19O7",
        "interaction" : "interacts with",
        "SUID" : 37187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36890",
        "source" : "36889",
        "target" : "36812",
        "shared_name" : "C18H21O8 (interacts with) C18H19O7",
        "family_id" : 17,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O8 (interacts with) C18H19O7",
        "interaction" : "interacts with",
        "SUID" : 36890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38168",
        "source" : "36886",
        "target" : "36887",
        "shared_name" : "C16H19O6 (interacts with) C16H17O5",
        "family_id" : 338,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O6 (interacts with) C16H17O5",
        "interaction" : "interacts with",
        "SUID" : 38168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37395",
        "source" : "36886",
        "target" : "36887",
        "shared_name" : "C16H19O6 (interacts with) C16H17O5",
        "family_id" : 61,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O6 (interacts with) C16H17O5",
        "interaction" : "interacts with",
        "SUID" : 37395,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36888",
        "source" : "36886",
        "target" : "36887",
        "shared_name" : "C16H19O6 (interacts with) C16H17O5",
        "family_id" : 241,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O6 (interacts with) C16H17O5",
        "interaction" : "interacts with",
        "SUID" : 36888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37908",
        "source" : "36883",
        "target" : "36884",
        "shared_name" : "C16H17O7 (interacts with) C16H15O6",
        "family_id" : 66,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O7 (interacts with) C16H15O6",
        "interaction" : "interacts with",
        "SUID" : 37908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37671",
        "source" : "36883",
        "target" : "36884",
        "shared_name" : "C16H17O7 (interacts with) C16H15O6",
        "family_id" : 138,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O7 (interacts with) C16H15O6",
        "interaction" : "interacts with",
        "SUID" : 37671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37604",
        "source" : "36883",
        "target" : "36884",
        "shared_name" : "C16H17O7 (interacts with) C16H15O6",
        "family_id" : 244,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O7 (interacts with) C16H15O6",
        "interaction" : "interacts with",
        "SUID" : 37604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37369",
        "source" : "36883",
        "target" : "37193",
        "shared_name" : "C16H17O7 (interacts with) C15H17O5",
        "family_id" : 288,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O7 (interacts with) C15H17O5",
        "interaction" : "interacts with",
        "SUID" : 37369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37183",
        "source" : "36883",
        "target" : "36884",
        "shared_name" : "C16H17O7 (interacts with) C16H15O6",
        "family_id" : 107,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O7 (interacts with) C16H15O6",
        "interaction" : "interacts with",
        "SUID" : 37183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36885",
        "source" : "36883",
        "target" : "36884",
        "shared_name" : "C16H17O7 (interacts with) C16H15O6",
        "family_id" : 70,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H17O7 (interacts with) C16H15O6",
        "interaction" : "interacts with",
        "SUID" : 36885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36990",
        "source" : "36881",
        "target" : "36989",
        "shared_name" : "C21H21O8 (interacts with) C20H21O6",
        "family_id" : 193,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O8 (interacts with) C20H21O6",
        "interaction" : "interacts with",
        "SUID" : 36990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36882",
        "source" : "36880",
        "target" : "36881",
        "shared_name" : "C22H21O10 (interacts with) C21H21O8",
        "family_id" : 193,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H21O10 (interacts with) C21H21O8",
        "interaction" : "interacts with",
        "SUID" : 36882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37742",
        "source" : "36878",
        "target" : "36914",
        "shared_name" : "C14H13O9 (interacts with) C13H13O7",
        "family_id" : 267,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H13O9 (interacts with) C13H13O7",
        "interaction" : "interacts with",
        "SUID" : 37742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37437",
        "source" : "36878",
        "target" : "36914",
        "shared_name" : "C14H13O9 (interacts with) C13H13O7",
        "family_id" : 157,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H13O9 (interacts with) C13H13O7",
        "interaction" : "interacts with",
        "SUID" : 37437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36915",
        "source" : "36878",
        "target" : "36914",
        "shared_name" : "C14H13O9 (interacts with) C13H13O7",
        "family_id" : 306,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H13O9 (interacts with) C13H13O7",
        "interaction" : "interacts with",
        "SUID" : 36915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37838",
        "source" : "36877",
        "target" : "37379",
        "shared_name" : "C14H15O10 (interacts with) C13H15O8",
        "family_id" : 295,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H15O10 (interacts with) C13H15O8",
        "interaction" : "interacts with",
        "SUID" : 37838,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37721",
        "source" : "36877",
        "target" : "37379",
        "shared_name" : "C14H15O10 (interacts with) C13H15O8",
        "family_id" : 87,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H15O10 (interacts with) C13H15O8",
        "interaction" : "interacts with",
        "SUID" : 37721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36879",
        "source" : "36877",
        "target" : "36878",
        "shared_name" : "C14H15O10 (interacts with) C14H13O9",
        "family_id" : 157,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O10 (interacts with) C14H13O9",
        "interaction" : "interacts with",
        "SUID" : 36879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37981",
        "source" : "36875",
        "target" : "36923",
        "shared_name" : "C18H17O12 (interacts with) C18H15O11",
        "family_id" : 38,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H17O12 (interacts with) C18H15O11",
        "interaction" : "interacts with",
        "SUID" : 37981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37745",
        "source" : "36875",
        "target" : "36818",
        "shared_name" : "C18H17O12 (interacts with) C17H17O10",
        "family_id" : 257,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O12 (interacts with) C17H17O10",
        "interaction" : "interacts with",
        "SUID" : 37745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37646",
        "source" : "36875",
        "target" : "36923",
        "shared_name" : "C18H17O12 (interacts with) C18H15O11",
        "family_id" : 173,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H17O12 (interacts with) C18H15O11",
        "interaction" : "interacts with",
        "SUID" : 37646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36876",
        "source" : "36875",
        "target" : "36818",
        "shared_name" : "C18H17O12 (interacts with) C17H17O10",
        "family_id" : 106,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O12 (interacts with) C17H17O10",
        "interaction" : "interacts with",
        "SUID" : 36876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38124",
        "source" : "36873",
        "target" : "36820",
        "shared_name" : "C18H17O11 (interacts with) C17H17O9",
        "family_id" : 288,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O11 (interacts with) C17H17O9",
        "interaction" : "interacts with",
        "SUID" : 38124,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38110",
        "source" : "36873",
        "target" : "36962",
        "shared_name" : "C18H17O11 (interacts with) C18H15O10",
        "family_id" : 182,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H17O11 (interacts with) C18H15O10",
        "interaction" : "interacts with",
        "SUID" : 38110,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37998",
        "source" : "36873",
        "target" : "36962",
        "shared_name" : "C18H17O11 (interacts with) C18H15O10",
        "family_id" : 23,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H17O11 (interacts with) C18H15O10",
        "interaction" : "interacts with",
        "SUID" : 37998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37552",
        "source" : "36873",
        "target" : "36820",
        "shared_name" : "C18H17O11 (interacts with) C17H17O9",
        "family_id" : 244,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O11 (interacts with) C17H17O9",
        "interaction" : "interacts with",
        "SUID" : 37552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37397",
        "source" : "36873",
        "target" : "36820",
        "shared_name" : "C18H17O11 (interacts with) C17H17O9",
        "family_id" : 66,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O11 (interacts with) C17H17O9",
        "interaction" : "interacts with",
        "SUID" : 37397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37311",
        "source" : "36873",
        "target" : "36820",
        "shared_name" : "C18H17O11 (interacts with) C17H17O9",
        "family_id" : 312,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O11 (interacts with) C17H17O9",
        "interaction" : "interacts with",
        "SUID" : 37311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37150",
        "source" : "36873",
        "target" : "36820",
        "shared_name" : "C18H17O11 (interacts with) C17H17O9",
        "family_id" : 115,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O11 (interacts with) C17H17O9",
        "interaction" : "interacts with",
        "SUID" : 37150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38204",
        "source" : "36871",
        "target" : "37513",
        "shared_name" : "C16H11O8 (interacts with) C15H11O6",
        "family_id" : 171,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O8 (interacts with) C15H11O6",
        "interaction" : "interacts with",
        "SUID" : 38204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37789",
        "source" : "36871",
        "target" : "37513",
        "shared_name" : "C16H11O8 (interacts with) C15H11O6",
        "family_id" : 116,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O8 (interacts with) C15H11O6",
        "interaction" : "interacts with",
        "SUID" : 37789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37611",
        "source" : "36871",
        "target" : "37513",
        "shared_name" : "C16H11O8 (interacts with) C15H11O6",
        "family_id" : 111,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O8 (interacts with) C15H11O6",
        "interaction" : "interacts with",
        "SUID" : 37611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37522",
        "source" : "36871",
        "target" : "37513",
        "shared_name" : "C16H11O8 (interacts with) C15H11O6",
        "family_id" : 148,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H11O8 (interacts with) C15H11O6",
        "interaction" : "interacts with",
        "SUID" : 37522,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38018",
        "source" : "36870",
        "target" : "37010",
        "shared_name" : "C16H13O9 (interacts with) C15H13O7",
        "family_id" : 0,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O9 (interacts with) C15H13O7",
        "interaction" : "interacts with",
        "SUID" : 38018,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37956",
        "source" : "36870",
        "target" : "36871",
        "shared_name" : "C16H13O9 (interacts with) C16H11O8",
        "family_id" : 97,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H13O9 (interacts with) C16H11O8",
        "interaction" : "interacts with",
        "SUID" : 37956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37654",
        "source" : "36870",
        "target" : "37010",
        "shared_name" : "C16H13O9 (interacts with) C15H13O7",
        "family_id" : 74,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O9 (interacts with) C15H13O7",
        "interaction" : "interacts with",
        "SUID" : 37654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37235",
        "source" : "36870",
        "target" : "37010",
        "shared_name" : "C16H13O9 (interacts with) C15H13O7",
        "family_id" : 172,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O9 (interacts with) C15H13O7",
        "interaction" : "interacts with",
        "SUID" : 37235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37011",
        "source" : "36870",
        "target" : "37010",
        "shared_name" : "C16H13O9 (interacts with) C15H13O7",
        "family_id" : 269,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O9 (interacts with) C15H13O7",
        "interaction" : "interacts with",
        "SUID" : 37011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36872",
        "source" : "36870",
        "target" : "36871",
        "shared_name" : "C16H13O9 (interacts with) C16H11O8",
        "family_id" : 148,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H13O9 (interacts with) C16H11O8",
        "interaction" : "interacts with",
        "SUID" : 36872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38081",
        "source" : "36868",
        "target" : "37104",
        "shared_name" : "C17H19O7 (interacts with) C16H19O5",
        "family_id" : 139,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O7 (interacts with) C16H19O5",
        "interaction" : "interacts with",
        "SUID" : 38081,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38041",
        "source" : "36868",
        "target" : "37104",
        "shared_name" : "C17H19O7 (interacts with) C16H19O5",
        "family_id" : 36,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O7 (interacts with) C16H19O5",
        "interaction" : "interacts with",
        "SUID" : 38041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38026",
        "source" : "36868",
        "target" : "37104",
        "shared_name" : "C17H19O7 (interacts with) C16H19O5",
        "family_id" : 335,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O7 (interacts with) C16H19O5",
        "interaction" : "interacts with",
        "SUID" : 38026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37717",
        "source" : "36868",
        "target" : "37068",
        "shared_name" : "C17H19O7 (interacts with) C17H17O6",
        "family_id" : 44,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O7 (interacts with) C17H17O6",
        "interaction" : "interacts with",
        "SUID" : 37717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37465",
        "source" : "36868",
        "target" : "37068",
        "shared_name" : "C17H19O7 (interacts with) C17H17O6",
        "family_id" : 5,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O7 (interacts with) C17H17O6",
        "interaction" : "interacts with",
        "SUID" : 37465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37427",
        "source" : "36868",
        "target" : "37068",
        "shared_name" : "C17H19O7 (interacts with) C17H17O6",
        "family_id" : 162,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O7 (interacts with) C17H17O6",
        "interaction" : "interacts with",
        "SUID" : 37427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37362",
        "source" : "36868",
        "target" : "37104",
        "shared_name" : "C17H19O7 (interacts with) C16H19O5",
        "family_id" : 13,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O7 (interacts with) C16H19O5",
        "interaction" : "interacts with",
        "SUID" : 37362,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37105",
        "source" : "36868",
        "target" : "37104",
        "shared_name" : "C17H19O7 (interacts with) C16H19O5",
        "family_id" : 337,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O7 (interacts with) C16H19O5",
        "interaction" : "interacts with",
        "SUID" : 37105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38190",
        "source" : "36867",
        "target" : "36868",
        "shared_name" : "C17H21O8 (interacts with) C17H19O7",
        "family_id" : 337,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O8 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 38190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38094",
        "source" : "36867",
        "target" : "36868",
        "shared_name" : "C17H21O8 (interacts with) C17H19O7",
        "family_id" : 12,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O8 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 38094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37516",
        "source" : "36867",
        "target" : "36827",
        "shared_name" : "C17H21O8 (interacts with) C16H21O6",
        "family_id" : 151,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H21O8 (interacts with) C16H21O6",
        "interaction" : "interacts with",
        "SUID" : 37516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37164",
        "source" : "36867",
        "target" : "36868",
        "shared_name" : "C17H21O8 (interacts with) C17H19O7",
        "family_id" : 36,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O8 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 37164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36869",
        "source" : "36867",
        "target" : "36868",
        "shared_name" : "C17H21O8 (interacts with) C17H19O7",
        "family_id" : 117,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O8 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 36869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38115",
        "source" : "36863",
        "target" : "37058",
        "shared_name" : "C15H15O7 (interacts with) C14H15O5",
        "family_id" : 48,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O7 (interacts with) C14H15O5",
        "interaction" : "interacts with",
        "SUID" : 38115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37938",
        "source" : "36863",
        "target" : "37937",
        "shared_name" : "C15H15O7 (interacts with) C15H13O6",
        "family_id" : 274,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H15O7 (interacts with) C15H13O6",
        "interaction" : "interacts with",
        "SUID" : 37938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37059",
        "source" : "36863",
        "target" : "37058",
        "shared_name" : "C15H15O7 (interacts with) C14H15O5",
        "family_id" : 298,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O7 (interacts with) C14H15O5",
        "interaction" : "interacts with",
        "SUID" : 37059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38180",
        "source" : "36862",
        "target" : "36863",
        "shared_name" : "C16H15O9 (interacts with) C15H15O7",
        "family_id" : 48,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O9 (interacts with) C15H15O7",
        "interaction" : "interacts with",
        "SUID" : 38180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36935",
        "source" : "36862",
        "target" : "36863",
        "shared_name" : "C16H15O9 (interacts with) C15H15O7",
        "family_id" : 298,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O9 (interacts with) C15H15O7",
        "interaction" : "interacts with",
        "SUID" : 36935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36864",
        "source" : "36862",
        "target" : "36863",
        "shared_name" : "C16H15O9 (interacts with) C15H15O7",
        "family_id" : 274,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O9 (interacts with) C15H15O7",
        "interaction" : "interacts with",
        "SUID" : 36864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38062",
        "source" : "36860",
        "target" : "36871",
        "shared_name" : "C17H11O10 (interacts with) C16H11O8",
        "family_id" : 111,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O10 (interacts with) C16H11O8",
        "interaction" : "interacts with",
        "SUID" : 38062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37885",
        "source" : "36860",
        "target" : "36871",
        "shared_name" : "C17H11O10 (interacts with) C16H11O8",
        "family_id" : 116,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O10 (interacts with) C16H11O8",
        "interaction" : "interacts with",
        "SUID" : 37885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37848",
        "source" : "36860",
        "target" : "36871",
        "shared_name" : "C17H11O10 (interacts with) C16H11O8",
        "family_id" : 171,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O10 (interacts with) C16H11O8",
        "interaction" : "interacts with",
        "SUID" : 37848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37828",
        "source" : "36860",
        "target" : "37827",
        "shared_name" : "C17H11O10 (interacts with) C17H9O9",
        "family_id" : 263,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H11O10 (interacts with) C17H9O9",
        "interaction" : "interacts with",
        "SUID" : 37828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37724",
        "source" : "36860",
        "target" : "36871",
        "shared_name" : "C17H11O10 (interacts with) C16H11O8",
        "family_id" : 57,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O10 (interacts with) C16H11O8",
        "interaction" : "interacts with",
        "SUID" : 37724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37616",
        "source" : "36860",
        "target" : "36871",
        "shared_name" : "C17H11O10 (interacts with) C16H11O8",
        "family_id" : 305,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H11O10 (interacts with) C16H11O8",
        "interaction" : "interacts with",
        "SUID" : 37616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38091",
        "source" : "36859",
        "target" : "36870",
        "shared_name" : "C17H13O11 (interacts with) C16H13O9",
        "family_id" : 97,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O11 (interacts with) C16H13O9",
        "interaction" : "interacts with",
        "SUID" : 38091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37980",
        "source" : "36859",
        "target" : "36860",
        "shared_name" : "C17H13O11 (interacts with) C17H11O10",
        "family_id" : 305,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H13O11 (interacts with) C17H11O10",
        "interaction" : "interacts with",
        "SUID" : 37980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37762",
        "source" : "36859",
        "target" : "36870",
        "shared_name" : "C17H13O11 (interacts with) C16H13O9",
        "family_id" : 148,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O11 (interacts with) C16H13O9",
        "interaction" : "interacts with",
        "SUID" : 37762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37481",
        "source" : "36859",
        "target" : "36870",
        "shared_name" : "C17H13O11 (interacts with) C16H13O9",
        "family_id" : 0,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O11 (interacts with) C16H13O9",
        "interaction" : "interacts with",
        "SUID" : 37481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37301",
        "source" : "36859",
        "target" : "36860",
        "shared_name" : "C17H13O11 (interacts with) C17H11O10",
        "family_id" : 278,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H13O11 (interacts with) C17H11O10",
        "interaction" : "interacts with",
        "SUID" : 37301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36861",
        "source" : "36859",
        "target" : "36860",
        "shared_name" : "C17H13O11 (interacts with) C17H11O10",
        "family_id" : 111,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H13O11 (interacts with) C17H11O10",
        "interaction" : "interacts with",
        "SUID" : 36861,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38196",
        "source" : "36856",
        "target" : "36857",
        "shared_name" : "C14H9O7 (interacts with) C14H7O6",
        "family_id" : 220,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H9O7 (interacts with) C14H7O6",
        "interaction" : "interacts with",
        "SUID" : 38196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36858",
        "source" : "36856",
        "target" : "36857",
        "shared_name" : "C14H9O7 (interacts with) C14H7O6",
        "family_id" : 55,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H9O7 (interacts with) C14H7O6",
        "interaction" : "interacts with",
        "SUID" : 36858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37158",
        "source" : "36853",
        "target" : "36854",
        "shared_name" : "C18H13O9 (interacts with) C17H13O7",
        "family_id" : 331,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H13O9 (interacts with) C17H13O7",
        "interaction" : "interacts with",
        "SUID" : 37158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37032",
        "source" : "36853",
        "target" : "36854",
        "shared_name" : "C18H13O9 (interacts with) C17H13O7",
        "family_id" : 214,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H13O9 (interacts with) C17H13O7",
        "interaction" : "interacts with",
        "SUID" : 37032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36855",
        "source" : "36853",
        "target" : "36854",
        "shared_name" : "C18H13O9 (interacts with) C17H13O7",
        "family_id" : 85,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H13O9 (interacts with) C17H13O7",
        "interaction" : "interacts with",
        "SUID" : 36855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37785",
        "source" : "36851",
        "target" : "37784",
        "shared_name" : "C14H9O8 (interacts with) C13H9O6",
        "family_id" : 308,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H9O8 (interacts with) C13H9O6",
        "interaction" : "interacts with",
        "SUID" : 37785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36866",
        "source" : "36851",
        "target" : "36865",
        "shared_name" : "C14H9O8 (interacts with) C14H7O7",
        "family_id" : 260,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H9O8 (interacts with) C14H7O7",
        "interaction" : "interacts with",
        "SUID" : 36866,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38132",
        "source" : "36850",
        "target" : "37112",
        "shared_name" : "C14H11O9 (interacts with) C13H11O7",
        "family_id" : 53,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H11O9 (interacts with) C13H11O7",
        "interaction" : "interacts with",
        "SUID" : 38132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37450",
        "source" : "36850",
        "target" : "37112",
        "shared_name" : "C14H11O9 (interacts with) C13H11O7",
        "family_id" : 10,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H11O9 (interacts with) C13H11O7",
        "interaction" : "interacts with",
        "SUID" : 37450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37113",
        "source" : "36850",
        "target" : "37112",
        "shared_name" : "C14H11O9 (interacts with) C13H11O7",
        "family_id" : 69,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H11O9 (interacts with) C13H11O7",
        "interaction" : "interacts with",
        "SUID" : 37113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36852",
        "source" : "36850",
        "target" : "36851",
        "shared_name" : "C14H11O9 (interacts with) C14H9O8",
        "family_id" : 308,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H11O9 (interacts with) C14H9O8",
        "interaction" : "interacts with",
        "SUID" : 36852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37627",
        "source" : "36848",
        "target" : "37162",
        "shared_name" : "C17H21O7 (interacts with) C17H19O6",
        "family_id" : 3,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O7 (interacts with) C17H19O6",
        "interaction" : "interacts with",
        "SUID" : 37627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37625",
        "source" : "36848",
        "target" : "37141",
        "shared_name" : "C17H21O7 (interacts with) C16H21O5",
        "family_id" : 167,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H21O7 (interacts with) C16H21O5",
        "interaction" : "interacts with",
        "SUID" : 37625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37163",
        "source" : "36848",
        "target" : "37162",
        "shared_name" : "C17H21O7 (interacts with) C17H19O6",
        "family_id" : 21,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O7 (interacts with) C17H19O6",
        "interaction" : "interacts with",
        "SUID" : 37163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37142",
        "source" : "36848",
        "target" : "37141",
        "shared_name" : "C17H21O7 (interacts with) C16H21O5",
        "family_id" : 161,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H21O7 (interacts with) C16H21O5",
        "interaction" : "interacts with",
        "SUID" : 37142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37630",
        "source" : "36847",
        "target" : "36848",
        "shared_name" : "C17H23O8 (interacts with) C17H21O7",
        "family_id" : 167,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H23O8 (interacts with) C17H21O7",
        "interaction" : "interacts with",
        "SUID" : 37630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37626",
        "source" : "36847",
        "target" : "36848",
        "shared_name" : "C17H23O8 (interacts with) C17H21O7",
        "family_id" : 161,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H23O8 (interacts with) C17H21O7",
        "interaction" : "interacts with",
        "SUID" : 37626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37309",
        "source" : "36847",
        "target" : "36848",
        "shared_name" : "C17H23O8 (interacts with) C17H21O7",
        "family_id" : 114,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H23O8 (interacts with) C17H21O7",
        "interaction" : "interacts with",
        "SUID" : 37309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36849",
        "source" : "36847",
        "target" : "36848",
        "shared_name" : "C17H23O8 (interacts with) C17H21O7",
        "family_id" : 3,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H23O8 (interacts with) C17H21O7",
        "interaction" : "interacts with",
        "SUID" : 36849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37966",
        "source" : "36844",
        "target" : "36845",
        "shared_name" : "C14H15O6 (interacts with) C14H13O5",
        "family_id" : 63,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O6 (interacts with) C14H13O5",
        "interaction" : "interacts with",
        "SUID" : 37966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37731",
        "source" : "36844",
        "target" : "36845",
        "shared_name" : "C14H15O6 (interacts with) C14H13O5",
        "family_id" : 275,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O6 (interacts with) C14H13O5",
        "interaction" : "interacts with",
        "SUID" : 37731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37554",
        "source" : "36844",
        "target" : "36845",
        "shared_name" : "C14H15O6 (interacts with) C14H13O5",
        "family_id" : 232,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O6 (interacts with) C14H13O5",
        "interaction" : "interacts with",
        "SUID" : 37554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37492",
        "source" : "36844",
        "target" : "36845",
        "shared_name" : "C14H15O6 (interacts with) C14H13O5",
        "family_id" : 75,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O6 (interacts with) C14H13O5",
        "interaction" : "interacts with",
        "SUID" : 37492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37477",
        "source" : "36844",
        "target" : "36845",
        "shared_name" : "C14H15O6 (interacts with) C14H13O5",
        "family_id" : 121,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O6 (interacts with) C14H13O5",
        "interaction" : "interacts with",
        "SUID" : 37477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37334",
        "source" : "36844",
        "target" : "36845",
        "shared_name" : "C14H15O6 (interacts with) C14H13O5",
        "family_id" : 253,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O6 (interacts with) C14H13O5",
        "interaction" : "interacts with",
        "SUID" : 37334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36846",
        "source" : "36844",
        "target" : "36845",
        "shared_name" : "C14H15O6 (interacts with) C14H13O5",
        "family_id" : 340,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O6 (interacts with) C14H13O5",
        "interaction" : "interacts with",
        "SUID" : 36846,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37850",
        "source" : "36842",
        "target" : "36820",
        "shared_name" : "C17H19O10 (interacts with) C17H17O9",
        "family_id" : 138,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O10 (interacts with) C17H17O9",
        "interaction" : "interacts with",
        "SUID" : 37850,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37612",
        "source" : "36842",
        "target" : "36862",
        "shared_name" : "C17H19O10 (interacts with) C16H15O9",
        "family_id" : 298,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C17H19O10 (interacts with) C16H15O9",
        "interaction" : "interacts with",
        "SUID" : 37612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37169",
        "source" : "36842",
        "target" : "36820",
        "shared_name" : "C17H19O10 (interacts with) C17H17O9",
        "family_id" : 135,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O10 (interacts with) C17H17O9",
        "interaction" : "interacts with",
        "SUID" : 37169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37129",
        "source" : "36842",
        "target" : "36820",
        "shared_name" : "C17H19O10 (interacts with) C17H17O9",
        "family_id" : 107,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O10 (interacts with) C17H17O9",
        "interaction" : "interacts with",
        "SUID" : 37129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37121",
        "source" : "36842",
        "target" : "36862",
        "shared_name" : "C17H19O10 (interacts with) C16H15O9",
        "family_id" : 274,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C17H19O10 (interacts with) C16H15O9",
        "interaction" : "interacts with",
        "SUID" : 37121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37111",
        "source" : "36842",
        "target" : "37110",
        "shared_name" : "C17H19O10 (interacts with) C16H19O8",
        "family_id" : 70,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O10 (interacts with) C16H19O8",
        "interaction" : "interacts with",
        "SUID" : 37111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38097",
        "source" : "36841",
        "target" : "36842",
        "shared_name" : "C18H19O12 (interacts with) C17H19O10",
        "family_id" : 138,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O12 (interacts with) C17H19O10",
        "interaction" : "interacts with",
        "SUID" : 38097,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37962",
        "source" : "36841",
        "target" : "36873",
        "shared_name" : "C18H19O12 (interacts with) C18H17O11",
        "family_id" : 244,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O12 (interacts with) C18H17O11",
        "interaction" : "interacts with",
        "SUID" : 37962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37949",
        "source" : "36841",
        "target" : "36873",
        "shared_name" : "C18H19O12 (interacts with) C18H17O11",
        "family_id" : 256,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O12 (interacts with) C18H17O11",
        "interaction" : "interacts with",
        "SUID" : 37949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37892",
        "source" : "36841",
        "target" : "36842",
        "shared_name" : "C18H19O12 (interacts with) C17H19O10",
        "family_id" : 70,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O12 (interacts with) C17H19O10",
        "interaction" : "interacts with",
        "SUID" : 37892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37488",
        "source" : "36841",
        "target" : "36873",
        "shared_name" : "C18H19O12 (interacts with) C18H17O11",
        "family_id" : 288,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O12 (interacts with) C18H17O11",
        "interaction" : "interacts with",
        "SUID" : 37488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37466",
        "source" : "36841",
        "target" : "36873",
        "shared_name" : "C18H19O12 (interacts with) C18H17O11",
        "family_id" : 312,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O12 (interacts with) C18H17O11",
        "interaction" : "interacts with",
        "SUID" : 37466,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37296",
        "source" : "36841",
        "target" : "36873",
        "shared_name" : "C18H19O12 (interacts with) C18H17O11",
        "family_id" : 66,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O12 (interacts with) C18H17O11",
        "interaction" : "interacts with",
        "SUID" : 37296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36874",
        "source" : "36841",
        "target" : "36873",
        "shared_name" : "C18H19O12 (interacts with) C18H17O11",
        "family_id" : 115,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O12 (interacts with) C18H17O11",
        "interaction" : "interacts with",
        "SUID" : 36874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36843",
        "source" : "36841",
        "target" : "36842",
        "shared_name" : "C18H19O12 (interacts with) C17H19O10",
        "family_id" : 135,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O12 (interacts with) C17H19O10",
        "interaction" : "interacts with",
        "SUID" : 36843,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38239",
        "source" : "36838",
        "target" : "36839",
        "shared_name" : "C20H17O9 (interacts with) C19H17O7",
        "family_id" : 89,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H17O9 (interacts with) C19H17O7",
        "interaction" : "interacts with",
        "SUID" : 38239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36840",
        "source" : "36838",
        "target" : "36839",
        "shared_name" : "C20H17O9 (interacts with) C19H17O7",
        "family_id" : 142,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H17O9 (interacts with) C19H17O7",
        "interaction" : "interacts with",
        "SUID" : 36840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37358",
        "source" : "36836",
        "target" : "37357",
        "shared_name" : "C16H17O6 (interacts with) C15H17O4",
        "family_id" : 254,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O6 (interacts with) C15H17O4",
        "interaction" : "interacts with",
        "SUID" : 37358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38073",
        "source" : "36835",
        "target" : "38057",
        "shared_name" : "C16H19O7 (interacts with) C15H19O5",
        "family_id" : 249,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O7 (interacts with) C15H19O5",
        "interaction" : "interacts with",
        "SUID" : 38073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37359",
        "source" : "36835",
        "target" : "36836",
        "shared_name" : "C16H19O7 (interacts with) C16H17O6",
        "family_id" : 254,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O7 (interacts with) C16H17O6",
        "interaction" : "interacts with",
        "SUID" : 37359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36837",
        "source" : "36835",
        "target" : "36836",
        "shared_name" : "C16H19O7 (interacts with) C16H17O6",
        "family_id" : 127,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O7 (interacts with) C16H17O6",
        "interaction" : "interacts with",
        "SUID" : 36837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37918",
        "source" : "36833",
        "target" : "37393",
        "shared_name" : "C14H15O7 (interacts with) C14H13O6",
        "family_id" : 58,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O7 (interacts with) C14H13O6",
        "interaction" : "interacts with",
        "SUID" : 37918,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37797",
        "source" : "36833",
        "target" : "37393",
        "shared_name" : "C14H15O7 (interacts with) C14H13O6",
        "family_id" : 136,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O7 (interacts with) C14H13O6",
        "interaction" : "interacts with",
        "SUID" : 37797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37495",
        "source" : "36833",
        "target" : "37393",
        "shared_name" : "C14H15O7 (interacts with) C14H13O6",
        "family_id" : 327,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O7 (interacts with) C14H13O6",
        "interaction" : "interacts with",
        "SUID" : 37495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37436",
        "source" : "36833",
        "target" : "37393",
        "shared_name" : "C14H15O7 (interacts with) C14H13O6",
        "family_id" : 319,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H15O7 (interacts with) C14H13O6",
        "interaction" : "interacts with",
        "SUID" : 37436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38118",
        "source" : "36832",
        "target" : "37916",
        "shared_name" : "C14H17O8 (interacts with) C13H17O6",
        "family_id" : 120,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H17O8 (interacts with) C13H17O6",
        "interaction" : "interacts with",
        "SUID" : 38118,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38085",
        "source" : "36832",
        "target" : "37916",
        "shared_name" : "C14H17O8 (interacts with) C13H17O6",
        "family_id" : 175,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H17O8 (interacts with) C13H17O6",
        "interaction" : "interacts with",
        "SUID" : 38085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37917",
        "source" : "36832",
        "target" : "37916",
        "shared_name" : "C14H17O8 (interacts with) C13H17O6",
        "family_id" : 292,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H17O8 (interacts with) C13H17O6",
        "interaction" : "interacts with",
        "SUID" : 37917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37453",
        "source" : "36832",
        "target" : "36833",
        "shared_name" : "C14H17O8 (interacts with) C14H15O7",
        "family_id" : 327,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H17O8 (interacts with) C14H15O7",
        "interaction" : "interacts with",
        "SUID" : 37453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37284",
        "source" : "36832",
        "target" : "36833",
        "shared_name" : "C14H17O8 (interacts with) C14H15O7",
        "family_id" : 282,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H17O8 (interacts with) C14H15O7",
        "interaction" : "interacts with",
        "SUID" : 37284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36834",
        "source" : "36832",
        "target" : "36833",
        "shared_name" : "C14H17O8 (interacts with) C14H15O7",
        "family_id" : 136,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H17O8 (interacts with) C14H15O7",
        "interaction" : "interacts with",
        "SUID" : 36834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37992",
        "source" : "36829",
        "target" : "36830",
        "shared_name" : "C19H17O8 (interacts with) C18H17O6",
        "family_id" : 186,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H17O8 (interacts with) C18H17O6",
        "interaction" : "interacts with",
        "SUID" : 37992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36831",
        "source" : "36829",
        "target" : "36830",
        "shared_name" : "C19H17O8 (interacts with) C18H17O6",
        "family_id" : 239,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H17O8 (interacts with) C18H17O6",
        "interaction" : "interacts with",
        "SUID" : 36831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38053",
        "source" : "36827",
        "target" : "38052",
        "shared_name" : "C16H21O6 (interacts with) C15H21O4",
        "family_id" : 203,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O6 (interacts with) C15H21O4",
        "interaction" : "interacts with",
        "SUID" : 38053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38235",
        "source" : "36826",
        "target" : "36827",
        "shared_name" : "C16H23O7 (interacts with) C16H21O6",
        "family_id" : 309,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H23O7 (interacts with) C16H21O6",
        "interaction" : "interacts with",
        "SUID" : 38235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36828",
        "source" : "36826",
        "target" : "36827",
        "shared_name" : "C16H23O7 (interacts with) C16H21O6",
        "family_id" : 203,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H23O7 (interacts with) C16H21O6",
        "interaction" : "interacts with",
        "SUID" : 36828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37809",
        "source" : "36824",
        "target" : "37218",
        "shared_name" : "C16H13O7 (interacts with) C15H13O5",
        "family_id" : 152,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O7 (interacts with) C15H13O5",
        "interaction" : "interacts with",
        "SUID" : 37809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37798",
        "source" : "36824",
        "target" : "37218",
        "shared_name" : "C16H13O7 (interacts with) C15H13O5",
        "family_id" : 264,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O7 (interacts with) C15H13O5",
        "interaction" : "interacts with",
        "SUID" : 37798,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37316",
        "source" : "36824",
        "target" : "37218",
        "shared_name" : "C16H13O7 (interacts with) C15H13O5",
        "family_id" : 294,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H13O7 (interacts with) C15H13O5",
        "interaction" : "interacts with",
        "SUID" : 37316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37941",
        "source" : "36823",
        "target" : "37124",
        "shared_name" : "C16H15O8 (interacts with) C15H15O6",
        "family_id" : 276,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O8 (interacts with) C15H15O6",
        "interaction" : "interacts with",
        "SUID" : 37941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37811",
        "source" : "36823",
        "target" : "37124",
        "shared_name" : "C16H15O8 (interacts with) C15H15O6",
        "family_id" : 146,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O8 (interacts with) C15H15O6",
        "interaction" : "interacts with",
        "SUID" : 37811,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37598",
        "source" : "36823",
        "target" : "37124",
        "shared_name" : "C16H15O8 (interacts with) C15H15O6",
        "family_id" : 129,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O8 (interacts with) C15H15O6",
        "interaction" : "interacts with",
        "SUID" : 37598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37512",
        "source" : "36823",
        "target" : "37124",
        "shared_name" : "C16H15O8 (interacts with) C15H15O6",
        "family_id" : 205,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O8 (interacts with) C15H15O6",
        "interaction" : "interacts with",
        "SUID" : 37512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37462",
        "source" : "36823",
        "target" : "36824",
        "shared_name" : "C16H15O8 (interacts with) C16H13O7",
        "family_id" : 264,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H15O8 (interacts with) C16H13O7",
        "interaction" : "interacts with",
        "SUID" : 37462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37125",
        "source" : "36823",
        "target" : "37124",
        "shared_name" : "C16H15O8 (interacts with) C15H15O6",
        "family_id" : 145,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H15O8 (interacts with) C15H15O6",
        "interaction" : "interacts with",
        "SUID" : 37125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36825",
        "source" : "36823",
        "target" : "36824",
        "shared_name" : "C16H15O8 (interacts with) C16H13O7",
        "family_id" : 294,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H15O8 (interacts with) C16H13O7",
        "interaction" : "interacts with",
        "SUID" : 36825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38088",
        "source" : "36821",
        "target" : "36854",
        "shared_name" : "C17H15O8 (interacts with) C17H13O7",
        "family_id" : 23,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O8 (interacts with) C17H13O7",
        "interaction" : "interacts with",
        "SUID" : 38088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37633",
        "source" : "36821",
        "target" : "36884",
        "shared_name" : "C17H15O8 (interacts with) C16H15O6",
        "family_id" : 182,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H15O8 (interacts with) C16H15O6",
        "interaction" : "interacts with",
        "SUID" : 37633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37455",
        "source" : "36821",
        "target" : "36854",
        "shared_name" : "C17H15O8 (interacts with) C17H13O7",
        "family_id" : 18,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H15O8 (interacts with) C17H13O7",
        "interaction" : "interacts with",
        "SUID" : 37455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38224",
        "source" : "36820",
        "target" : "36883",
        "shared_name" : "C17H17O9 (interacts with) C16H17O7",
        "family_id" : 66,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O9 (interacts with) C16H17O7",
        "interaction" : "interacts with",
        "SUID" : 38224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38171",
        "source" : "36820",
        "target" : "36883",
        "shared_name" : "C17H17O9 (interacts with) C16H17O7",
        "family_id" : 138,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O9 (interacts with) C16H17O7",
        "interaction" : "interacts with",
        "SUID" : 38171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37607",
        "source" : "36820",
        "target" : "36883",
        "shared_name" : "C17H17O9 (interacts with) C16H17O7",
        "family_id" : 312,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O9 (interacts with) C16H17O7",
        "interaction" : "interacts with",
        "SUID" : 37607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37570",
        "source" : "36820",
        "target" : "36883",
        "shared_name" : "C17H17O9 (interacts with) C16H17O7",
        "family_id" : 107,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O9 (interacts with) C16H17O7",
        "interaction" : "interacts with",
        "SUID" : 37570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37213",
        "source" : "36820",
        "target" : "36883",
        "shared_name" : "C17H17O9 (interacts with) C16H17O7",
        "family_id" : 244,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O9 (interacts with) C16H17O7",
        "interaction" : "interacts with",
        "SUID" : 37213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37099",
        "source" : "36820",
        "target" : "36883",
        "shared_name" : "C17H17O9 (interacts with) C16H17O7",
        "family_id" : 288,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O9 (interacts with) C16H17O7",
        "interaction" : "interacts with",
        "SUID" : 37099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36822",
        "source" : "36820",
        "target" : "36821",
        "shared_name" : "C17H17O9 (interacts with) C17H15O8",
        "family_id" : 135,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H17O9 (interacts with) C17H15O8",
        "interaction" : "interacts with",
        "SUID" : 36822,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37816",
        "source" : "36818",
        "target" : "36894",
        "shared_name" : "C17H17O10 (interacts with) C16H17O8",
        "family_id" : 94,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O10 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 37816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37780",
        "source" : "36818",
        "target" : "36924",
        "shared_name" : "C17H17O10 (interacts with) C17H15O9",
        "family_id" : 257,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H17O10 (interacts with) C17H15O9",
        "interaction" : "interacts with",
        "SUID" : 37780,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37332",
        "source" : "36818",
        "target" : "36924",
        "shared_name" : "C17H17O10 (interacts with) C17H15O9",
        "family_id" : 165,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H17O10 (interacts with) C17H15O9",
        "interaction" : "interacts with",
        "SUID" : 37332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37148",
        "source" : "36818",
        "target" : "36924",
        "shared_name" : "C17H17O10 (interacts with) C17H15O9",
        "family_id" : 106,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H17O10 (interacts with) C17H15O9",
        "interaction" : "interacts with",
        "SUID" : 37148,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37009",
        "source" : "36818",
        "target" : "36894",
        "shared_name" : "C17H17O10 (interacts with) C16H17O8",
        "family_id" : 210,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O10 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 37009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36940",
        "source" : "36818",
        "target" : "36894",
        "shared_name" : "C17H17O10 (interacts with) C16H17O8",
        "family_id" : 246,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O10 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 36940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36936",
        "source" : "36818",
        "target" : "36894",
        "shared_name" : "C17H17O10 (interacts with) C16H17O8",
        "family_id" : 39,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O10 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 36936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38167",
        "source" : "36817",
        "target" : "36899",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 275,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 38167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38093",
        "source" : "36817",
        "target" : "36818",
        "shared_name" : "C17H19O11 (interacts with) C17H17O10",
        "family_id" : 210,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O11 (interacts with) C17H17O10",
        "interaction" : "interacts with",
        "SUID" : 38093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38006",
        "source" : "36817",
        "target" : "36899",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 198,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 38006,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37991",
        "source" : "36817",
        "target" : "36818",
        "shared_name" : "C17H19O11 (interacts with) C17H17O10",
        "family_id" : 39,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O11 (interacts with) C17H17O10",
        "interaction" : "interacts with",
        "SUID" : 37991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37985",
        "source" : "36817",
        "target" : "36899",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 37,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 37985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37968",
        "source" : "36817",
        "target" : "36899",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 49,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 37968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37942",
        "source" : "36817",
        "target" : "36899",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 286,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 37942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37711",
        "source" : "36817",
        "target" : "36818",
        "shared_name" : "C17H19O11 (interacts with) C17H17O10",
        "family_id" : 246,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O11 (interacts with) C17H17O10",
        "interaction" : "interacts with",
        "SUID" : 37711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37543",
        "source" : "36817",
        "target" : "36899",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 236,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 37543,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37493",
        "source" : "36817",
        "target" : "36899",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 144,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 37493,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37368",
        "source" : "36817",
        "target" : "36899",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 8,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 37368,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37348",
        "source" : "36817",
        "target" : "36818",
        "shared_name" : "C17H19O11 (interacts with) C17H17O10",
        "family_id" : 94,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O11 (interacts with) C17H17O10",
        "interaction" : "interacts with",
        "SUID" : 37348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37285",
        "source" : "36817",
        "target" : "36899",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 291,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 37285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37266",
        "source" : "36817",
        "target" : "36899",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 303,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 37266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37227",
        "source" : "36817",
        "target" : "36818",
        "shared_name" : "C17H19O11 (interacts with) C17H17O10",
        "family_id" : 192,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O11 (interacts with) C17H17O10",
        "interaction" : "interacts with",
        "SUID" : 37227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37042",
        "source" : "36817",
        "target" : "37041",
        "shared_name" : "C17H19O11 (interacts with) C16H15O10",
        "family_id" : 75,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C17H19O11 (interacts with) C16H15O10",
        "interaction" : "interacts with",
        "SUID" : 37042,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36900",
        "source" : "36817",
        "target" : "36899",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 170,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 36900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36819",
        "source" : "36817",
        "target" : "36818",
        "shared_name" : "C17H19O11 (interacts with) C17H17O10",
        "family_id" : 165,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O11 (interacts with) C17H17O10",
        "interaction" : "interacts with",
        "SUID" : 36819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37482",
        "source" : "36814",
        "target" : "36815",
        "shared_name" : "C15H9O8 (interacts with) C14H9O6",
        "family_id" : 102,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H9O8 (interacts with) C14H9O6",
        "interaction" : "interacts with",
        "SUID" : 37482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36816",
        "source" : "36814",
        "target" : "36815",
        "shared_name" : "C15H9O8 (interacts with) C14H9O6",
        "family_id" : 137,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H9O8 (interacts with) C14H9O6",
        "interaction" : "interacts with",
        "SUID" : 36816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38228",
        "source" : "36812",
        "target" : "37167",
        "shared_name" : "C18H19O7 (interacts with) C17H19O5",
        "family_id" : 219,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O7 (interacts with) C17H19O5",
        "interaction" : "interacts with",
        "SUID" : 38228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37819",
        "source" : "36812",
        "target" : "37167",
        "shared_name" : "C18H19O7 (interacts with) C17H19O5",
        "family_id" : 197,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O7 (interacts with) C17H19O5",
        "interaction" : "interacts with",
        "SUID" : 37819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37775",
        "source" : "36812",
        "target" : "37167",
        "shared_name" : "C18H19O7 (interacts with) C17H19O5",
        "family_id" : 233,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O7 (interacts with) C17H19O5",
        "interaction" : "interacts with",
        "SUID" : 37775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37443",
        "source" : "36812",
        "target" : "37167",
        "shared_name" : "C18H19O7 (interacts with) C17H19O5",
        "family_id" : 124,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O7 (interacts with) C17H19O5",
        "interaction" : "interacts with",
        "SUID" : 37443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37347",
        "source" : "36812",
        "target" : "37167",
        "shared_name" : "C18H19O7 (interacts with) C17H19O5",
        "family_id" : 227,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O7 (interacts with) C17H19O5",
        "interaction" : "interacts with",
        "SUID" : 37347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37331",
        "source" : "36812",
        "target" : "37167",
        "shared_name" : "C18H19O7 (interacts with) C17H19O5",
        "family_id" : 17,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O7 (interacts with) C17H19O5",
        "interaction" : "interacts with",
        "SUID" : 37331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37231",
        "source" : "36812",
        "target" : "37167",
        "shared_name" : "C18H19O7 (interacts with) C17H19O5",
        "family_id" : 67,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O7 (interacts with) C17H19O5",
        "interaction" : "interacts with",
        "SUID" : 37231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37228",
        "source" : "36812",
        "target" : "37167",
        "shared_name" : "C18H19O7 (interacts with) C17H19O5",
        "family_id" : 304,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O7 (interacts with) C17H19O5",
        "interaction" : "interacts with",
        "SUID" : 37228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37168",
        "source" : "36812",
        "target" : "37167",
        "shared_name" : "C18H19O7 (interacts with) C17H19O5",
        "family_id" : 320,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O7 (interacts with) C17H19O5",
        "interaction" : "interacts with",
        "SUID" : 37168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38172",
        "source" : "36811",
        "target" : "37252",
        "shared_name" : "C19H19O9 (interacts with) C18H15O8",
        "family_id" : 311,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1H4O1",
        "name" : "C19H19O9 (interacts with) C18H15O8",
        "interaction" : "interacts with",
        "SUID" : 38172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38049",
        "source" : "36811",
        "target" : "36829",
        "shared_name" : "C19H19O9 (interacts with) C19H17O8",
        "family_id" : 150,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H19O9 (interacts with) C19H17O8",
        "interaction" : "interacts with",
        "SUID" : 38049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "38048",
        "source" : "36811",
        "target" : "36812",
        "shared_name" : "C19H19O9 (interacts with) C18H19O7",
        "family_id" : 304,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O9 (interacts with) C18H19O7",
        "interaction" : "interacts with",
        "SUID" : 38048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37715",
        "source" : "36811",
        "target" : "36829",
        "shared_name" : "C19H19O9 (interacts with) C19H17O8",
        "family_id" : 98,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H19O9 (interacts with) C19H17O8",
        "interaction" : "interacts with",
        "SUID" : 37715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37467",
        "source" : "36811",
        "target" : "36812",
        "shared_name" : "C19H19O9 (interacts with) C18H19O7",
        "family_id" : 233,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O9 (interacts with) C18H19O7",
        "interaction" : "interacts with",
        "SUID" : 37467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37454",
        "source" : "36811",
        "target" : "36812",
        "shared_name" : "C19H19O9 (interacts with) C18H19O7",
        "family_id" : 219,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O9 (interacts with) C18H19O7",
        "interaction" : "interacts with",
        "SUID" : 37454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37402",
        "source" : "36811",
        "target" : "36829",
        "shared_name" : "C19H19O9 (interacts with) C19H17O8",
        "family_id" : 131,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H19O9 (interacts with) C19H17O8",
        "interaction" : "interacts with",
        "SUID" : 37402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37342",
        "source" : "36811",
        "target" : "36829",
        "shared_name" : "C19H19O9 (interacts with) C19H17O8",
        "family_id" : 239,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H19O9 (interacts with) C19H17O8",
        "interaction" : "interacts with",
        "SUID" : 37342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "37189",
        "source" : "36811",
        "target" : "36829",
        "shared_name" : "C19H19O9 (interacts with) C19H17O8",
        "family_id" : 186,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H19O9 (interacts with) C19H17O8",
        "interaction" : "interacts with",
        "SUID" : 37189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "36813",
        "source" : "36811",
        "target" : "36812",
        "shared_name" : "C19H19O9 (interacts with) C18H19O7",
        "family_id" : 197,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O9 (interacts with) C18H19O7",
        "interaction" : "interacts with",
        "SUID" : 36813,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}