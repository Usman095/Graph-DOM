var networks = {"Common_families_cyto_input.csv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.2",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "Common_families_cyto_input.csv",
    "name" : "Common_families_cyto_input.csv",
    "SUID" : 9484,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "10074",
        "shared_name" : "C15H13O8",
        "name" : "C15H13O8",
        "SUID" : 10074,
        "selected" : false
      },
      "position" : {
        "x" : -179.54479973052503,
        "y" : 1011.3141477492547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10071",
        "shared_name" : "C14H19O6",
        "name" : "C14H19O6",
        "SUID" : 10071,
        "selected" : false
      },
      "position" : {
        "x" : -632.5290297720289,
        "y" : 741.0839231398797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10062",
        "shared_name" : "C18H15O10",
        "name" : "C18H15O10",
        "SUID" : 10062,
        "selected" : false
      },
      "position" : {
        "x" : 863.5841446664476,
        "y" : -929.2784654709601
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10054",
        "shared_name" : "C15H21O9",
        "name" : "C15H21O9",
        "SUID" : 10054,
        "selected" : false
      },
      "position" : {
        "x" : -808.459220812068,
        "y" : 784.8617856887079
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10046",
        "shared_name" : "C16H13O10",
        "name" : "C16H13O10",
        "SUID" : 10046,
        "selected" : false
      },
      "position" : {
        "x" : 121.71530158783435,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10045",
        "shared_name" : "C17H13O12",
        "name" : "C17H13O12",
        "SUID" : 10045,
        "selected" : false
      },
      "position" : {
        "x" : 118.69784934784411,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10042",
        "shared_name" : "C23H27O8",
        "name" : "C23H27O8",
        "SUID" : 10042,
        "selected" : false
      },
      "position" : {
        "x" : 18.697849347844112,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10041",
        "shared_name" : "C24H27O10",
        "name" : "C24H27O10",
        "SUID" : 10041,
        "selected" : false
      },
      "position" : {
        "x" : 15.680397107853878,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10038",
        "shared_name" : "C19H23O7",
        "name" : "C19H23O7",
        "SUID" : 10038,
        "selected" : false
      },
      "position" : {
        "x" : -584.5171889517164,
        "y" : -753.3291093918585
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10034",
        "shared_name" : "C17H23O6",
        "name" : "C17H23O6",
        "SUID" : 10034,
        "selected" : false
      },
      "position" : {
        "x" : 632.4539719369554,
        "y" : -1133.9819032761359
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10031",
        "shared_name" : "C21H27O11",
        "name" : "C21H27O11",
        "SUID" : 10031,
        "selected" : false
      },
      "position" : {
        "x" : 168.58621986176013,
        "y" : 1142.2330625441766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10028",
        "shared_name" : "C12H13O7",
        "name" : "C12H13O7",
        "SUID" : 10028,
        "selected" : false
      },
      "position" : {
        "x" : -84.31960289214612,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10027",
        "shared_name" : "C13H13O9",
        "name" : "C13H13O9",
        "SUID" : 10027,
        "selected" : false
      },
      "position" : {
        "x" : -87.33705513213636,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10020",
        "shared_name" : "C21H23O8",
        "name" : "C21H23O8",
        "SUID" : 10020,
        "selected" : false
      },
      "position" : {
        "x" : 475.9327049996996,
        "y" : 101.47180918724303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10018",
        "shared_name" : "C14H21O6",
        "name" : "C14H21O6",
        "SUID" : 10018,
        "selected" : false
      },
      "position" : {
        "x" : -403.0587310049391,
        "y" : -941.9804613205695
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10016",
        "shared_name" : "C15H15O9",
        "name" : "C15H15O9",
        "SUID" : 10016,
        "selected" : false
      },
      "position" : {
        "x" : -259.76892416213514,
        "y" : 934.6781309035516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10013",
        "shared_name" : "C20H25O8",
        "name" : "C20H25O8",
        "SUID" : 10013,
        "selected" : false
      },
      "position" : {
        "x" : 4.108009412541378,
        "y" : 1279.6309507277704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10012",
        "shared_name" : "C21H25O10",
        "name" : "C21H25O10",
        "SUID" : 10012,
        "selected" : false
      },
      "position" : {
        "x" : 87.66922767426013,
        "y" : 1215.9557493117547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10006",
        "shared_name" : "C19H21O8",
        "name" : "C19H21O8",
        "SUID" : 10006,
        "selected" : false
      },
      "position" : {
        "x" : 180.30895240570544,
        "y" : -620.0422250839972
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9996",
        "shared_name" : "C15H19O6",
        "name" : "C15H19O6",
        "SUID" : 9996,
        "selected" : false
      },
      "position" : {
        "x" : 1187.3921356942797,
        "y" : -941.9804613205695
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9987",
        "shared_name" : "C17H17O9",
        "name" : "C17H17O9",
        "SUID" : 9987,
        "selected" : false
      },
      "position" : {
        "x" : 974.0491410043383,
        "y" : -709.2545549484992
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9986",
        "shared_name" : "C18H17O11",
        "name" : "C18H17O11",
        "SUID" : 9986,
        "selected" : false
      },
      "position" : {
        "x" : 917.4246292855883,
        "y" : -827.9658434006476
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9983",
        "shared_name" : "C16H23O8",
        "name" : "C16H23O8",
        "SUID" : 9983,
        "selected" : false
      },
      "position" : {
        "x" : -187.33705513213636,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9982",
        "shared_name" : "C17H23O10",
        "name" : "C17H23O10",
        "SUID" : 9982,
        "selected" : false
      },
      "position" : {
        "x" : -190.3545073721266,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9980",
        "shared_name" : "C18H15O7",
        "name" : "C18H15O7",
        "SUID" : 9980,
        "selected" : false
      },
      "position" : {
        "x" : -438.4009398672438,
        "y" : 361.90797404320006
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9978",
        "shared_name" : "C20H23O7",
        "name" : "C20H23O7",
        "SUID" : 9978,
        "selected" : false
      },
      "position" : {
        "x" : -299.1569442007399,
        "y" : 1142.2330625441766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9970",
        "shared_name" : "C14H15O7",
        "name" : "C14H15O7",
        "SUID" : 9970,
        "selected" : false
      },
      "position" : {
        "x" : -347.6135634634352,
        "y" : 862.9849241164422
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9966",
        "shared_name" : "C21H21O9",
        "name" : "C21H21O9",
        "SUID" : 9966,
        "selected" : false
      },
      "position" : {
        "x" : -290.3545073721266,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9965",
        "shared_name" : "C22H21O11",
        "name" : "C22H21O11",
        "SUID" : 9965,
        "selected" : false
      },
      "position" : {
        "x" : -293.3719596121168,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9959",
        "shared_name" : "C16H19O7",
        "name" : "C16H19O7",
        "SUID" : 9959,
        "selected" : false
      },
      "position" : {
        "x" : -9.017631456599247,
        "y" : 320.490852155993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9947",
        "shared_name" : "C15H15O7",
        "name" : "C15H15O7",
        "SUID" : 9947,
        "selected" : false
      },
      "position" : {
        "x" : 375.9327049996996,
        "y" : 170.30536631614928
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9945",
        "shared_name" : "C19H15O10",
        "name" : "C19H15O10",
        "SUID" : 9945,
        "selected" : false
      },
      "position" : {
        "x" : -393.3719596121168,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9944",
        "shared_name" : "C19H17O11",
        "name" : "C19H17O11",
        "SUID" : 9944,
        "selected" : false
      },
      "position" : {
        "x" : -396.38941185210706,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9937",
        "shared_name" : "C16H17O9",
        "name" : "C16H17O9",
        "SUID" : 9937,
        "selected" : false
      },
      "position" : {
        "x" : -664.0043944570875,
        "y" : 1042.2330625441766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9935",
        "shared_name" : "C16H21O6",
        "name" : "C16H21O6",
        "SUID" : 9935,
        "selected" : false
      },
      "position" : {
        "x" : -807.1803206655836,
        "y" : -171.07655735938783
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9931",
        "shared_name" : "C16H23O6",
        "name" : "C16H23O6",
        "SUID" : 9931,
        "selected" : false
      },
      "position" : {
        "x" : -274.0914229605055,
        "y" : -1041.9804613205695
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9928",
        "shared_name" : "C13H15O7",
        "name" : "C13H15O7",
        "SUID" : 9928,
        "selected" : false
      },
      "position" : {
        "x" : -496.38941185210706,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9927",
        "shared_name" : "C14H15O9",
        "name" : "C14H15O9",
        "SUID" : 9927,
        "selected" : false
      },
      "position" : {
        "x" : -499.4068640920973,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9923",
        "shared_name" : "C19H21O7",
        "name" : "C19H21O7",
        "SUID" : 9923,
        "selected" : false
      },
      "position" : {
        "x" : 143.00748451019763,
        "y" : -1561.751423082044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9921",
        "shared_name" : "C20H25O7",
        "name" : "C20H25O7",
        "SUID" : 9921,
        "selected" : false
      },
      "position" : {
        "x" : 684.8831139352465,
        "y" : 440.1723287490106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9913",
        "shared_name" : "C14H17O7",
        "name" : "C14H17O7",
        "SUID" : 9913,
        "selected" : false
      },
      "position" : {
        "x" : -399.1569442007399,
        "y" : 1321.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9911",
        "shared_name" : "C22H15O11",
        "name" : "C22H15O11",
        "SUID" : 9911,
        "selected" : false
      },
      "position" : {
        "x" : 219.86124427582263,
        "y" : 863.2329709914422
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9908",
        "shared_name" : "C21H17O13",
        "name" : "C21H17O13",
        "SUID" : 9908,
        "selected" : false
      },
      "position" : {
        "x" : -765.4253920767164,
        "y" : -1711.7111208054328
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9903",
        "shared_name" : "C22H25O9",
        "name" : "C22H25O9",
        "SUID" : 9903,
        "selected" : false
      },
      "position" : {
        "x" : -758.0682143423414,
        "y" : 438.7290113356805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9902",
        "shared_name" : "C23H25O11",
        "name" : "C23H25O11",
        "SUID" : 9902,
        "selected" : false
      },
      "position" : {
        "x" : -770.8629454824782,
        "y" : 323.8930128005243
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9898",
        "shared_name" : "C16H21O7",
        "name" : "C16H21O7",
        "SUID" : 9898,
        "selected" : false
      },
      "position" : {
        "x" : -397.8231314871168,
        "y" : 1.471809187243025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9894",
        "shared_name" : "C19H19O7",
        "name" : "C19H19O7",
        "SUID" : 9894,
        "selected" : false
      },
      "position" : {
        "x" : 148.10900123383044,
        "y" : -941.9804613205695
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9891",
        "shared_name" : "C22H27O8",
        "name" : "C22H27O8",
        "SUID" : 9891,
        "selected" : false
      },
      "position" : {
        "x" : -599.4068640920973,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9890",
        "shared_name" : "C23H27O10",
        "name" : "C23H27O10",
        "SUID" : 9890,
        "selected" : false
      },
      "position" : {
        "x" : -602.4243163320875,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9887",
        "shared_name" : "C15H15O8",
        "name" : "C15H15O8",
        "SUID" : 9887,
        "selected" : false
      },
      "position" : {
        "x" : -519.7235030386305,
        "y" : 1142.2330625441766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9886",
        "shared_name" : "C15H17O9",
        "name" : "C15H17O9",
        "SUID" : 9886,
        "selected" : false
      },
      "position" : {
        "x" : -453.6687239858961,
        "y" : 1228.456641950915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9869",
        "shared_name" : "C14H11O8",
        "name" : "C14H11O8",
        "SUID" : 9869,
        "selected" : false
      },
      "position" : {
        "x" : -702.4243163320875,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9868",
        "shared_name" : "C14H13O9",
        "name" : "C14H13O9",
        "SUID" : 9868,
        "selected" : false
      },
      "position" : {
        "x" : -705.4417685720778,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9857",
        "shared_name" : "C20H17O11",
        "name" : "C20H17O11",
        "SUID" : 9857,
        "selected" : false
      },
      "position" : {
        "x" : -728.314445421443,
        "y" : -1611.1176149460578
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9850",
        "shared_name" : "C22H21O12",
        "name" : "C22H21O12",
        "SUID" : 9850,
        "selected" : false
      },
      "position" : {
        "x" : -684.9567031118727,
        "y" : -630.5610277268195
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9846",
        "shared_name" : "C21H27O8",
        "name" : "C21H27O8",
        "SUID" : 9846,
        "selected" : false
      },
      "position" : {
        "x" : -642.2557677481032,
        "y" : 602.5825956252313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9843",
        "shared_name" : "C13H9O8",
        "name" : "C13H9O8",
        "SUID" : 9843,
        "selected" : false
      },
      "position" : {
        "x" : -805.4417685720778,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9842",
        "shared_name" : "C14H9O10",
        "name" : "C14H9O10",
        "SUID" : 9842,
        "selected" : false
      },
      "position" : {
        "x" : -808.459220812068,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9838",
        "shared_name" : "C13H19O6",
        "name" : "C13H19O6",
        "SUID" : 9838,
        "selected" : false
      },
      "position" : {
        "x" : 683.6734810617113,
        "y" : 1142.2330625441766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9837",
        "shared_name" : "C14H19O8",
        "name" : "C14H19O8",
        "SUID" : 9837,
        "selected" : false
      },
      "position" : {
        "x" : 680.6560288217211,
        "y" : 1249.9552305129266
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9831",
        "shared_name" : "C22H27O9",
        "name" : "C22H27O9",
        "SUID" : 9831,
        "selected" : false
      },
      "position" : {
        "x" : 440.42780311371325,
        "y" : 920.2778852370477
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9822",
        "shared_name" : "C15H11O8",
        "name" : "C15H11O8",
        "SUID" : 9822,
        "selected" : false
      },
      "position" : {
        "x" : 580.6560288217211,
        "y" : 1142.2330625441766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9821",
        "shared_name" : "C15H13O9",
        "name" : "C15H13O9",
        "SUID" : 9821,
        "selected" : false
      },
      "position" : {
        "x" : 577.6385765817308,
        "y" : 1249.9552305129266
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9817",
        "shared_name" : "C18H17O8",
        "name" : "C18H17O8",
        "SUID" : 9817,
        "selected" : false
      },
      "position" : {
        "x" : -181.4991378042555,
        "y" : 233.5617444899774
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9810",
        "shared_name" : "C19H19O12",
        "name" : "C19H19O12",
        "SUID" : 9810,
        "selected" : false
      },
      "position" : {
        "x" : -275.00100033019544,
        "y" : -343.16927357642885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9808",
        "shared_name" : "C21H27O9",
        "name" : "C21H27O9",
        "SUID" : 9808,
        "selected" : false
      },
      "position" : {
        "x" : 477.63857658173083,
        "y" : 1142.2330625441766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9807",
        "shared_name" : "C22H27O11",
        "name" : "C22H27O11",
        "SUID" : 9807,
        "selected" : false
      },
      "position" : {
        "x" : 474.6211243417406,
        "y" : 1249.9552305129266
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9805",
        "shared_name" : "C20H19O8",
        "name" : "C20H19O8",
        "SUID" : 9805,
        "selected" : false
      },
      "position" : {
        "x" : 254.60895545746325,
        "y" : -1434.9308702561163
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9802",
        "shared_name" : "C17H19O7",
        "name" : "C17H19O7",
        "SUID" : 9802,
        "selected" : false
      },
      "position" : {
        "x" : -669.0421675894117,
        "y" : -114.17811938255068
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9799",
        "shared_name" : "C20H19O10",
        "name" : "C20H19O10",
        "SUID" : 9799,
        "selected" : false
      },
      "position" : {
        "x" : 901.4998741891527,
        "y" : -1602.9221498581671
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9798",
        "shared_name" : "C21H19O12",
        "name" : "C21H19O12",
        "SUID" : 9798,
        "selected" : false
      },
      "position" : {
        "x" : 900.3347702767992,
        "y" : -1711.7111208054328
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9796",
        "shared_name" : "C22H27O10",
        "name" : "C22H27O10",
        "SUID" : 9796,
        "selected" : false
      },
      "position" : {
        "x" : -737.3261565420485,
        "y" : 553.5742566970087
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9795",
        "shared_name" : "C22H29O11",
        "name" : "C22H29O11",
        "SUID" : 9795,
        "selected" : false
      },
      "position" : {
        "x" : -808.459220812068,
        "y" : 641.0839231398797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9791",
        "shared_name" : "C19H15O8",
        "name" : "C19H15O8",
        "SUID" : 9791,
        "selected" : false
      },
      "position" : {
        "x" : -808.459220812068,
        "y" : -1486.960449418714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9790",
        "shared_name" : "C19H17O9",
        "name" : "C19H17O9",
        "SUID" : 9790,
        "selected" : false
      },
      "position" : {
        "x" : -693.6731719229078,
        "y" : -1505.2801210495734
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9788",
        "shared_name" : "C19H15O9",
        "name" : "C19H15O9",
        "SUID" : 9788,
        "selected" : false
      },
      "position" : {
        "x" : -404.48469536040784,
        "y" : 252.83895091087584
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9786",
        "shared_name" : "C18H19O11",
        "name" : "C18H19O11",
        "SUID" : 9786,
        "selected" : false
      },
      "position" : {
        "x" : 92.0506554391527,
        "y" : 489.662483015368
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9783",
        "shared_name" : "C18H25O7",
        "name" : "C18H25O7",
        "SUID" : 9783,
        "selected" : false
      },
      "position" : {
        "x" : -174.0914229605055,
        "y" : -1700.3479768845343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9781",
        "shared_name" : "C15H21O7",
        "name" : "C15H21O7",
        "SUID" : 9781,
        "selected" : false
      },
      "position" : {
        "x" : 693.1000138070726,
        "y" : -666.8330003830695
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9779",
        "shared_name" : "C16H21O9",
        "name" : "C16H21O9",
        "SUID" : 9779,
        "selected" : false
      },
      "position" : {
        "x" : 803.7081986215258,
        "y" : -688.6940080734992
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9777",
        "shared_name" : "C21H25O9",
        "name" : "C21H25O9",
        "SUID" : 9777,
        "selected" : false
      },
      "position" : {
        "x" : 586.1595627811098,
        "y" : 390.3874323752618
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9767",
        "shared_name" : "C16H21O10",
        "name" : "C16H21O10",
        "SUID" : 9767,
        "selected" : false
      },
      "position" : {
        "x" : -336.184448168025,
        "y" : -762.7823869797492
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9760",
        "shared_name" : "C18H23O8",
        "name" : "C18H23O8",
        "SUID" : 9760,
        "selected" : false
      },
      "position" : {
        "x" : 682.0130234506273,
        "y" : -1239.3989336106085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9757",
        "shared_name" : "C14H17O6",
        "name" : "C14H17O6",
        "SUID" : 9757,
        "selected" : false
      },
      "position" : {
        "x" : 341.8938866403246,
        "y" : 239.96625498802428
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9754",
        "shared_name" : "C21H17O12",
        "name" : "C21H17O12",
        "SUID" : 9754,
        "selected" : false
      },
      "position" : {
        "x" : -808.459220812068,
        "y" : 1142.2330625441766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9752",
        "shared_name" : "C21H19O9",
        "name" : "C21H19O9",
        "SUID" : 9752,
        "selected" : false
      },
      "position" : {
        "x" : -503.0587310049391,
        "y" : -512.7016069504523
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9751",
        "shared_name" : "C22H19O11",
        "name" : "C22H19O11",
        "SUID" : 9751,
        "selected" : false
      },
      "position" : {
        "x" : -602.3558730337477,
        "y" : -548.4740478607916
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9748",
        "shared_name" : "C20H15O10",
        "name" : "C20H15O10",
        "SUID" : 9748,
        "selected" : false
      },
      "position" : {
        "x" : 374.6211243417406,
        "y" : 1142.2330625441766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9747",
        "shared_name" : "C21H15O12",
        "name" : "C21H15O12",
        "SUID" : 9747,
        "selected" : false
      },
      "position" : {
        "x" : 371.60367210175036,
        "y" : 1249.9552305129266
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9745",
        "shared_name" : "C19H25O8",
        "name" : "C19H25O8",
        "SUID" : 9745,
        "selected" : false
      },
      "position" : {
        "x" : -808.459220812068,
        "y" : -903.3267137619757
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9743",
        "shared_name" : "C20H21O8",
        "name" : "C20H21O8",
        "SUID" : 9743,
        "selected" : false
      },
      "position" : {
        "x" : -761.9368514273024,
        "y" : -631.847152909925
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9741",
        "shared_name" : "C18H21O8",
        "name" : "C18H21O8",
        "SUID" : 9741,
        "selected" : false
      },
      "position" : {
        "x" : 923.1078224923754,
        "y" : -228.87720509498354
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9738",
        "shared_name" : "C17H19O9",
        "name" : "C17H19O9",
        "SUID" : 9738,
        "selected" : false
      },
      "position" : {
        "x" : -0.05471031402112203,
        "y" : 435.5447767165399
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9737",
        "shared_name" : "C17H21O10",
        "name" : "C17H21O10",
        "SUID" : 9737,
        "selected" : false
      },
      "position" : {
        "x" : -81.4991378042555,
        "y" : 513.1396100905633
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9735",
        "shared_name" : "C22H15O12",
        "name" : "C22H15O12",
        "SUID" : 9735,
        "selected" : false
      },
      "position" : {
        "x" : 540.4278031137133,
        "y" : 741.0839231398797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9732",
        "shared_name" : "C21H23O10",
        "name" : "C21H23O10",
        "SUID" : 9732,
        "selected" : false
      },
      "position" : {
        "x" : 456.1024781015062,
        "y" : -286.1554643723273
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9730",
        "shared_name" : "C22H29O8",
        "name" : "C22H29O8",
        "SUID" : 9730,
        "selected" : false
      },
      "position" : {
        "x" : 271.60367210175036,
        "y" : 1142.2330625441766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9729",
        "shared_name" : "C23H29O10",
        "name" : "C23H29O10",
        "SUID" : 9729,
        "selected" : false
      },
      "position" : {
        "x" : 268.5862198617601,
        "y" : 1249.9552305129266
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9727",
        "shared_name" : "C18H23O6",
        "name" : "C18H23O6",
        "SUID" : 9727,
        "selected" : false
      },
      "position" : {
        "x" : 65.98075111176013,
        "y" : -1711.7111208054328
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9726",
        "shared_name" : "C19H23O8",
        "name" : "C19H23O8",
        "SUID" : 9726,
        "selected" : false
      },
      "position" : {
        "x" : 33.78571326996325,
        "y" : -1598.9698335739874
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9722",
        "shared_name" : "C20H17O8",
        "name" : "C20H17O8",
        "SUID" : 9722,
        "selected" : false
      },
      "position" : {
        "x" : -79.54479973052503,
        "y" : 741.0839231398797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9720",
        "shared_name" : "C21H29O8",
        "name" : "C21H29O8",
        "SUID" : 9720,
        "selected" : false
      },
      "position" : {
        "x" : 319.8612442758226,
        "y" : 741.0839231398797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9719",
        "shared_name" : "C22H29O10",
        "name" : "C22H29O10",
        "SUID" : 9719,
        "selected" : false
      },
      "position" : {
        "x" : 385.916023328557,
        "y" : 827.307502546618
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9717",
        "shared_name" : "C16H19O8",
        "name" : "C16H19O8",
        "SUID" : 9717,
        "selected" : false
      },
      "position" : {
        "x" : 1112.1062851693773,
        "y" : -859.7546922776007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9715",
        "shared_name" : "C22H23O8",
        "name" : "C22H23O8",
        "SUID" : 9715,
        "selected" : false
      },
      "position" : {
        "x" : -783.4708480093336,
        "y" : 101.47180918724303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9714",
        "shared_name" : "C23H23O10",
        "name" : "C23H23O10",
        "SUID" : 9714,
        "selected" : false
      },
      "position" : {
        "x" : -779.4786833975172,
        "y" : 211.81366709739928
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9712",
        "shared_name" : "C17H19O6",
        "name" : "C17H19O6",
        "SUID" : 9712,
        "selected" : false
      },
      "position" : {
        "x" : -571.073029443965,
        "y" : -1206.7815782639288
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9709",
        "shared_name" : "C17H19O11",
        "name" : "C17H19O11",
        "SUID" : 9709,
        "selected" : false
      },
      "position" : {
        "x" : -165.83023445342542,
        "y" : -906.502083024671
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9706",
        "shared_name" : "C20H27O8",
        "name" : "C20H27O8",
        "SUID" : 9706,
        "selected" : false
      },
      "position" : {
        "x" : 636.8025627877855,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9705",
        "shared_name" : "C21H27O10",
        "name" : "C21H27O10",
        "SUID" : 9705,
        "selected" : false
      },
      "position" : {
        "x" : 633.7851105477953,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9703",
        "shared_name" : "C15H21O6",
        "name" : "C15H21O6",
        "SUID" : 9703,
        "selected" : false
      },
      "position" : {
        "x" : 33.59966285492419,
        "y" : 101.47180918724303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9702",
        "shared_name" : "C16H21O8",
        "name" : "C16H21O8",
        "SUID" : 9702,
        "selected" : false
      },
      "position" : {
        "x" : 0.652046277775753,
        "y" : 207.29193858177428
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9699",
        "shared_name" : "C18H19O8",
        "name" : "C18H19O8",
        "SUID" : 9699,
        "selected" : false
      },
      "position" : {
        "x" : -547.915971681819,
        "y" : -1313.089828691175
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9693",
        "shared_name" : "C16H23O7",
        "name" : "C16H23O7",
        "SUID" : 9693,
        "selected" : false
      },
      "position" : {
        "x" : -808.459220812068,
        "y" : -412.7016069504523
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9692",
        "shared_name" : "C17H23O9",
        "name" : "C17H23O9",
        "SUID" : 9692,
        "selected" : false
      },
      "position" : {
        "x" : -735.3138045523024,
        "y" : -324.5740739914679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9690",
        "shared_name" : "C18H25O9",
        "name" : "C18H25O9",
        "SUID" : 9690,
        "selected" : false
      },
      "position" : {
        "x" : 579.5338974740648,
        "y" : -1288.3493120285773
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9689",
        "shared_name" : "C19H25O11",
        "name" : "C19H25O11",
        "SUID" : 9689,
        "selected" : false
      },
      "position" : {
        "x" : 661.7830429818773,
        "y" : -1354.124865135839
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9687",
        "shared_name" : "C21H27O12",
        "name" : "C21H27O12",
        "SUID" : 9687,
        "selected" : false
      },
      "position" : {
        "x" : 249.03319175507067,
        "y" : -313.23111744849916
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9685",
        "shared_name" : "C17H17O7",
        "name" : "C17H17O7",
        "SUID" : 9685,
        "selected" : false
      },
      "position" : {
        "x" : -57.39324562285901,
        "y" : -412.7016069504523
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9683",
        "shared_name" : "C13H17O6",
        "name" : "C13H17O6",
        "SUID" : 9683,
        "selected" : false
      },
      "position" : {
        "x" : -532.5290297720289,
        "y" : 741.0839231398797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9682",
        "shared_name" : "C14H17O8",
        "name" : "C14H17O8",
        "SUID" : 9682,
        "selected" : false
      },
      "position" : {
        "x" : -439.12993614409925,
        "y" : 798.961181440661
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9680",
        "shared_name" : "C19H23O6",
        "name" : "C19H23O6",
        "SUID" : 9680,
        "selected" : false
      },
      "position" : {
        "x" : 624.8647499826097,
        "y" : -412.7016069504523
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9679",
        "shared_name" : "C20H23O8",
        "name" : "C20H23O8",
        "SUID" : 9679,
        "selected" : false
      },
      "position" : {
        "x" : 529.320449903264,
        "y" : -365.01136036842104
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9676",
        "shared_name" : "C19H27O9",
        "name" : "C19H27O9",
        "SUID" : 9676,
        "selected" : false
      },
      "position" : {
        "x" : 533.7851105477953,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9675",
        "shared_name" : "C20H27O11",
        "name" : "C20H27O11",
        "SUID" : 9675,
        "selected" : false
      },
      "position" : {
        "x" : 530.767658307805,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9672",
        "shared_name" : "C20H13O11",
        "name" : "C20H13O11",
        "SUID" : 9672,
        "selected" : false
      },
      "position" : {
        "x" : 430.76765830780505,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9671",
        "shared_name" : "C21H13O13",
        "name" : "C21H13O13",
        "SUID" : 9671,
        "selected" : false
      },
      "position" : {
        "x" : 427.7502060678148,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9662",
        "shared_name" : "C19H19O10",
        "name" : "C19H19O10",
        "SUID" : 9662,
        "selected" : false
      },
      "position" : {
        "x" : -598.1810359213209,
        "y" : -1413.7345888230109
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9661",
        "shared_name" : "C20H19O12",
        "name" : "C20H19O12",
        "SUID" : 9661,
        "selected" : false
      },
      "position" : {
        "x" : -688.3755339834547,
        "y" : -1352.9054720017218
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9659",
        "shared_name" : "C17H17O10",
        "name" : "C17H17O10",
        "SUID" : 9659,
        "selected" : false
      },
      "position" : {
        "x" : -65.20563499663831,
        "y" : -878.7939226242804
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9657",
        "shared_name" : "C18H17O9",
        "name" : "C18H17O9",
        "SUID" : 9657,
        "selected" : false
      },
      "position" : {
        "x" : -131.50436775420667,
        "y" : -325.5112840744757
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9655",
        "shared_name" : "C21H23O9",
        "name" : "C21H23O9",
        "SUID" : 9655,
        "selected" : false
      },
      "position" : {
        "x" : -197.03102867339612,
        "y" : 1181.5306699660516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9654",
        "shared_name" : "C22H23O11",
        "name" : "C22H23O11",
        "SUID" : 9654,
        "selected" : false
      },
      "position" : {
        "x" : -95.89199058745862,
        "y" : 1210.0300596144891
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9650",
        "shared_name" : "C17H23O8",
        "name" : "C17H23O8",
        "SUID" : 9650,
        "selected" : false
      },
      "position" : {
        "x" : -293.8572615835524,
        "y" : -1152.770941934278
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9649",
        "shared_name" : "C18H23O10",
        "name" : "C18H23O10",
        "SUID" : 9649,
        "selected" : false
      },
      "position" : {
        "x" : -344.3384932730055,
        "y" : -1249.4066469284796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9647",
        "shared_name" : "C21H21O12",
        "name" : "C21H21O12",
        "SUID" : 9647,
        "selected" : false
      },
      "position" : {
        "x" : 80.44371803070544,
        "y" : -720.7912294480109
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9642",
        "shared_name" : "C20H25O12",
        "name" : "C20H25O12",
        "SUID" : 9642,
        "selected" : false
      },
      "position" : {
        "x" : 593.1000138070726,
        "y" : -590.9837648484015
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9637",
        "shared_name" : "C20H25O9",
        "name" : "C20H25O9",
        "SUID" : 9637,
        "selected" : false
      },
      "position" : {
        "x" : 422.7591973092699,
        "y" : -400.7861101242804
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9636",
        "shared_name" : "C21H25O11",
        "name" : "C21H25O11",
        "SUID" : 9636,
        "selected" : false
      },
      "position" : {
        "x" : 355.5010872628832,
        "y" : -317.1189653488898
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9631",
        "shared_name" : "C19H25O9",
        "name" : "C19H25O9",
        "SUID" : 9631,
        "selected" : false
      },
      "position" : {
        "x" : -83.52544395659925,
        "y" : -1627.1248781296515
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9629",
        "shared_name" : "C19H23O9",
        "name" : "C19H23O9",
        "SUID" : 9629,
        "selected" : false
      },
      "position" : {
        "x" : 423.8087998178148,
        "y" : -714.2402078720831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9628",
        "shared_name" : "C19H25O10",
        "name" : "C19H25O10",
        "SUID" : 9628,
        "selected" : false
      },
      "position" : {
        "x" : 522.2086106088304,
        "y" : -670.104435167005
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9626",
        "shared_name" : "C21H21O10",
        "name" : "C21H21O10",
        "SUID" : 9626,
        "selected" : false
      },
      "position" : {
        "x" : -777.840568468318,
        "y" : -725.5366746994757
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9623",
        "shared_name" : "C20H15O11",
        "name" : "C20H15O11",
        "SUID" : 9623,
        "selected" : false
      },
      "position" : {
        "x" : -455.8213347647047,
        "y" : 160.96149424583678
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9622",
        "shared_name" : "C21H15O13",
        "name" : "C21H15O13",
        "SUID" : 9622,
        "selected" : false
      },
      "position" : {
        "x" : -542.2557677481032,
        "y" : 101.47180918724303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9620",
        "shared_name" : "C19H15O11",
        "name" : "C19H15O11",
        "SUID" : 9620,
        "selected" : false
      },
      "position" : {
        "x" : 327.7502060678148,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9619",
        "shared_name" : "C19H17O12",
        "name" : "C19H17O12",
        "SUID" : 9619,
        "selected" : false
      },
      "position" : {
        "x" : 324.7327538278246,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9617",
        "shared_name" : "C18H21O11",
        "name" : "C18H21O11",
        "SUID" : 9617,
        "selected" : false
      },
      "position" : {
        "x" : -235.22777931426526,
        "y" : -150.9862817141318
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9614",
        "shared_name" : "C19H21O12",
        "name" : "C19H21O12",
        "SUID" : 9614,
        "selected" : false
      },
      "position" : {
        "x" : -497.8231314871168,
        "y" : -270.535515031507
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9611",
        "shared_name" : "C19H21O10",
        "name" : "C19H21O10",
        "SUID" : 9611,
        "selected" : false
      },
      "position" : {
        "x" : 832.7653237130785,
        "y" : -150.3228990647101
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9610",
        "shared_name" : "C20H21O12",
        "name" : "C20H21O12",
        "SUID" : 9610,
        "selected" : false
      },
      "position" : {
        "x" : 759.469059064641,
        "y" : -65.664550981214
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9607",
        "shared_name" : "C17H21O8",
        "name" : "C17H21O8",
        "SUID" : 9607,
        "selected" : false
      },
      "position" : {
        "x" : -699.7244185659742,
        "y" : -219.01163502662416
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9605",
        "shared_name" : "C22H23O10",
        "name" : "C22H23O10",
        "SUID" : 9605,
        "selected" : false
      },
      "position" : {
        "x" : 477.43113334442614,
        "y" : 211.67220286400084
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9604",
        "shared_name" : "C22H25O11",
        "name" : "C22H25O11",
        "SUID" : 9604,
        "selected" : false
      },
      "position" : {
        "x" : 514.0383721139574,
        "y" : 311.8905561354852
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9601",
        "shared_name" : "C21H23O11",
        "name" : "C21H23O11",
        "SUID" : 9601,
        "selected" : false
      },
      "position" : {
        "x" : -760.4053878042555,
        "y" : -831.6730272385382
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9600",
        "shared_name" : "C21H25O12",
        "name" : "C21H25O12",
        "SUID" : 9600,
        "selected" : false
      },
      "position" : {
        "x" : -740.2457808706617,
        "y" : -941.9804613205695
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9598",
        "shared_name" : "C20H23O9",
        "name" : "C20H23O9",
        "SUID" : 9598,
        "selected" : false
      },
      "position" : {
        "x" : -694.2016982290602,
        "y" : -750.1929094406867
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9597",
        "shared_name" : "C20H25O10",
        "name" : "C20H25O10",
        "SUID" : 9597,
        "selected" : false
      },
      "position" : {
        "x" : -687.4171675894117,
        "y" : -858.9059068772101
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9594",
        "shared_name" : "C15H19O8",
        "name" : "C15H19O8",
        "SUID" : 9594,
        "selected" : false
      },
      "position" : {
        "x" : -704.5622023794508,
        "y" : 827.2410581496454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9593",
        "shared_name" : "C16H19O10",
        "name" : "C16H19O10",
        "SUID" : 9593,
        "selected" : false
      },
      "position" : {
        "x" : -682.3304213735914,
        "y" : 932.741454878161
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9591",
        "shared_name" : "C17H21O9",
        "name" : "C17H21O9",
        "SUID" : 9591,
        "selected" : false
      },
      "position" : {
        "x" : -321.8148879263258,
        "y" : -85.10010548560854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9589",
        "shared_name" : "C20H25O11",
        "name" : "C20H25O11",
        "SUID" : 9589,
        "selected" : false
      },
      "position" : {
        "x" : -61.2886885855055,
        "y" : -1524.3721315476203
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9587",
        "shared_name" : "C16H19O9",
        "name" : "C16H19O9",
        "SUID" : 9587,
        "selected" : false
      },
      "position" : {
        "x" : -238.98679344390393,
        "y" : -828.2441560837531
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9585",
        "shared_name" : "C19H23O11",
        "name" : "C19H23O11",
        "SUID" : 9585,
        "selected" : false
      },
      "position" : {
        "x" : 1118.765720441594,
        "y" : -272.48140736549135
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9582",
        "shared_name" : "C19H27O8",
        "name" : "C19H27O8",
        "SUID" : 9582,
        "selected" : false
      },
      "position" : {
        "x" : 42.60675437714099,
        "y" : -399.3140337082648
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9581",
        "shared_name" : "C20H27O10",
        "name" : "C20H27O10",
        "SUID" : 9581,
        "selected" : false
      },
      "position" : {
        "x" : 138.24902732635974,
        "y" : -342.5782243820929
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9578",
        "shared_name" : "C18H19O6",
        "name" : "C18H19O6",
        "SUID" : 9578,
        "selected" : false
      },
      "position" : {
        "x" : 974.3589249398851,
        "y" : -1549.6256715866828
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9576",
        "shared_name" : "C17H19O10",
        "name" : "C17H19O10",
        "SUID" : 9576,
        "selected" : false
      },
      "position" : {
        "x" : 1010.1661453988695,
        "y" : -797.418815812757
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9575",
        "shared_name" : "C17H21O11",
        "name" : "C17H21O11",
        "SUID" : 9575,
        "selected" : false
      },
      "position" : {
        "x" : 910.990974500432,
        "y" : -744.6444780442023
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9572",
        "shared_name" : "C21H19O10",
        "name" : "C21H19O10",
        "SUID" : 9572,
        "selected" : false
      },
      "position" : {
        "x" : 372.74669654633044,
        "y" : -1419.0309221359992
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9571",
        "shared_name" : "C22H19O12",
        "name" : "C22H19O12",
        "SUID" : 9571,
        "selected" : false
      },
      "position" : {
        "x" : 479.5338974740648,
        "y" : -1412.999023637464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9569",
        "shared_name" : "C21H17O10",
        "name" : "C21H17O10",
        "SUID" : 9569,
        "selected" : false
      },
      "position" : {
        "x" : 27.396064832463253,
        "y" : 766.5180051711297
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9568",
        "shared_name" : "C22H17O12",
        "name" : "C22H17O12",
        "SUID" : 9568,
        "selected" : false
      },
      "position" : {
        "x" : 125.65946204926013,
        "y" : 806.5555570510126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9566",
        "shared_name" : "C18H19O9",
        "name" : "C18H19O9",
        "SUID" : 9566,
        "selected" : false
      },
      "position" : {
        "x" : -567.4868258688307,
        "y" : -141.8677446457648
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9564",
        "shared_name" : "C18H19O10",
        "name" : "C18H19O10",
        "SUID" : 9564,
        "selected" : false
      },
      "position" : {
        "x" : -217.6627883169508,
        "y" : -254.79888936012026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9561",
        "shared_name" : "C17H23O7",
        "name" : "C17H23O7",
        "SUID" : 9561,
        "selected" : false
      },
      "position" : {
        "x" : 1033.4574013497972,
        "y" : -412.7016069504523
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9560",
        "shared_name" : "C18H23O9",
        "name" : "C18H23O9",
        "SUID" : 9560,
        "selected" : false
      },
      "position" : {
        "x" : 1018.0279579904222,
        "y" : -300.2904741379523
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9556",
        "shared_name" : "C20H15O8",
        "name" : "C20H15O8",
        "SUID" : 9556,
        "selected" : false
      },
      "position" : {
        "x" : 729.1635208871508,
        "y" : 837.8426816848016
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9555",
        "shared_name" : "C21H15O10",
        "name" : "C21H15O10",
        "SUID" : 9555,
        "selected" : false
      },
      "position" : {
        "x" : 636.8229141976976,
        "y" : 782.0582273390985
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9553",
        "shared_name" : "C20H21O10",
        "name" : "C20H21O10",
        "SUID" : 9553,
        "selected" : false
      },
      "position" : {
        "x" : 184.2295456674242,
        "y" : -736.4888078781867
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9552",
        "shared_name" : "C20H23O11",
        "name" : "C20H23O11",
        "SUID" : 9552,
        "selected" : false
      },
      "position" : {
        "x" : 306.67247779633044,
        "y" : -730.5751268479132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9550",
        "shared_name" : "C19H17O8",
        "name" : "C19H17O8",
        "SUID" : 9550,
        "selected" : false
      },
      "position" : {
        "x" : -619.7235030386305,
        "y" : 1238.9918210890985
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9549",
        "shared_name" : "C20H17O10",
        "name" : "C20H17O10",
        "SUID" : 9549,
        "selected" : false
      },
      "position" : {
        "x" : -712.0641097280836,
        "y" : 1183.2073667433954
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9547",
        "shared_name" : "C19H19O9",
        "name" : "C19H19O9",
        "SUID" : 9547,
        "selected" : false
      },
      "position" : {
        "x" : 817.4539833810472,
        "y" : -53.10832425086733
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9546",
        "shared_name" : "C20H19O11",
        "name" : "C20H19O11",
        "SUID" : 9546,
        "selected" : false
      },
      "position" : {
        "x" : 724.8647499826097,
        "y" : -151.84044667213197
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9544",
        "shared_name" : "C22H25O8",
        "name" : "C22H25O8",
        "SUID" : 9544,
        "selected" : false
      },
      "position" : {
        "x" : 224.73275382782458,
        "y" : 1421.4270246413446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9543",
        "shared_name" : "C23H25O10",
        "name" : "C23H25O10",
        "SUID" : 9543,
        "selected" : false
      },
      "position" : {
        "x" : 221.71530158783435,
        "y" : 1529.1491926100946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9541",
        "shared_name" : "C18H21O7",
        "name" : "C18H21O7",
        "SUID" : 9541,
        "selected" : false
      },
      "position" : {
        "x" : 868.0574646737718,
        "y" : -1502.5037386032843
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9539",
        "shared_name" : "C19H19O8",
        "name" : "C19H19O8",
        "SUID" : 9539,
        "selected" : false
      },
      "position" : {
        "x" : 920.8257942941332,
        "y" : -1469.8782350632453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9538",
        "shared_name" : "C19H21O9",
        "name" : "C19H21O9",
        "SUID" : 9538,
        "selected" : false
      },
      "position" : {
        "x" : 843.5419007089281,
        "y" : -1392.747989854505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9536",
        "shared_name" : "C19H23O10",
        "name" : "C19H23O10",
        "SUID" : 9536,
        "selected" : false
      },
      "position" : {
        "x" : 764.4320297982836,
        "y" : -1317.7679826828742
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9534",
        "shared_name" : "C20H23O10",
        "name" : "C20H23O10",
        "SUID" : 9534,
        "selected" : false
      },
      "position" : {
        "x" : 39.44522865082263,
        "y" : -1491.4643652054572
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9531",
        "shared_name" : "C20H19O9",
        "name" : "C20H19O9",
        "SUID" : 9531,
        "selected" : false
      },
      "position" : {
        "x" : 138.24327857758044,
        "y" : -834.4258195969367
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9530",
        "shared_name" : "C21H19O11",
        "name" : "C21H19O11",
        "SUID" : 9530,
        "selected" : false
      },
      "position" : {
        "x" : 34.79436500336169,
        "y" : -814.2335741135382
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9528",
        "shared_name" : "C15H21O8",
        "name" : "C15H21O8",
        "SUID" : 9528,
        "selected" : false
      },
      "position" : {
        "x" : -328.16824333404065,
        "y" : -853.1771776291632
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9526",
        "shared_name" : "C20H21O9",
        "name" : "C20H21O9",
        "SUID" : 9526,
        "selected" : false
      },
      "position" : {
        "x" : 141.85330970551013,
        "y" : -1456.4099924179816
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9524",
        "shared_name" : "C18H21O10",
        "name" : "C18H21O10",
        "SUID" : 9524,
        "selected" : false
      },
      "position" : {
        "x" : -598.1875762197828,
        "y" : -242.9294893357062
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9523",
        "shared_name" : "C18H23O11",
        "name" : "C18H23O11",
        "SUID" : 9523,
        "selected" : false
      },
      "position" : {
        "x" : -630.1512984487867,
        "y" : -339.71744557349916
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9521",
        "shared_name" : "C21H21O11",
        "name" : "C21H21O11",
        "SUID" : 9521,
        "selected" : false
      },
      "position" : {
        "x" : 114.22126014496325,
        "y" : -1355.8551790329718
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9520",
        "shared_name" : "C21H23O12",
        "name" : "C21H23O12",
        "SUID" : 9520,
        "selected" : false
      },
      "position" : {
        "x" : 17.327797010197628,
        "y" : -1389.7576143357062
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9518",
        "shared_name" : "C14H19O7",
        "name" : "C14H19O7",
        "SUID" : 9518,
        "selected" : false
      },
      "position" : {
        "x" : 310.46718986298083,
        "y" : 120.00733164818053
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9517",
        "shared_name" : "C15H19O9",
        "name" : "C15H19O9",
        "SUID" : 9517,
        "selected" : false
      },
      "position" : {
        "x" : 207.8095665719652,
        "y" : 101.47180918724303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9515",
        "shared_name" : "C15H17O8",
        "name" : "C15H17O8",
        "SUID" : 9515,
        "selected" : false
      },
      "position" : {
        "x" : 251.95138175751208,
        "y" : 198.46857432396178
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9514",
        "shared_name" : "C16H17O10",
        "name" : "C16H17O10",
        "SUID" : 9514,
        "selected" : false
      },
      "position" : {
        "x" : 192.0506554391527,
        "y" : 295.8591993239618
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9512",
        "shared_name" : "C20H21O11",
        "name" : "C20H21O11",
        "SUID" : 9512,
        "selected" : false
      },
      "position" : {
        "x" : 915.775569989934,
        "y" : -1313.9307405564093
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9511",
        "shared_name" : "C20H23O12",
        "name" : "C20H23O12",
        "SUID" : 9511,
        "selected" : false
      },
      "position" : {
        "x" : 839.7291489389086,
        "y" : -1246.5613710495734
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9509",
        "shared_name" : "C19H23O12",
        "name" : "C19H23O12",
        "SUID" : 9509,
        "selected" : false
      },
      "position" : {
        "x" : -432.03842918609143,
        "y" : -1511.6457826706671
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9507",
        "shared_name" : "C16H19O6",
        "name" : "C16H19O6",
        "SUID" : 9507,
        "selected" : false
      },
      "position" : {
        "x" : -244.1679438803053,
        "y" : -81.42422505347963
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9506",
        "shared_name" : "C17H19O8",
        "name" : "C17H19O8",
        "SUID" : 9506,
        "selected" : false
      },
      "position" : {
        "x" : -291.91596977447034,
        "y" : -180.1032774063849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9504",
        "shared_name" : "C18H21O9",
        "name" : "C18H21O9",
        "SUID" : 9504,
        "selected" : false
      },
      "position" : {
        "x" : -433.042716905818,
        "y" : -1334.048599443128
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9503",
        "shared_name" : "C19H21O11",
        "name" : "C19H21O11",
        "SUID" : 9503,
        "selected" : false
      },
      "position" : {
        "x" : -489.32915489409925,
        "y" : -1426.2878725144171
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9501",
        "shared_name" : "C14H19O5",
        "name" : "C14H19O5",
        "SUID" : 9501,
        "selected" : false
      },
      "position" : {
        "x" : -315.7722319815016,
        "y" : -634.7699281784796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9500",
        "shared_name" : "C15H19O7",
        "name" : "C15H19O7",
        "SUID" : 9500,
        "selected" : false
      },
      "position" : {
        "x" : -284.458373949275,
        "y" : -741.3817960831427
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9498",
        "shared_name" : "C19H17O10",
        "name" : "C19H17O10",
        "SUID" : 9498,
        "selected" : false
      },
      "position" : {
        "x" : -293.89418403838636,
        "y" : 216.9214857009149
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9497",
        "shared_name" : "C20H17O12",
        "name" : "C20H17O12",
        "SUID" : 9497,
        "selected" : false
      },
      "position" : {
        "x" : -353.6440047476149,
        "y" : 131.68949107200865
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9495",
        "shared_name" : "C15H17O6",
        "name" : "C15H17O6",
        "SUID" : 9495,
        "selected" : false
      },
      "position" : {
        "x" : -175.19715492461683,
        "y" : -697.8933488938117
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9494",
        "shared_name" : "C16H17O8",
        "name" : "C16H17O8",
        "SUID" : 9494,
        "selected" : false
      },
      "position" : {
        "x" : -128.29729931090833,
        "y" : -792.9575960251593
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "10055",
        "source" : "10054",
        "target" : "9594",
        "shared_name" : "C15H21O9 (interacts with) C15H19O8",
        "family_id" : 32,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O9 (interacts with) C15H19O8",
        "interaction" : "interacts with",
        "SUID" : 10055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10047",
        "source" : "10045",
        "target" : "10046",
        "shared_name" : "C17H13O12 (interacts with) C16H13O10",
        "family_id" : 103,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H13O12 (interacts with) C16H13O10",
        "interaction" : "interacts with",
        "SUID" : 10047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10043",
        "source" : "10041",
        "target" : "10042",
        "shared_name" : "C24H27O10 (interacts with) C23H27O8",
        "family_id" : 157,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C24H27O10 (interacts with) C23H27O8",
        "interaction" : "interacts with",
        "SUID" : 10043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10032",
        "source" : "10031",
        "target" : "10012",
        "shared_name" : "C21H27O11 (interacts with) C21H25O10",
        "family_id" : 106,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H27O11 (interacts with) C21H25O10",
        "interaction" : "interacts with",
        "SUID" : 10032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10029",
        "source" : "10027",
        "target" : "10028",
        "shared_name" : "C13H13O9 (interacts with) C12H13O7",
        "family_id" : 163,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C13H13O9 (interacts with) C12H13O7",
        "interaction" : "interacts with",
        "SUID" : 10029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10075",
        "source" : "10016",
        "target" : "10074",
        "shared_name" : "C15H15O9 (interacts with) C15H13O8",
        "family_id" : 139,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H15O9 (interacts with) C15H13O8",
        "interaction" : "interacts with",
        "SUID" : 10075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10017",
        "source" : "10016",
        "target" : "9970",
        "shared_name" : "C15H15O9 (interacts with) C14H15O7",
        "family_id" : 46,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H15O9 (interacts with) C14H15O7",
        "interaction" : "interacts with",
        "SUID" : 10017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10076",
        "source" : "10012",
        "target" : "10013",
        "shared_name" : "C21H25O10 (interacts with) C20H25O8",
        "family_id" : 119,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H25O10 (interacts with) C20H25O8",
        "interaction" : "interacts with",
        "SUID" : 10076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10014",
        "source" : "10012",
        "target" : "10013",
        "shared_name" : "C21H25O10 (interacts with) C20H25O8",
        "family_id" : 106,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H25O10 (interacts with) C20H25O8",
        "interaction" : "interacts with",
        "SUID" : 10014,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10063",
        "source" : "9986",
        "target" : "10062",
        "shared_name" : "C18H17O11 (interacts with) C18H15O10",
        "family_id" : 8,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H17O11 (interacts with) C18H15O10",
        "interaction" : "interacts with",
        "SUID" : 10063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9988",
        "source" : "9986",
        "target" : "9987",
        "shared_name" : "C18H17O11 (interacts with) C17H17O9",
        "family_id" : 95,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O11 (interacts with) C17H17O9",
        "interaction" : "interacts with",
        "SUID" : 9988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9984",
        "source" : "9982",
        "target" : "9983",
        "shared_name" : "C17H23O10 (interacts with) C16H23O8",
        "family_id" : 7,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H23O10 (interacts with) C16H23O8",
        "interaction" : "interacts with",
        "SUID" : 9984,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9967",
        "source" : "9965",
        "target" : "9966",
        "shared_name" : "C22H21O11 (interacts with) C21H21O9",
        "family_id" : 79,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H21O11 (interacts with) C21H21O9",
        "interaction" : "interacts with",
        "SUID" : 9967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9946",
        "source" : "9944",
        "target" : "9945",
        "shared_name" : "C19H17O11 (interacts with) C19H15O10",
        "family_id" : 124,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H17O11 (interacts with) C19H15O10",
        "interaction" : "interacts with",
        "SUID" : 9946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9929",
        "source" : "9927",
        "target" : "9928",
        "shared_name" : "C14H15O9 (interacts with) C13H15O7",
        "family_id" : 165,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H15O9 (interacts with) C13H15O7",
        "interaction" : "interacts with",
        "SUID" : 9929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9974",
        "source" : "9908",
        "target" : "9857",
        "shared_name" : "C21H17O13 (interacts with) C20H17O11",
        "family_id" : 180,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H17O13 (interacts with) C20H17O11",
        "interaction" : "interacts with",
        "SUID" : 9974,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9909",
        "source" : "9908",
        "target" : "9857",
        "shared_name" : "C21H17O13 (interacts with) C20H17O11",
        "family_id" : 129,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H17O13 (interacts with) C20H17O11",
        "interaction" : "interacts with",
        "SUID" : 9909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10011",
        "source" : "9902",
        "target" : "9714",
        "shared_name" : "C23H25O11 (interacts with) C23H23O10",
        "family_id" : 122,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C23H25O11 (interacts with) C23H23O10",
        "interaction" : "interacts with",
        "SUID" : 10011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9904",
        "source" : "9902",
        "target" : "9903",
        "shared_name" : "C23H25O11 (interacts with) C22H25O9",
        "family_id" : 24,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C23H25O11 (interacts with) C22H25O9",
        "interaction" : "interacts with",
        "SUID" : 9904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9892",
        "source" : "9890",
        "target" : "9891",
        "shared_name" : "C23H27O10 (interacts with) C22H27O8",
        "family_id" : 34,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C23H27O10 (interacts with) C22H27O8",
        "interaction" : "interacts with",
        "SUID" : 9892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9914",
        "source" : "9886",
        "target" : "9913",
        "shared_name" : "C15H17O9 (interacts with) C14H17O7",
        "family_id" : 22,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O9 (interacts with) C14H17O7",
        "interaction" : "interacts with",
        "SUID" : 9914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9888",
        "source" : "9886",
        "target" : "9887",
        "shared_name" : "C15H17O9 (interacts with) C15H15O8",
        "family_id" : 153,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O9 (interacts with) C15H15O8",
        "interaction" : "interacts with",
        "SUID" : 9888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9870",
        "source" : "9868",
        "target" : "9869",
        "shared_name" : "C14H13O9 (interacts with) C14H11O8",
        "family_id" : 179,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H13O9 (interacts with) C14H11O8",
        "interaction" : "interacts with",
        "SUID" : 9870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9962",
        "source" : "9857",
        "target" : "9790",
        "shared_name" : "C20H17O11 (interacts with) C19H17O9",
        "family_id" : 180,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H17O11 (interacts with) C19H17O9",
        "interaction" : "interacts with",
        "SUID" : 9962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9858",
        "source" : "9857",
        "target" : "9790",
        "shared_name" : "C20H17O11 (interacts with) C19H17O9",
        "family_id" : 129,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H17O11 (interacts with) C19H17O9",
        "interaction" : "interacts with",
        "SUID" : 9858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10060",
        "source" : "9850",
        "target" : "9751",
        "shared_name" : "C22H21O12 (interacts with) C22H19O11",
        "family_id" : 1,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C22H21O12 (interacts with) C22H19O11",
        "interaction" : "interacts with",
        "SUID" : 10060,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9851",
        "source" : "9850",
        "target" : "9626",
        "shared_name" : "C22H21O12 (interacts with) C21H21O10",
        "family_id" : 75,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H21O12 (interacts with) C21H21O10",
        "interaction" : "interacts with",
        "SUID" : 9851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9844",
        "source" : "9842",
        "target" : "9843",
        "shared_name" : "C14H9O10 (interacts with) C13H9O8",
        "family_id" : 23,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H9O10 (interacts with) C13H9O8",
        "interaction" : "interacts with",
        "SUID" : 9844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9839",
        "source" : "9837",
        "target" : "9838",
        "shared_name" : "C14H19O8 (interacts with) C13H19O6",
        "family_id" : 15,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H19O8 (interacts with) C13H19O6",
        "interaction" : "interacts with",
        "SUID" : 9839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9823",
        "source" : "9821",
        "target" : "9822",
        "shared_name" : "C15H13O9 (interacts with) C15H11O8",
        "family_id" : 96,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H13O9 (interacts with) C15H11O8",
        "interaction" : "interacts with",
        "SUID" : 9823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9949",
        "source" : "9810",
        "target" : "9564",
        "shared_name" : "C19H19O12 (interacts with) C18H19O10",
        "family_id" : 52,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O12 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 9949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9840",
        "source" : "9810",
        "target" : "9564",
        "shared_name" : "C19H19O12 (interacts with) C18H19O10",
        "family_id" : 71,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O12 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 9840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9811",
        "source" : "9810",
        "target" : "9564",
        "shared_name" : "C19H19O12 (interacts with) C18H19O10",
        "family_id" : 0,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O12 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 9811,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9809",
        "source" : "9807",
        "target" : "9808",
        "shared_name" : "C22H27O11 (interacts with) C21H27O9",
        "family_id" : 171,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H27O11 (interacts with) C21H27O9",
        "interaction" : "interacts with",
        "SUID" : 9809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9991",
        "source" : "9799",
        "target" : "9539",
        "shared_name" : "C20H19O10 (interacts with) C19H19O8",
        "family_id" : 84,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H19O10 (interacts with) C19H19O8",
        "interaction" : "interacts with",
        "SUID" : 9991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9834",
        "source" : "9798",
        "target" : "9799",
        "shared_name" : "C21H19O12 (interacts with) C20H19O10",
        "family_id" : 200,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H19O12 (interacts with) C20H19O10",
        "interaction" : "interacts with",
        "SUID" : 9834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9800",
        "source" : "9798",
        "target" : "9799",
        "shared_name" : "C21H19O12 (interacts with) C20H19O10",
        "family_id" : 84,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H19O12 (interacts with) C20H19O10",
        "interaction" : "interacts with",
        "SUID" : 9800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9930",
        "source" : "9796",
        "target" : "9903",
        "shared_name" : "C22H27O10 (interacts with) C22H25O9",
        "family_id" : 44,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C22H27O10 (interacts with) C22H25O9",
        "interaction" : "interacts with",
        "SUID" : 9930,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9881",
        "source" : "9796",
        "target" : "9846",
        "shared_name" : "C22H27O10 (interacts with) C21H27O8",
        "family_id" : 196,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H27O10 (interacts with) C21H27O8",
        "interaction" : "interacts with",
        "SUID" : 9881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9847",
        "source" : "9796",
        "target" : "9846",
        "shared_name" : "C22H27O10 (interacts with) C21H27O8",
        "family_id" : 128,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H27O10 (interacts with) C21H27O8",
        "interaction" : "interacts with",
        "SUID" : 9847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9797",
        "source" : "9795",
        "target" : "9796",
        "shared_name" : "C22H29O11 (interacts with) C22H27O10",
        "family_id" : 196,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C22H29O11 (interacts with) C22H27O10",
        "interaction" : "interacts with",
        "SUID" : 9797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9792",
        "source" : "9790",
        "target" : "9791",
        "shared_name" : "C19H17O9 (interacts with) C19H15O8",
        "family_id" : 129,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H17O9 (interacts with) C19H15O8",
        "interaction" : "interacts with",
        "SUID" : 9792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9981",
        "source" : "9788",
        "target" : "9980",
        "shared_name" : "C19H15O9 (interacts with) C18H15O7",
        "family_id" : 94,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H15O9 (interacts with) C18H15O7",
        "interaction" : "interacts with",
        "SUID" : 9981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9975",
        "source" : "9786",
        "target" : "9738",
        "shared_name" : "C18H19O11 (interacts with) C17H19O9",
        "family_id" : 39,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O11 (interacts with) C17H19O9",
        "interaction" : "interacts with",
        "SUID" : 9975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9787",
        "source" : "9786",
        "target" : "9738",
        "shared_name" : "C18H19O11 (interacts with) C17H19O9",
        "family_id" : 81,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O11 (interacts with) C17H19O9",
        "interaction" : "interacts with",
        "SUID" : 9787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9782",
        "source" : "9779",
        "target" : "9781",
        "shared_name" : "C16H21O9 (interacts with) C15H21O7",
        "family_id" : 120,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O9 (interacts with) C15H21O7",
        "interaction" : "interacts with",
        "SUID" : 9782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9922",
        "source" : "9777",
        "target" : "9921",
        "shared_name" : "C21H25O9 (interacts with) C20H25O7",
        "family_id" : 17,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H25O9 (interacts with) C20H25O7",
        "interaction" : "interacts with",
        "SUID" : 9922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10024",
        "source" : "9767",
        "target" : "9587",
        "shared_name" : "C16H21O10 (interacts with) C16H19O9",
        "family_id" : 118,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O10 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 10024,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10015",
        "source" : "9767",
        "target" : "9528",
        "shared_name" : "C16H21O10 (interacts with) C15H21O8",
        "family_id" : 216,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O10 (interacts with) C15H21O8",
        "interaction" : "interacts with",
        "SUID" : 10015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9956",
        "source" : "9767",
        "target" : "9528",
        "shared_name" : "C16H21O10 (interacts with) C15H21O8",
        "family_id" : 80,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O10 (interacts with) C15H21O8",
        "interaction" : "interacts with",
        "SUID" : 9956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9835",
        "source" : "9767",
        "target" : "9528",
        "shared_name" : "C16H21O10 (interacts with) C15H21O8",
        "family_id" : 25,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O10 (interacts with) C15H21O8",
        "interaction" : "interacts with",
        "SUID" : 9835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9816",
        "source" : "9767",
        "target" : "9587",
        "shared_name" : "C16H21O10 (interacts with) C16H19O9",
        "family_id" : 152,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O10 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 9816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9768",
        "source" : "9767",
        "target" : "9587",
        "shared_name" : "C16H21O10 (interacts with) C16H19O9",
        "family_id" : 77,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O10 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 9768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10035",
        "source" : "9760",
        "target" : "10034",
        "shared_name" : "C18H23O8 (interacts with) C17H23O6",
        "family_id" : 86,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O8 (interacts with) C17H23O6",
        "interaction" : "interacts with",
        "SUID" : 10035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10030",
        "source" : "9754",
        "target" : "9549",
        "shared_name" : "C21H17O12 (interacts with) C20H17O10",
        "family_id" : 187,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H17O12 (interacts with) C20H17O10",
        "interaction" : "interacts with",
        "SUID" : 10030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9755",
        "source" : "9754",
        "target" : "9549",
        "shared_name" : "C21H17O12 (interacts with) C20H17O10",
        "family_id" : 208,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H17O12 (interacts with) C20H17O10",
        "interaction" : "interacts with",
        "SUID" : 9755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9919",
        "source" : "9751",
        "target" : "9752",
        "shared_name" : "C22H19O11 (interacts with) C21H19O9",
        "family_id" : 3,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H19O11 (interacts with) C21H19O9",
        "interaction" : "interacts with",
        "SUID" : 9919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9753",
        "source" : "9751",
        "target" : "9752",
        "shared_name" : "C22H19O11 (interacts with) C21H19O9",
        "family_id" : 1,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H19O11 (interacts with) C21H19O9",
        "interaction" : "interacts with",
        "SUID" : 9753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9749",
        "source" : "9747",
        "target" : "9748",
        "shared_name" : "C21H15O12 (interacts with) C20H15O10",
        "family_id" : 89,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H15O12 (interacts with) C20H15O10",
        "interaction" : "interacts with",
        "SUID" : 9749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10070",
        "source" : "9738",
        "target" : "9959",
        "shared_name" : "C17H19O9 (interacts with) C16H19O7",
        "family_id" : 39,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O9 (interacts with) C16H19O7",
        "interaction" : "interacts with",
        "SUID" : 10070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9739",
        "source" : "9737",
        "target" : "9738",
        "shared_name" : "C17H21O10 (interacts with) C17H19O9",
        "family_id" : 195,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O10 (interacts with) C17H19O9",
        "interaction" : "interacts with",
        "SUID" : 9739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9836",
        "source" : "9735",
        "target" : "9555",
        "shared_name" : "C22H15O12 (interacts with) C21H15O10",
        "family_id" : 141,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H15O12 (interacts with) C21H15O10",
        "interaction" : "interacts with",
        "SUID" : 9836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9736",
        "source" : "9735",
        "target" : "9555",
        "shared_name" : "C22H15O12 (interacts with) C21H15O10",
        "family_id" : 198,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H15O12 (interacts with) C21H15O10",
        "interaction" : "interacts with",
        "SUID" : 9736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9889",
        "source" : "9732",
        "target" : "9679",
        "shared_name" : "C21H23O10 (interacts with) C20H23O8",
        "family_id" : 6,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O10 (interacts with) C20H23O8",
        "interaction" : "interacts with",
        "SUID" : 9889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9733",
        "source" : "9732",
        "target" : "9679",
        "shared_name" : "C21H23O10 (interacts with) C20H23O8",
        "family_id" : 88,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O10 (interacts with) C20H23O8",
        "interaction" : "interacts with",
        "SUID" : 9733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9731",
        "source" : "9729",
        "target" : "9730",
        "shared_name" : "C23H29O10 (interacts with) C22H29O8",
        "family_id" : 85,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C23H29O10 (interacts with) C22H29O8",
        "interaction" : "interacts with",
        "SUID" : 9731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9924",
        "source" : "9726",
        "target" : "9923",
        "shared_name" : "C19H23O8 (interacts with) C19H21O7",
        "family_id" : 135,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O8 (interacts with) C19H21O7",
        "interaction" : "interacts with",
        "SUID" : 9924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9728",
        "source" : "9726",
        "target" : "9727",
        "shared_name" : "C19H23O8 (interacts with) C18H23O6",
        "family_id" : 214,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O8 (interacts with) C18H23O6",
        "interaction" : "interacts with",
        "SUID" : 9728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9832",
        "source" : "9719",
        "target" : "9831",
        "shared_name" : "C22H29O10 (interacts with) C22H27O9",
        "family_id" : 168,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C22H29O10 (interacts with) C22H27O9",
        "interaction" : "interacts with",
        "SUID" : 9832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9721",
        "source" : "9719",
        "target" : "9720",
        "shared_name" : "C22H29O10 (interacts with) C21H29O8",
        "family_id" : 164,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H29O10 (interacts with) C21H29O8",
        "interaction" : "interacts with",
        "SUID" : 9721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9997",
        "source" : "9717",
        "target" : "9996",
        "shared_name" : "C16H19O8 (interacts with) C15H19O6",
        "family_id" : 117,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O8 (interacts with) C15H19O6",
        "interaction" : "interacts with",
        "SUID" : 9997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9716",
        "source" : "9714",
        "target" : "9715",
        "shared_name" : "C23H23O10 (interacts with) C22H23O8",
        "family_id" : 122,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C23H23O10 (interacts with) C22H23O8",
        "interaction" : "interacts with",
        "SUID" : 9716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10036",
        "source" : "9709",
        "target" : "9659",
        "shared_name" : "C17H19O11 (interacts with) C17H17O10",
        "family_id" : 12,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O11 (interacts with) C17H17O10",
        "interaction" : "interacts with",
        "SUID" : 10036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9969",
        "source" : "9709",
        "target" : "9587",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 31,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 9969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9953",
        "source" : "9709",
        "target" : "9587",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 55,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 9953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9920",
        "source" : "9709",
        "target" : "9587",
        "shared_name" : "C17H19O11 (interacts with) C16H19O9",
        "family_id" : 190,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O11 (interacts with) C16H19O9",
        "interaction" : "interacts with",
        "SUID" : 9920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9861",
        "source" : "9709",
        "target" : "9659",
        "shared_name" : "C17H19O11 (interacts with) C17H17O10",
        "family_id" : 58,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O11 (interacts with) C17H17O10",
        "interaction" : "interacts with",
        "SUID" : 9861,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9710",
        "source" : "9709",
        "target" : "9659",
        "shared_name" : "C17H19O11 (interacts with) C17H17O10",
        "family_id" : 72,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O11 (interacts with) C17H17O10",
        "interaction" : "interacts with",
        "SUID" : 9710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9707",
        "source" : "9705",
        "target" : "9706",
        "shared_name" : "C21H27O10 (interacts with) C20H27O8",
        "family_id" : 202,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H27O10 (interacts with) C20H27O8",
        "interaction" : "interacts with",
        "SUID" : 9707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9960",
        "source" : "9702",
        "target" : "9959",
        "shared_name" : "C16H21O8 (interacts with) C16H19O7",
        "family_id" : 47,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H21O8 (interacts with) C16H19O7",
        "interaction" : "interacts with",
        "SUID" : 9960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9704",
        "source" : "9702",
        "target" : "9703",
        "shared_name" : "C16H21O8 (interacts with) C15H21O6",
        "family_id" : 10,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H21O8 (interacts with) C15H21O6",
        "interaction" : "interacts with",
        "SUID" : 9704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9972",
        "source" : "9699",
        "target" : "9712",
        "shared_name" : "C18H19O8 (interacts with) C17H19O6",
        "family_id" : 20,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O8 (interacts with) C17H19O6",
        "interaction" : "interacts with",
        "SUID" : 9972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9713",
        "source" : "9699",
        "target" : "9712",
        "shared_name" : "C18H19O8 (interacts with) C17H19O6",
        "family_id" : 53,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O8 (interacts with) C17H19O6",
        "interaction" : "interacts with",
        "SUID" : 9713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10050",
        "source" : "9692",
        "target" : "9607",
        "shared_name" : "C17H23O9 (interacts with) C17H21O8",
        "family_id" : 125,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H23O9 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 10050,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9951",
        "source" : "9692",
        "target" : "9607",
        "shared_name" : "C17H23O9 (interacts with) C17H21O8",
        "family_id" : 78,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H23O9 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 9951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9694",
        "source" : "9692",
        "target" : "9693",
        "shared_name" : "C17H23O9 (interacts with) C16H23O7",
        "family_id" : 130,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H23O9 (interacts with) C16H23O7",
        "interaction" : "interacts with",
        "SUID" : 9694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9761",
        "source" : "9690",
        "target" : "9760",
        "shared_name" : "C18H25O9 (interacts with) C18H23O8",
        "family_id" : 133,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H25O9 (interacts with) C18H23O8",
        "interaction" : "interacts with",
        "SUID" : 9761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10051",
        "source" : "9689",
        "target" : "9536",
        "shared_name" : "C19H25O11 (interacts with) C19H23O10",
        "family_id" : 73,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O11 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 10051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9957",
        "source" : "9689",
        "target" : "9690",
        "shared_name" : "C19H25O11 (interacts with) C18H25O9",
        "family_id" : 133,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H25O11 (interacts with) C18H25O9",
        "interaction" : "interacts with",
        "SUID" : 9957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9952",
        "source" : "9689",
        "target" : "9536",
        "shared_name" : "C19H25O11 (interacts with) C19H23O10",
        "family_id" : 181,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O11 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 9952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9691",
        "source" : "9689",
        "target" : "9690",
        "shared_name" : "C19H25O11 (interacts with) C18H25O9",
        "family_id" : 136,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H25O11 (interacts with) C18H25O9",
        "interaction" : "interacts with",
        "SUID" : 9691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9998",
        "source" : "9687",
        "target" : "9636",
        "shared_name" : "C21H27O12 (interacts with) C21H25O11",
        "family_id" : 111,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H27O12 (interacts with) C21H25O11",
        "interaction" : "interacts with",
        "SUID" : 9998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9907",
        "source" : "9687",
        "target" : "9636",
        "shared_name" : "C21H27O12 (interacts with) C21H25O11",
        "family_id" : 156,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H27O12 (interacts with) C21H25O11",
        "interaction" : "interacts with",
        "SUID" : 9907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9859",
        "source" : "9687",
        "target" : "9581",
        "shared_name" : "C21H27O12 (interacts with) C20H27O10",
        "family_id" : 170,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H27O12 (interacts with) C20H27O10",
        "interaction" : "interacts with",
        "SUID" : 9859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9688",
        "source" : "9687",
        "target" : "9636",
        "shared_name" : "C21H27O12 (interacts with) C21H25O11",
        "family_id" : 88,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H27O12 (interacts with) C21H25O11",
        "interaction" : "interacts with",
        "SUID" : 9688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9971",
        "source" : "9682",
        "target" : "9970",
        "shared_name" : "C14H17O8 (interacts with) C14H15O7",
        "family_id" : 30,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H17O8 (interacts with) C14H15O7",
        "interaction" : "interacts with",
        "SUID" : 9971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9684",
        "source" : "9682",
        "target" : "9683",
        "shared_name" : "C14H17O8 (interacts with) C13H17O6",
        "family_id" : 62,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C14H17O8 (interacts with) C13H17O6",
        "interaction" : "interacts with",
        "SUID" : 9684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9961",
        "source" : "9679",
        "target" : "9680",
        "shared_name" : "C20H23O8 (interacts with) C19H23O6",
        "family_id" : 88,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O8 (interacts with) C19H23O6",
        "interaction" : "interacts with",
        "SUID" : 9961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9681",
        "source" : "9679",
        "target" : "9680",
        "shared_name" : "C20H23O8 (interacts with) C19H23O6",
        "family_id" : 111,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O8 (interacts with) C19H23O6",
        "interaction" : "interacts with",
        "SUID" : 9681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9677",
        "source" : "9675",
        "target" : "9676",
        "shared_name" : "C20H27O11 (interacts with) C19H27O9",
        "family_id" : 93,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H27O11 (interacts with) C19H27O9",
        "interaction" : "interacts with",
        "SUID" : 9677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9673",
        "source" : "9671",
        "target" : "9672",
        "shared_name" : "C21H13O13 (interacts with) C20H13O11",
        "family_id" : 87,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H13O13 (interacts with) C20H13O11",
        "interaction" : "interacts with",
        "SUID" : 9673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9964",
        "source" : "9662",
        "target" : "9790",
        "shared_name" : "C19H19O10 (interacts with) C19H17O9",
        "family_id" : 126,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H19O10 (interacts with) C19H17O9",
        "interaction" : "interacts with",
        "SUID" : 9964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9883",
        "source" : "9662",
        "target" : "9699",
        "shared_name" : "C19H19O10 (interacts with) C18H19O8",
        "family_id" : 53,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O10 (interacts with) C18H19O8",
        "interaction" : "interacts with",
        "SUID" : 9883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9824",
        "source" : "9662",
        "target" : "9699",
        "shared_name" : "C19H19O10 (interacts with) C18H19O8",
        "family_id" : 28,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O10 (interacts with) C18H19O8",
        "interaction" : "interacts with",
        "SUID" : 9824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9848",
        "source" : "9661",
        "target" : "9662",
        "shared_name" : "C20H19O12 (interacts with) C19H19O10",
        "family_id" : 102,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H19O12 (interacts with) C19H19O10",
        "interaction" : "interacts with",
        "SUID" : 9848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9663",
        "source" : "9661",
        "target" : "9662",
        "shared_name" : "C20H19O12 (interacts with) C19H19O10",
        "family_id" : 126,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H19O12 (interacts with) C19H19O10",
        "interaction" : "interacts with",
        "SUID" : 9663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9701",
        "source" : "9659",
        "target" : "9494",
        "shared_name" : "C17H17O10 (interacts with) C16H17O8",
        "family_id" : 72,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O10 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 9701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9660",
        "source" : "9659",
        "target" : "9494",
        "shared_name" : "C17H17O10 (interacts with) C16H17O8",
        "family_id" : 58,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H17O10 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 9660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9686",
        "source" : "9657",
        "target" : "9685",
        "shared_name" : "C18H17O9 (interacts with) C17H17O7",
        "family_id" : 16,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H17O9 (interacts with) C17H17O7",
        "interaction" : "interacts with",
        "SUID" : 9686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9979",
        "source" : "9655",
        "target" : "9978",
        "shared_name" : "C21H23O9 (interacts with) C20H23O7",
        "family_id" : 48,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O9 (interacts with) C20H23O7",
        "interaction" : "interacts with",
        "SUID" : 9979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9910",
        "source" : "9654",
        "target" : "9655",
        "shared_name" : "C22H23O11 (interacts with) C21H23O9",
        "family_id" : 48,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H23O11 (interacts with) C21H23O9",
        "interaction" : "interacts with",
        "SUID" : 9910,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9656",
        "source" : "9654",
        "target" : "9655",
        "shared_name" : "C22H23O11 (interacts with) C21H23O9",
        "family_id" : 193,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H23O11 (interacts with) C21H23O9",
        "interaction" : "interacts with",
        "SUID" : 9656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9932",
        "source" : "9650",
        "target" : "9931",
        "shared_name" : "C17H23O8 (interacts with) C16H23O6",
        "family_id" : 68,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H23O8 (interacts with) C16H23O6",
        "interaction" : "interacts with",
        "SUID" : 9932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9926",
        "source" : "9649",
        "target" : "9504",
        "shared_name" : "C18H23O10 (interacts with) C18H21O9",
        "family_id" : 104,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O10 (interacts with) C18H21O9",
        "interaction" : "interacts with",
        "SUID" : 9926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9667",
        "source" : "9649",
        "target" : "9650",
        "shared_name" : "C18H23O10 (interacts with) C17H23O8",
        "family_id" : 68,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O10 (interacts with) C17H23O8",
        "interaction" : "interacts with",
        "SUID" : 9667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9651",
        "source" : "9649",
        "target" : "9650",
        "shared_name" : "C18H23O10 (interacts with) C17H23O8",
        "family_id" : 188,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O10 (interacts with) C17H23O8",
        "interaction" : "interacts with",
        "SUID" : 9651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9874",
        "source" : "9647",
        "target" : "9530",
        "shared_name" : "C21H21O12 (interacts with) C21H19O11",
        "family_id" : 178,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H21O12 (interacts with) C21H19O11",
        "interaction" : "interacts with",
        "SUID" : 9874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9812",
        "source" : "9647",
        "target" : "9553",
        "shared_name" : "C21H21O12 (interacts with) C20H21O10",
        "family_id" : 109,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O12 (interacts with) C20H21O10",
        "interaction" : "interacts with",
        "SUID" : 9812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9804",
        "source" : "9647",
        "target" : "9553",
        "shared_name" : "C21H21O12 (interacts with) C20H21O10",
        "family_id" : 132,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O12 (interacts with) C20H21O10",
        "interaction" : "interacts with",
        "SUID" : 9804,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9773",
        "source" : "9647",
        "target" : "9553",
        "shared_name" : "C21H21O12 (interacts with) C20H21O10",
        "family_id" : 57,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O12 (interacts with) C20H21O10",
        "interaction" : "interacts with",
        "SUID" : 9773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9698",
        "source" : "9647",
        "target" : "9530",
        "shared_name" : "C21H21O12 (interacts with) C21H19O11",
        "family_id" : 105,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H21O12 (interacts with) C21H19O11",
        "interaction" : "interacts with",
        "SUID" : 9698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9695",
        "source" : "9647",
        "target" : "9530",
        "shared_name" : "C21H21O12 (interacts with) C21H19O11",
        "family_id" : 176,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H21O12 (interacts with) C21H19O11",
        "interaction" : "interacts with",
        "SUID" : 9695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9648",
        "source" : "9647",
        "target" : "9553",
        "shared_name" : "C21H21O12 (interacts with) C20H21O10",
        "family_id" : 54,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O12 (interacts with) C20H21O10",
        "interaction" : "interacts with",
        "SUID" : 9648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9852",
        "source" : "9642",
        "target" : "9628",
        "shared_name" : "C20H25O12 (interacts with) C19H25O10",
        "family_id" : 134,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O12 (interacts with) C19H25O10",
        "interaction" : "interacts with",
        "SUID" : 9852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9643",
        "source" : "9642",
        "target" : "9628",
        "shared_name" : "C20H25O12 (interacts with) C19H25O10",
        "family_id" : 204,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O12 (interacts with) C19H25O10",
        "interaction" : "interacts with",
        "SUID" : 9643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10022",
        "source" : "9637",
        "target" : "9679",
        "shared_name" : "C20H25O9 (interacts with) C20H23O8",
        "family_id" : 111,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O9 (interacts with) C20H23O8",
        "interaction" : "interacts with",
        "SUID" : 10022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9968",
        "source" : "9636",
        "target" : "9732",
        "shared_name" : "C21H25O11 (interacts with) C21H23O10",
        "family_id" : 206,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H25O11 (interacts with) C21H23O10",
        "interaction" : "interacts with",
        "SUID" : 9968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9917",
        "source" : "9636",
        "target" : "9732",
        "shared_name" : "C21H25O11 (interacts with) C21H23O10",
        "family_id" : 88,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H25O11 (interacts with) C21H23O10",
        "interaction" : "interacts with",
        "SUID" : 9917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9774",
        "source" : "9636",
        "target" : "9732",
        "shared_name" : "C21H25O11 (interacts with) C21H23O10",
        "family_id" : 6,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H25O11 (interacts with) C21H23O10",
        "interaction" : "interacts with",
        "SUID" : 9774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9666",
        "source" : "9636",
        "target" : "9637",
        "shared_name" : "C21H25O11 (interacts with) C20H25O9",
        "family_id" : 169,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H25O11 (interacts with) C20H25O9",
        "interaction" : "interacts with",
        "SUID" : 9666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9638",
        "source" : "9636",
        "target" : "9637",
        "shared_name" : "C21H25O11 (interacts with) C20H25O9",
        "family_id" : 111,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H25O11 (interacts with) C20H25O9",
        "interaction" : "interacts with",
        "SUID" : 9638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10000",
        "source" : "9631",
        "target" : "9726",
        "shared_name" : "C19H25O9 (interacts with) C19H23O8",
        "family_id" : 45,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O9 (interacts with) C19H23O8",
        "interaction" : "interacts with",
        "SUID" : 10000,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9784",
        "source" : "9631",
        "target" : "9783",
        "shared_name" : "C19H25O9 (interacts with) C18H25O7",
        "family_id" : 177,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H25O9 (interacts with) C18H25O7",
        "interaction" : "interacts with",
        "SUID" : 9784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9665",
        "source" : "9628",
        "target" : "9629",
        "shared_name" : "C19H25O10 (interacts with) C19H23O9",
        "family_id" : 184,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O10 (interacts with) C19H23O9",
        "interaction" : "interacts with",
        "SUID" : 9665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9630",
        "source" : "9628",
        "target" : "9629",
        "shared_name" : "C19H25O10 (interacts with) C19H23O9",
        "family_id" : 204,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H25O10 (interacts with) C19H23O9",
        "interaction" : "interacts with",
        "SUID" : 9630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9993",
        "source" : "9626",
        "target" : "9743",
        "shared_name" : "C21H21O10 (interacts with) C20H21O8",
        "family_id" : 75,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O10 (interacts with) C20H21O8",
        "interaction" : "interacts with",
        "SUID" : 9993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9794",
        "source" : "9626",
        "target" : "9743",
        "shared_name" : "C21H21O10 (interacts with) C20H21O8",
        "family_id" : 5,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O10 (interacts with) C20H21O8",
        "interaction" : "interacts with",
        "SUID" : 9794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9901",
        "source" : "9623",
        "target" : "9788",
        "shared_name" : "C20H15O11 (interacts with) C19H15O9",
        "family_id" : 144,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H15O11 (interacts with) C19H15O9",
        "interaction" : "interacts with",
        "SUID" : 9901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9864",
        "source" : "9623",
        "target" : "9788",
        "shared_name" : "C20H15O11 (interacts with) C19H15O9",
        "family_id" : 94,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H15O11 (interacts with) C19H15O9",
        "interaction" : "interacts with",
        "SUID" : 9864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9789",
        "source" : "9623",
        "target" : "9788",
        "shared_name" : "C20H15O11 (interacts with) C19H15O9",
        "family_id" : 43,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H15O11 (interacts with) C19H15O9",
        "interaction" : "interacts with",
        "SUID" : 9789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9872",
        "source" : "9622",
        "target" : "9623",
        "shared_name" : "C21H15O13 (interacts with) C20H15O11",
        "family_id" : 94,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H15O13 (interacts with) C20H15O11",
        "interaction" : "interacts with",
        "SUID" : 9872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9633",
        "source" : "9622",
        "target" : "9623",
        "shared_name" : "C21H15O13 (interacts with) C20H15O11",
        "family_id" : 9,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H15O13 (interacts with) C20H15O11",
        "interaction" : "interacts with",
        "SUID" : 9633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9624",
        "source" : "9622",
        "target" : "9623",
        "shared_name" : "C21H15O13 (interacts with) C20H15O11",
        "family_id" : 43,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H15O13 (interacts with) C20H15O11",
        "interaction" : "interacts with",
        "SUID" : 9624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9621",
        "source" : "9619",
        "target" : "9620",
        "shared_name" : "C19H17O12 (interacts with) C19H15O11",
        "family_id" : 110,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H17O12 (interacts with) C19H15O11",
        "interaction" : "interacts with",
        "SUID" : 9621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9954",
        "source" : "9617",
        "target" : "9564",
        "shared_name" : "C18H21O11 (interacts with) C18H19O10",
        "family_id" : 16,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O11 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 9954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9941",
        "source" : "9617",
        "target" : "9591",
        "shared_name" : "C18H21O11 (interacts with) C17H21O9",
        "family_id" : 70,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O11 (interacts with) C17H21O9",
        "interaction" : "interacts with",
        "SUID" : 9941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9905",
        "source" : "9617",
        "target" : "9591",
        "shared_name" : "C18H21O11 (interacts with) C17H21O9",
        "family_id" : 166,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O11 (interacts with) C17H21O9",
        "interaction" : "interacts with",
        "SUID" : 9905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9863",
        "source" : "9617",
        "target" : "9564",
        "shared_name" : "C18H21O11 (interacts with) C18H19O10",
        "family_id" : 192,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O11 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 9863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9833",
        "source" : "9617",
        "target" : "9591",
        "shared_name" : "C18H21O11 (interacts with) C17H21O9",
        "family_id" : 123,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O11 (interacts with) C17H21O9",
        "interaction" : "interacts with",
        "SUID" : 9833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9763",
        "source" : "9617",
        "target" : "9564",
        "shared_name" : "C18H21O11 (interacts with) C18H19O10",
        "family_id" : 145,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O11 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 9763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9674",
        "source" : "9617",
        "target" : "9591",
        "shared_name" : "C18H21O11 (interacts with) C17H21O9",
        "family_id" : 33,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O11 (interacts with) C17H21O9",
        "interaction" : "interacts with",
        "SUID" : 9674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9625",
        "source" : "9617",
        "target" : "9564",
        "shared_name" : "C18H21O11 (interacts with) C18H19O10",
        "family_id" : 64,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O11 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 9625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9618",
        "source" : "9617",
        "target" : "9564",
        "shared_name" : "C18H21O11 (interacts with) C18H19O10",
        "family_id" : 76,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O11 (interacts with) C18H19O10",
        "interaction" : "interacts with",
        "SUID" : 9618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10073",
        "source" : "9614",
        "target" : "9524",
        "shared_name" : "C19H21O12 (interacts with) C18H21O10",
        "family_id" : 29,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O12 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 10073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9934",
        "source" : "9614",
        "target" : "9524",
        "shared_name" : "C19H21O12 (interacts with) C18H21O10",
        "family_id" : 158,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O12 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 9934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9879",
        "source" : "9614",
        "target" : "9524",
        "shared_name" : "C19H21O12 (interacts with) C18H21O10",
        "family_id" : 203,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O12 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 9879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9871",
        "source" : "9614",
        "target" : "9524",
        "shared_name" : "C19H21O12 (interacts with) C18H21O10",
        "family_id" : 197,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O12 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 9871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9615",
        "source" : "9614",
        "target" : "9524",
        "shared_name" : "C19H21O12 (interacts with) C18H21O10",
        "family_id" : 18,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O12 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 9615,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9963",
        "source" : "9611",
        "target" : "9741",
        "shared_name" : "C19H21O10 (interacts with) C18H21O8",
        "family_id" : 182,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O10 (interacts with) C18H21O8",
        "interaction" : "interacts with",
        "SUID" : 9963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9785",
        "source" : "9611",
        "target" : "9547",
        "shared_name" : "C19H21O10 (interacts with) C19H19O9",
        "family_id" : 167,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O10 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 9785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9668",
        "source" : "9611",
        "target" : "9547",
        "shared_name" : "C19H21O10 (interacts with) C19H19O9",
        "family_id" : 186,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O10 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 9668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10061",
        "source" : "9610",
        "target" : "9546",
        "shared_name" : "C20H21O12 (interacts with) C20H19O11",
        "family_id" : 162,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H21O12 (interacts with) C20H19O11",
        "interaction" : "interacts with",
        "SUID" : 10061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9893",
        "source" : "9610",
        "target" : "9611",
        "shared_name" : "C20H21O12 (interacts with) C19H21O10",
        "family_id" : 167,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O12 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 9893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9854",
        "source" : "9610",
        "target" : "9611",
        "shared_name" : "C20H21O12 (interacts with) C19H21O10",
        "family_id" : 107,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O12 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 9854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9819",
        "source" : "9610",
        "target" : "9546",
        "shared_name" : "C20H21O12 (interacts with) C20H19O11",
        "family_id" : 149,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H21O12 (interacts with) C20H19O11",
        "interaction" : "interacts with",
        "SUID" : 9819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9612",
        "source" : "9610",
        "target" : "9611",
        "shared_name" : "C20H21O12 (interacts with) C19H21O10",
        "family_id" : 182,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O12 (interacts with) C19H21O10",
        "interaction" : "interacts with",
        "SUID" : 9612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10069",
        "source" : "9607",
        "target" : "9802",
        "shared_name" : "C17H21O8 (interacts with) C17H19O7",
        "family_id" : 63,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O8 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 10069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10066",
        "source" : "9607",
        "target" : "9802",
        "shared_name" : "C17H21O8 (interacts with) C17H19O7",
        "family_id" : 203,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O8 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 10066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9936",
        "source" : "9607",
        "target" : "9935",
        "shared_name" : "C17H21O8 (interacts with) C16H21O6",
        "family_id" : 108,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H21O8 (interacts with) C16H21O6",
        "interaction" : "interacts with",
        "SUID" : 9936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10021",
        "source" : "9605",
        "target" : "10020",
        "shared_name" : "C22H23O10 (interacts with) C21H23O8",
        "family_id" : 172,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H23O10 (interacts with) C21H23O8",
        "interaction" : "interacts with",
        "SUID" : 10021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10037",
        "source" : "9604",
        "target" : "9777",
        "shared_name" : "C22H25O11 (interacts with) C21H25O9",
        "family_id" : 211,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H25O11 (interacts with) C21H25O9",
        "interaction" : "interacts with",
        "SUID" : 10037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9778",
        "source" : "9604",
        "target" : "9777",
        "shared_name" : "C22H25O11 (interacts with) C21H25O9",
        "family_id" : 17,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H25O11 (interacts with) C21H25O9",
        "interaction" : "interacts with",
        "SUID" : 9778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9697",
        "source" : "9604",
        "target" : "9605",
        "shared_name" : "C22H25O11 (interacts with) C22H23O10",
        "family_id" : 147,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C22H25O11 (interacts with) C22H23O10",
        "interaction" : "interacts with",
        "SUID" : 9697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9606",
        "source" : "9604",
        "target" : "9605",
        "shared_name" : "C22H25O11 (interacts with) C22H23O10",
        "family_id" : 172,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C22H25O11 (interacts with) C22H23O10",
        "interaction" : "interacts with",
        "SUID" : 9606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10009",
        "source" : "9601",
        "target" : "9598",
        "shared_name" : "C21H23O11 (interacts with) C20H23O9",
        "family_id" : 91,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O11 (interacts with) C20H23O9",
        "interaction" : "interacts with",
        "SUID" : 10009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9958",
        "source" : "9601",
        "target" : "9598",
        "shared_name" : "C21H23O11 (interacts with) C20H23O9",
        "family_id" : 59,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O11 (interacts with) C20H23O9",
        "interaction" : "interacts with",
        "SUID" : 9958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9918",
        "source" : "9601",
        "target" : "9598",
        "shared_name" : "C21H23O11 (interacts with) C20H23O9",
        "family_id" : 174,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O11 (interacts with) C20H23O9",
        "interaction" : "interacts with",
        "SUID" : 9918,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9734",
        "source" : "9601",
        "target" : "9626",
        "shared_name" : "C21H23O11 (interacts with) C21H21O10",
        "family_id" : 213,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H23O11 (interacts with) C21H21O10",
        "interaction" : "interacts with",
        "SUID" : 9734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9678",
        "source" : "9601",
        "target" : "9598",
        "shared_name" : "C21H23O11 (interacts with) C20H23O9",
        "family_id" : 40,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O11 (interacts with) C20H23O9",
        "interaction" : "interacts with",
        "SUID" : 9678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9627",
        "source" : "9601",
        "target" : "9626",
        "shared_name" : "C21H23O11 (interacts with) C21H21O10",
        "family_id" : 5,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H23O11 (interacts with) C21H21O10",
        "interaction" : "interacts with",
        "SUID" : 9627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10052",
        "source" : "9600",
        "target" : "9597",
        "shared_name" : "C21H25O12 (interacts with) C20H25O10",
        "family_id" : 35,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H25O12 (interacts with) C20H25O10",
        "interaction" : "interacts with",
        "SUID" : 10052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10010",
        "source" : "9600",
        "target" : "9597",
        "shared_name" : "C21H25O12 (interacts with) C20H25O10",
        "family_id" : 112,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H25O12 (interacts with) C20H25O10",
        "interaction" : "interacts with",
        "SUID" : 10010,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9885",
        "source" : "9600",
        "target" : "9601",
        "shared_name" : "C21H25O12 (interacts with) C21H23O11",
        "family_id" : 151,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H25O12 (interacts with) C21H23O11",
        "interaction" : "interacts with",
        "SUID" : 9885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9828",
        "source" : "9600",
        "target" : "9597",
        "shared_name" : "C21H25O12 (interacts with) C20H25O10",
        "family_id" : 185,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H25O12 (interacts with) C20H25O10",
        "interaction" : "interacts with",
        "SUID" : 9828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9826",
        "source" : "9600",
        "target" : "9597",
        "shared_name" : "C21H25O12 (interacts with) C20H25O10",
        "family_id" : 98,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H25O12 (interacts with) C20H25O10",
        "interaction" : "interacts with",
        "SUID" : 9826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9762",
        "source" : "9600",
        "target" : "9601",
        "shared_name" : "C21H25O12 (interacts with) C21H23O11",
        "family_id" : 40,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H25O12 (interacts with) C21H23O11",
        "interaction" : "interacts with",
        "SUID" : 9762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9602",
        "source" : "9600",
        "target" : "9601",
        "shared_name" : "C21H25O12 (interacts with) C21H23O11",
        "family_id" : 174,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H25O12 (interacts with) C21H23O11",
        "interaction" : "interacts with",
        "SUID" : 9602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10059",
        "source" : "9598",
        "target" : "10038",
        "shared_name" : "C20H23O9 (interacts with) C19H23O7",
        "family_id" : 98,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O9 (interacts with) C19H23O7",
        "interaction" : "interacts with",
        "SUID" : 10059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10039",
        "source" : "9598",
        "target" : "10038",
        "shared_name" : "C20H23O9 (interacts with) C19H23O7",
        "family_id" : 174,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O9 (interacts with) C19H23O7",
        "interaction" : "interacts with",
        "SUID" : 10039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9744",
        "source" : "9598",
        "target" : "9743",
        "shared_name" : "C20H23O9 (interacts with) C20H21O8",
        "family_id" : 91,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O9 (interacts with) C20H21O8",
        "interaction" : "interacts with",
        "SUID" : 9744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9746",
        "source" : "9597",
        "target" : "9745",
        "shared_name" : "C20H25O10 (interacts with) C19H25O8",
        "family_id" : 35,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O10 (interacts with) C19H25O8",
        "interaction" : "interacts with",
        "SUID" : 9746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9613",
        "source" : "9597",
        "target" : "9598",
        "shared_name" : "C20H25O10 (interacts with) C20H23O9",
        "family_id" : 112,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O10 (interacts with) C20H23O9",
        "interaction" : "interacts with",
        "SUID" : 9613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9599",
        "source" : "9597",
        "target" : "9598",
        "shared_name" : "C20H25O10 (interacts with) C20H23O9",
        "family_id" : 98,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O10 (interacts with) C20H23O9",
        "interaction" : "interacts with",
        "SUID" : 9599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10072",
        "source" : "9594",
        "target" : "10071",
        "shared_name" : "C15H19O8 (interacts with) C14H19O6",
        "family_id" : 50,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H19O8 (interacts with) C14H19O6",
        "interaction" : "interacts with",
        "SUID" : 10072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9938",
        "source" : "9593",
        "target" : "9937",
        "shared_name" : "C16H19O10 (interacts with) C16H17O9",
        "family_id" : 14,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O10 (interacts with) C16H17O9",
        "interaction" : "interacts with",
        "SUID" : 9938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9711",
        "source" : "9593",
        "target" : "9594",
        "shared_name" : "C16H19O10 (interacts with) C15H19O8",
        "family_id" : 50,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O10 (interacts with) C15H19O8",
        "interaction" : "interacts with",
        "SUID" : 9711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9595",
        "source" : "9593",
        "target" : "9594",
        "shared_name" : "C16H19O10 (interacts with) C15H19O8",
        "family_id" : 61,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O10 (interacts with) C15H19O8",
        "interaction" : "interacts with",
        "SUID" : 9595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9994",
        "source" : "9591",
        "target" : "9506",
        "shared_name" : "C17H21O9 (interacts with) C17H19O8",
        "family_id" : 123,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O9 (interacts with) C17H19O8",
        "interaction" : "interacts with",
        "SUID" : 9994,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9899",
        "source" : "9591",
        "target" : "9898",
        "shared_name" : "C17H21O9 (interacts with) C16H21O7",
        "family_id" : 70,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H21O9 (interacts with) C16H21O7",
        "interaction" : "interacts with",
        "SUID" : 9899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9592",
        "source" : "9591",
        "target" : "9506",
        "shared_name" : "C17H21O9 (interacts with) C17H19O8",
        "family_id" : 166,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O9 (interacts with) C17H19O8",
        "interaction" : "interacts with",
        "SUID" : 9592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10053",
        "source" : "9589",
        "target" : "9631",
        "shared_name" : "C20H25O11 (interacts with) C19H25O9",
        "family_id" : 45,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O11 (interacts with) C19H25O9",
        "interaction" : "interacts with",
        "SUID" : 10053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9973",
        "source" : "9589",
        "target" : "9534",
        "shared_name" : "C20H25O11 (interacts with) C20H23O10",
        "family_id" : 114,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O11 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 9973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9882",
        "source" : "9589",
        "target" : "9534",
        "shared_name" : "C20H25O11 (interacts with) C20H23O10",
        "family_id" : 121,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O11 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 9882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9860",
        "source" : "9589",
        "target" : "9631",
        "shared_name" : "C20H25O11 (interacts with) C19H25O9",
        "family_id" : 199,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O11 (interacts with) C19H25O9",
        "interaction" : "interacts with",
        "SUID" : 9860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9696",
        "source" : "9589",
        "target" : "9534",
        "shared_name" : "C20H25O11 (interacts with) C20H23O10",
        "family_id" : 113,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O11 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 9696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9632",
        "source" : "9589",
        "target" : "9631",
        "shared_name" : "C20H25O11 (interacts with) C19H25O9",
        "family_id" : 177,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H25O11 (interacts with) C19H25O9",
        "interaction" : "interacts with",
        "SUID" : 9632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9590",
        "source" : "9589",
        "target" : "9534",
        "shared_name" : "C20H25O11 (interacts with) C20H23O10",
        "family_id" : 100,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H25O11 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 9590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9940",
        "source" : "9587",
        "target" : "9500",
        "shared_name" : "C16H19O9 (interacts with) C15H19O7",
        "family_id" : 118,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O9 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 9940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9813",
        "source" : "9587",
        "target" : "9500",
        "shared_name" : "C16H19O9 (interacts with) C15H19O7",
        "family_id" : 152,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O9 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 9813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9756",
        "source" : "9587",
        "target" : "9500",
        "shared_name" : "C16H19O9 (interacts with) C15H19O7",
        "family_id" : 36,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O9 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 9756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9670",
        "source" : "9587",
        "target" : "9494",
        "shared_name" : "C16H19O9 (interacts with) C16H17O8",
        "family_id" : 55,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C16H19O9 (interacts with) C16H17O8",
        "interaction" : "interacts with",
        "SUID" : 9670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9588",
        "source" : "9587",
        "target" : "9500",
        "shared_name" : "C16H19O9 (interacts with) C15H19O7",
        "family_id" : 190,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H19O9 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 9588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9915",
        "source" : "9585",
        "target" : "9560",
        "shared_name" : "C19H23O11 (interacts with) C18H23O9",
        "family_id" : 26,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O11 (interacts with) C18H23O9",
        "interaction" : "interacts with",
        "SUID" : 9915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9645",
        "source" : "9585",
        "target" : "9560",
        "shared_name" : "C19H23O11 (interacts with) C18H23O9",
        "family_id" : 67,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O11 (interacts with) C18H23O9",
        "interaction" : "interacts with",
        "SUID" : 9645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9586",
        "source" : "9585",
        "target" : "9560",
        "shared_name" : "C19H23O11 (interacts with) C18H23O9",
        "family_id" : 154,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O11 (interacts with) C18H23O9",
        "interaction" : "interacts with",
        "SUID" : 9586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9583",
        "source" : "9581",
        "target" : "9582",
        "shared_name" : "C20H27O10 (interacts with) C19H27O8",
        "family_id" : 42,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H27O10 (interacts with) C19H27O8",
        "interaction" : "interacts with",
        "SUID" : 9583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10023",
        "source" : "9576",
        "target" : "9987",
        "shared_name" : "C17H19O10 (interacts with) C17H17O9",
        "family_id" : 201,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H19O10 (interacts with) C17H17O9",
        "interaction" : "interacts with",
        "SUID" : 10023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9718",
        "source" : "9576",
        "target" : "9717",
        "shared_name" : "C17H19O10 (interacts with) C16H19O8",
        "family_id" : 117,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O10 (interacts with) C16H19O8",
        "interaction" : "interacts with",
        "SUID" : 9718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9780",
        "source" : "9575",
        "target" : "9779",
        "shared_name" : "C17H21O11 (interacts with) C16H21O9",
        "family_id" : 83,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H21O11 (interacts with) C16H21O9",
        "interaction" : "interacts with",
        "SUID" : 9780,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9725",
        "source" : "9575",
        "target" : "9576",
        "shared_name" : "C17H21O11 (interacts with) C17H19O10",
        "family_id" : 201,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O11 (interacts with) C17H19O10",
        "interaction" : "interacts with",
        "SUID" : 9725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9580",
        "source" : "9575",
        "target" : "9576",
        "shared_name" : "C17H21O11 (interacts with) C17H19O10",
        "family_id" : 117,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O11 (interacts with) C17H19O10",
        "interaction" : "interacts with",
        "SUID" : 9580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9577",
        "source" : "9575",
        "target" : "9576",
        "shared_name" : "C17H21O11 (interacts with) C17H19O10",
        "family_id" : 138,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C17H21O11 (interacts with) C17H19O10",
        "interaction" : "interacts with",
        "SUID" : 9577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9820",
        "source" : "9572",
        "target" : "9805",
        "shared_name" : "C21H19O10 (interacts with) C20H19O8",
        "family_id" : 2,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H19O10 (interacts with) C20H19O8",
        "interaction" : "interacts with",
        "SUID" : 9820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9770",
        "source" : "9571",
        "target" : "9572",
        "shared_name" : "C22H19O12 (interacts with) C21H19O10",
        "family_id" : 66,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H19O12 (interacts with) C21H19O10",
        "interaction" : "interacts with",
        "SUID" : 9770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9573",
        "source" : "9571",
        "target" : "9572",
        "shared_name" : "C22H19O12 (interacts with) C21H19O10",
        "family_id" : 2,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H19O12 (interacts with) C21H19O10",
        "interaction" : "interacts with",
        "SUID" : 9573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9723",
        "source" : "9569",
        "target" : "9722",
        "shared_name" : "C21H17O10 (interacts with) C20H17O8",
        "family_id" : 194,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H17O10 (interacts with) C20H17O8",
        "interaction" : "interacts with",
        "SUID" : 9723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9912",
        "source" : "9568",
        "target" : "9911",
        "shared_name" : "C22H17O12 (interacts with) C22H15O11",
        "family_id" : 212,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C22H17O12 (interacts with) C22H15O11",
        "interaction" : "interacts with",
        "SUID" : 9912,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9855",
        "source" : "9568",
        "target" : "9569",
        "shared_name" : "C22H17O12 (interacts with) C21H17O10",
        "family_id" : 205,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H17O12 (interacts with) C21H17O10",
        "interaction" : "interacts with",
        "SUID" : 9855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9570",
        "source" : "9568",
        "target" : "9569",
        "shared_name" : "C22H17O12 (interacts with) C21H17O10",
        "family_id" : 194,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C22H17O12 (interacts with) C21H17O10",
        "interaction" : "interacts with",
        "SUID" : 9570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10005",
        "source" : "9566",
        "target" : "9802",
        "shared_name" : "C18H19O9 (interacts with) C17H19O7",
        "family_id" : 173,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O9 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 10005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9803",
        "source" : "9566",
        "target" : "9802",
        "shared_name" : "C18H19O9 (interacts with) C17H19O7",
        "family_id" : 29,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O9 (interacts with) C17H19O7",
        "interaction" : "interacts with",
        "SUID" : 9803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9825",
        "source" : "9564",
        "target" : "9657",
        "shared_name" : "C18H19O10 (interacts with) C18H17O9",
        "family_id" : 145,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O10 (interacts with) C18H17O9",
        "interaction" : "interacts with",
        "SUID" : 9825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9814",
        "source" : "9564",
        "target" : "9506",
        "shared_name" : "C18H19O10 (interacts with) C17H19O8",
        "family_id" : 0,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O10 (interacts with) C17H19O8",
        "interaction" : "interacts with",
        "SUID" : 9814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9658",
        "source" : "9564",
        "target" : "9657",
        "shared_name" : "C18H19O10 (interacts with) C18H17O9",
        "family_id" : 16,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H19O10 (interacts with) C18H17O9",
        "interaction" : "interacts with",
        "SUID" : 9658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9644",
        "source" : "9564",
        "target" : "9506",
        "shared_name" : "C18H19O10 (interacts with) C17H19O8",
        "family_id" : 192,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O10 (interacts with) C17H19O8",
        "interaction" : "interacts with",
        "SUID" : 9644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9640",
        "source" : "9564",
        "target" : "9506",
        "shared_name" : "C18H19O10 (interacts with) C17H19O8",
        "family_id" : 52,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O10 (interacts with) C17H19O8",
        "interaction" : "interacts with",
        "SUID" : 9640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9565",
        "source" : "9564",
        "target" : "9506",
        "shared_name" : "C18H19O10 (interacts with) C17H19O8",
        "family_id" : 76,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H19O10 (interacts with) C17H19O8",
        "interaction" : "interacts with",
        "SUID" : 9565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9742",
        "source" : "9560",
        "target" : "9741",
        "shared_name" : "C18H23O9 (interacts with) C18H21O8",
        "family_id" : 154,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O9 (interacts with) C18H21O8",
        "interaction" : "interacts with",
        "SUID" : 9742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9562",
        "source" : "9560",
        "target" : "9561",
        "shared_name" : "C18H23O9 (interacts with) C17H23O7",
        "family_id" : 67,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O9 (interacts with) C17H23O7",
        "interaction" : "interacts with",
        "SUID" : 9562,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9557",
        "source" : "9555",
        "target" : "9556",
        "shared_name" : "C21H15O10 (interacts with) C20H15O8",
        "family_id" : 198,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H15O10 (interacts with) C20H15O8",
        "interaction" : "interacts with",
        "SUID" : 9557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10007",
        "source" : "9553",
        "target" : "10006",
        "shared_name" : "C20H21O10 (interacts with) C19H21O8",
        "family_id" : 132,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O10 (interacts with) C19H21O8",
        "interaction" : "interacts with",
        "SUID" : 10007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9900",
        "source" : "9553",
        "target" : "9531",
        "shared_name" : "C20H21O10 (interacts with) C20H19O9",
        "family_id" : 109,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H21O10 (interacts with) C20H19O9",
        "interaction" : "interacts with",
        "SUID" : 9900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9853",
        "source" : "9553",
        "target" : "9531",
        "shared_name" : "C20H21O10 (interacts with) C20H19O9",
        "family_id" : 209,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H21O10 (interacts with) C20H19O9",
        "interaction" : "interacts with",
        "SUID" : 9853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9646",
        "source" : "9553",
        "target" : "9531",
        "shared_name" : "C20H21O10 (interacts with) C20H19O9",
        "family_id" : 54,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H21O10 (interacts with) C20H19O9",
        "interaction" : "interacts with",
        "SUID" : 9646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9793",
        "source" : "9552",
        "target" : "9629",
        "shared_name" : "C20H23O11 (interacts with) C19H23O9",
        "family_id" : 115,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O11 (interacts with) C19H23O9",
        "interaction" : "interacts with",
        "SUID" : 9793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9554",
        "source" : "9552",
        "target" : "9553",
        "shared_name" : "C20H23O11 (interacts with) C20H21O10",
        "family_id" : 56,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O11 (interacts with) C20H21O10",
        "interaction" : "interacts with",
        "SUID" : 9554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9551",
        "source" : "9549",
        "target" : "9550",
        "shared_name" : "C20H17O10 (interacts with) C19H17O8",
        "family_id" : 208,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H17O10 (interacts with) C19H17O8",
        "interaction" : "interacts with",
        "SUID" : 9551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9548",
        "source" : "9546",
        "target" : "9547",
        "shared_name" : "C20H19O11 (interacts with) C19H19O9",
        "family_id" : 162,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H19O11 (interacts with) C19H19O9",
        "interaction" : "interacts with",
        "SUID" : 9548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9545",
        "source" : "9543",
        "target" : "9544",
        "shared_name" : "C23H25O10 (interacts with) C22H25O8",
        "family_id" : 191,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C23H25O10 (interacts with) C22H25O8",
        "interaction" : "interacts with",
        "SUID" : 9545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9878",
        "source" : "9541",
        "target" : "9578",
        "shared_name" : "C18H21O7 (interacts with) C18H19O6",
        "family_id" : 150,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O7 (interacts with) C18H19O6",
        "interaction" : "interacts with",
        "SUID" : 9878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9584",
        "source" : "9541",
        "target" : "9578",
        "shared_name" : "C18H21O7 (interacts with) C18H19O6",
        "family_id" : 159,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O7 (interacts with) C18H19O6",
        "interaction" : "interacts with",
        "SUID" : 9584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10025",
        "source" : "9539",
        "target" : "9578",
        "shared_name" : "C19H19O8 (interacts with) C18H19O6",
        "family_id" : 65,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O8 (interacts with) C18H19O6",
        "interaction" : "interacts with",
        "SUID" : 10025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9579",
        "source" : "9539",
        "target" : "9578",
        "shared_name" : "C19H19O8 (interacts with) C18H19O6",
        "family_id" : 4,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H19O8 (interacts with) C18H19O6",
        "interaction" : "interacts with",
        "SUID" : 9579,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10008",
        "source" : "9538",
        "target" : "9539",
        "shared_name" : "C19H21O9 (interacts with) C19H19O8",
        "family_id" : 65,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O9 (interacts with) C19H19O8",
        "interaction" : "interacts with",
        "SUID" : 10008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9841",
        "source" : "9538",
        "target" : "9541",
        "shared_name" : "C19H21O9 (interacts with) C18H21O7",
        "family_id" : 159,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O9 (interacts with) C18H21O7",
        "interaction" : "interacts with",
        "SUID" : 9841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9542",
        "source" : "9538",
        "target" : "9541",
        "shared_name" : "C19H21O9 (interacts with) C18H21O7",
        "family_id" : 150,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O9 (interacts with) C18H21O7",
        "interaction" : "interacts with",
        "SUID" : 9542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9540",
        "source" : "9538",
        "target" : "9539",
        "shared_name" : "C19H21O9 (interacts with) C19H19O8",
        "family_id" : 4,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O9 (interacts with) C19H19O8",
        "interaction" : "interacts with",
        "SUID" : 9540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10048",
        "source" : "9536",
        "target" : "9538",
        "shared_name" : "C19H23O10 (interacts with) C19H21O9",
        "family_id" : 90,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O10 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 10048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9943",
        "source" : "9536",
        "target" : "9538",
        "shared_name" : "C19H23O10 (interacts with) C19H21O9",
        "family_id" : 73,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O10 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 9943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9880",
        "source" : "9536",
        "target" : "9538",
        "shared_name" : "C19H23O10 (interacts with) C19H21O9",
        "family_id" : 4,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O10 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 9880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9815",
        "source" : "9536",
        "target" : "9760",
        "shared_name" : "C19H23O10 (interacts with) C18H23O8",
        "family_id" : 189,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O10 (interacts with) C18H23O8",
        "interaction" : "interacts with",
        "SUID" : 9815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9769",
        "source" : "9536",
        "target" : "9760",
        "shared_name" : "C19H23O10 (interacts with) C18H23O8",
        "family_id" : 86,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H23O10 (interacts with) C18H23O8",
        "interaction" : "interacts with",
        "SUID" : 9769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9669",
        "source" : "9536",
        "target" : "9538",
        "shared_name" : "C19H23O10 (interacts with) C19H21O9",
        "family_id" : 159,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O10 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 9669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9641",
        "source" : "9536",
        "target" : "9538",
        "shared_name" : "C19H23O10 (interacts with) C19H21O9",
        "family_id" : 215,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O10 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 9641,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10067",
        "source" : "9534",
        "target" : "9526",
        "shared_name" : "C20H23O10 (interacts with) C20H21O9",
        "family_id" : 183,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O10 (interacts with) C20H21O9",
        "interaction" : "interacts with",
        "SUID" : 10067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10064",
        "source" : "9534",
        "target" : "9526",
        "shared_name" : "C20H23O10 (interacts with) C20H21O9",
        "family_id" : 114,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O10 (interacts with) C20H21O9",
        "interaction" : "interacts with",
        "SUID" : 10064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9999",
        "source" : "9534",
        "target" : "9726",
        "shared_name" : "C20H23O10 (interacts with) C19H23O8",
        "family_id" : 113,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O10 (interacts with) C19H23O8",
        "interaction" : "interacts with",
        "SUID" : 9999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9845",
        "source" : "9534",
        "target" : "9726",
        "shared_name" : "C20H23O10 (interacts with) C19H23O8",
        "family_id" : 148,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O10 (interacts with) C19H23O8",
        "interaction" : "interacts with",
        "SUID" : 9845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9829",
        "source" : "9534",
        "target" : "9726",
        "shared_name" : "C20H23O10 (interacts with) C19H23O8",
        "family_id" : 214,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O10 (interacts with) C19H23O8",
        "interaction" : "interacts with",
        "SUID" : 9829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9772",
        "source" : "9534",
        "target" : "9726",
        "shared_name" : "C20H23O10 (interacts with) C19H23O8",
        "family_id" : 135,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O10 (interacts with) C19H23O8",
        "interaction" : "interacts with",
        "SUID" : 9772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9596",
        "source" : "9534",
        "target" : "9526",
        "shared_name" : "C20H23O10 (interacts with) C20H21O9",
        "family_id" : 121,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O10 (interacts with) C20H21O9",
        "interaction" : "interacts with",
        "SUID" : 9596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9535",
        "source" : "9534",
        "target" : "9526",
        "shared_name" : "C20H23O10 (interacts with) C20H21O9",
        "family_id" : 217,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O10 (interacts with) C20H21O9",
        "interaction" : "interacts with",
        "SUID" : 9535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10056",
        "source" : "9531",
        "target" : "9894",
        "shared_name" : "C20H19O9 (interacts with) C19H19O7",
        "family_id" : 109,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H19O9 (interacts with) C19H19O7",
        "interaction" : "interacts with",
        "SUID" : 10056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9895",
        "source" : "9531",
        "target" : "9894",
        "shared_name" : "C20H19O9 (interacts with) C19H19O7",
        "family_id" : 178,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H19O9 (interacts with) C19H19O7",
        "interaction" : "interacts with",
        "SUID" : 9895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9990",
        "source" : "9530",
        "target" : "9531",
        "shared_name" : "C21H19O11 (interacts with) C20H19O9",
        "family_id" : 176,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H19O11 (interacts with) C20H19O9",
        "interaction" : "interacts with",
        "SUID" : 9990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9603",
        "source" : "9530",
        "target" : "9531",
        "shared_name" : "C21H19O11 (interacts with) C20H19O9",
        "family_id" : 178,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H19O11 (interacts with) C20H19O9",
        "interaction" : "interacts with",
        "SUID" : 9603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9532",
        "source" : "9530",
        "target" : "9531",
        "shared_name" : "C21H19O11 (interacts with) C20H19O9",
        "family_id" : 11,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H19O11 (interacts with) C20H19O9",
        "interaction" : "interacts with",
        "SUID" : 9532,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10019",
        "source" : "9528",
        "target" : "10018",
        "shared_name" : "C15H21O8 (interacts with) C14H21O6",
        "family_id" : 175,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H21O8 (interacts with) C14H21O6",
        "interaction" : "interacts with",
        "SUID" : 10019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9897",
        "source" : "9528",
        "target" : "9500",
        "shared_name" : "C15H21O8 (interacts with) C15H19O7",
        "family_id" : 142,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O8 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 9897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9856",
        "source" : "9528",
        "target" : "9500",
        "shared_name" : "C15H21O8 (interacts with) C15H19O7",
        "family_id" : 25,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O8 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 9856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9529",
        "source" : "9528",
        "target" : "9500",
        "shared_name" : "C15H21O8 (interacts with) C15H19O7",
        "family_id" : 80,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H21O8 (interacts with) C15H19O7",
        "interaction" : "interacts with",
        "SUID" : 9529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10057",
        "source" : "9526",
        "target" : "9923",
        "shared_name" : "C20H21O9 (interacts with) C19H21O7",
        "family_id" : 210,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O9 (interacts with) C19H21O7",
        "interaction" : "interacts with",
        "SUID" : 10057,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10026",
        "source" : "9526",
        "target" : "9923",
        "shared_name" : "C20H21O9 (interacts with) C19H21O7",
        "family_id" : 114,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O9 (interacts with) C19H21O7",
        "interaction" : "interacts with",
        "SUID" : 10026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9985",
        "source" : "9526",
        "target" : "9923",
        "shared_name" : "C20H21O9 (interacts with) C19H21O7",
        "family_id" : 217,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O9 (interacts with) C19H21O7",
        "interaction" : "interacts with",
        "SUID" : 9985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9862",
        "source" : "9526",
        "target" : "9805",
        "shared_name" : "C20H21O9 (interacts with) C20H19O8",
        "family_id" : 160,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H21O9 (interacts with) C20H19O8",
        "interaction" : "interacts with",
        "SUID" : 9862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9806",
        "source" : "9526",
        "target" : "9805",
        "shared_name" : "C20H21O9 (interacts with) C20H19O8",
        "family_id" : 155,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H21O9 (interacts with) C20H19O8",
        "interaction" : "interacts with",
        "SUID" : 9806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10065",
        "source" : "9524",
        "target" : "9607",
        "shared_name" : "C18H21O10 (interacts with) C17H21O8",
        "family_id" : 203,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O10 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 10065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10040",
        "source" : "9524",
        "target" : "9566",
        "shared_name" : "C18H21O10 (interacts with) C18H19O9",
        "family_id" : 197,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 10040,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10004",
        "source" : "9524",
        "target" : "9607",
        "shared_name" : "C18H21O10 (interacts with) C17H21O8",
        "family_id" : 37,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O10 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 10004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9977",
        "source" : "9524",
        "target" : "9607",
        "shared_name" : "C18H21O10 (interacts with) C17H21O8",
        "family_id" : 21,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O10 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 9977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9865",
        "source" : "9524",
        "target" : "9607",
        "shared_name" : "C18H21O10 (interacts with) C17H21O8",
        "family_id" : 108,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O10 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 9865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9653",
        "source" : "9524",
        "target" : "9566",
        "shared_name" : "C18H21O10 (interacts with) C18H19O9",
        "family_id" : 173,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 9653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9635",
        "source" : "9524",
        "target" : "9607",
        "shared_name" : "C18H21O10 (interacts with) C17H21O8",
        "family_id" : 158,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O10 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 9635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9608",
        "source" : "9524",
        "target" : "9607",
        "shared_name" : "C18H21O10 (interacts with) C17H21O8",
        "family_id" : 63,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H21O10 (interacts with) C17H21O8",
        "interaction" : "interacts with",
        "SUID" : 9608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9574",
        "source" : "9524",
        "target" : "9566",
        "shared_name" : "C18H21O10 (interacts with) C18H19O9",
        "family_id" : 29,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 9574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9567",
        "source" : "9524",
        "target" : "9566",
        "shared_name" : "C18H21O10 (interacts with) C18H19O9",
        "family_id" : 27,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O10 (interacts with) C18H19O9",
        "interaction" : "interacts with",
        "SUID" : 9567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10002",
        "source" : "9523",
        "target" : "9524",
        "shared_name" : "C18H23O11 (interacts with) C18H21O10",
        "family_id" : 108,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O11 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 10002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9939",
        "source" : "9523",
        "target" : "9524",
        "shared_name" : "C18H23O11 (interacts with) C18H21O10",
        "family_id" : 63,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O11 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 9939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9906",
        "source" : "9523",
        "target" : "9692",
        "shared_name" : "C18H23O11 (interacts with) C17H23O9",
        "family_id" : 78,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O11 (interacts with) C17H23O9",
        "interaction" : "interacts with",
        "SUID" : 9906,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9765",
        "source" : "9523",
        "target" : "9524",
        "shared_name" : "C18H23O11 (interacts with) C18H21O10",
        "family_id" : 37,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O11 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 9765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9724",
        "source" : "9523",
        "target" : "9692",
        "shared_name" : "C18H23O11 (interacts with) C17H23O9",
        "family_id" : 60,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C18H23O11 (interacts with) C17H23O9",
        "interaction" : "interacts with",
        "SUID" : 9724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9616",
        "source" : "9523",
        "target" : "9524",
        "shared_name" : "C18H23O11 (interacts with) C18H21O10",
        "family_id" : 173,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O11 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 9616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9609",
        "source" : "9523",
        "target" : "9524",
        "shared_name" : "C18H23O11 (interacts with) C18H21O10",
        "family_id" : 92,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O11 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 9609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9525",
        "source" : "9523",
        "target" : "9524",
        "shared_name" : "C18H23O11 (interacts with) C18H21O10",
        "family_id" : 27,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H23O11 (interacts with) C18H21O10",
        "interaction" : "interacts with",
        "SUID" : 9525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10058",
        "source" : "9521",
        "target" : "9526",
        "shared_name" : "C21H21O11 (interacts with) C20H21O9",
        "family_id" : 69,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O11 (interacts with) C20H21O9",
        "interaction" : "interacts with",
        "SUID" : 10058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10049",
        "source" : "9521",
        "target" : "9526",
        "shared_name" : "C21H21O11 (interacts with) C20H21O9",
        "family_id" : 155,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O11 (interacts with) C20H21O9",
        "interaction" : "interacts with",
        "SUID" : 10049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9771",
        "source" : "9521",
        "target" : "9526",
        "shared_name" : "C21H21O11 (interacts with) C20H21O9",
        "family_id" : 160,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O11 (interacts with) C20H21O9",
        "interaction" : "interacts with",
        "SUID" : 9771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9652",
        "source" : "9521",
        "target" : "9526",
        "shared_name" : "C21H21O11 (interacts with) C20H21O9",
        "family_id" : 161,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O11 (interacts with) C20H21O9",
        "interaction" : "interacts with",
        "SUID" : 9652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9527",
        "source" : "9521",
        "target" : "9526",
        "shared_name" : "C21H21O11 (interacts with) C20H21O9",
        "family_id" : 210,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H21O11 (interacts with) C20H21O9",
        "interaction" : "interacts with",
        "SUID" : 9527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10068",
        "source" : "9520",
        "target" : "9521",
        "shared_name" : "C21H23O12 (interacts with) C21H21O11",
        "family_id" : 101,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H23O12 (interacts with) C21H21O11",
        "interaction" : "interacts with",
        "SUID" : 10068,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9992",
        "source" : "9520",
        "target" : "9521",
        "shared_name" : "C21H23O12 (interacts with) C21H21O11",
        "family_id" : 155,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H23O12 (interacts with) C21H21O11",
        "interaction" : "interacts with",
        "SUID" : 9992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9925",
        "source" : "9520",
        "target" : "9534",
        "shared_name" : "C21H23O12 (interacts with) C20H23O10",
        "family_id" : 148,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O12 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 9925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9884",
        "source" : "9520",
        "target" : "9521",
        "shared_name" : "C21H23O12 (interacts with) C21H21O11",
        "family_id" : 69,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H23O12 (interacts with) C21H21O11",
        "interaction" : "interacts with",
        "SUID" : 9884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9877",
        "source" : "9520",
        "target" : "9534",
        "shared_name" : "C21H23O12 (interacts with) C20H23O10",
        "family_id" : 116,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O12 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 9877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9849",
        "source" : "9520",
        "target" : "9534",
        "shared_name" : "C21H23O12 (interacts with) C20H23O10",
        "family_id" : 217,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O12 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 9849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9827",
        "source" : "9520",
        "target" : "9534",
        "shared_name" : "C21H23O12 (interacts with) C20H23O10",
        "family_id" : 135,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O12 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 9827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9558",
        "source" : "9520",
        "target" : "9534",
        "shared_name" : "C21H23O12 (interacts with) C20H23O10",
        "family_id" : 214,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C21H23O12 (interacts with) C20H23O10",
        "interaction" : "interacts with",
        "SUID" : 9558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9522",
        "source" : "9520",
        "target" : "9521",
        "shared_name" : "C21H23O12 (interacts with) C21H21O11",
        "family_id" : 210,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C21H23O12 (interacts with) C21H21O11",
        "interaction" : "interacts with",
        "SUID" : 9522,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9758",
        "source" : "9518",
        "target" : "9757",
        "shared_name" : "C14H19O7 (interacts with) C14H17O6",
        "family_id" : 207,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C14H19O7 (interacts with) C14H17O6",
        "interaction" : "interacts with",
        "SUID" : 9758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9950",
        "source" : "9517",
        "target" : "9515",
        "shared_name" : "C15H19O9 (interacts with) C15H17O8",
        "family_id" : 74,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O9 (interacts with) C15H17O8",
        "interaction" : "interacts with",
        "SUID" : 9950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9896",
        "source" : "9517",
        "target" : "9515",
        "shared_name" : "C15H19O9 (interacts with) C15H17O8",
        "family_id" : 13,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O9 (interacts with) C15H17O8",
        "interaction" : "interacts with",
        "SUID" : 9896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9875",
        "source" : "9517",
        "target" : "9518",
        "shared_name" : "C15H19O9 (interacts with) C14H19O7",
        "family_id" : 207,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H19O9 (interacts with) C14H19O7",
        "interaction" : "interacts with",
        "SUID" : 9875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9519",
        "source" : "9517",
        "target" : "9518",
        "shared_name" : "C15H19O9 (interacts with) C14H19O7",
        "family_id" : 38,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H19O9 (interacts with) C14H19O7",
        "interaction" : "interacts with",
        "SUID" : 9519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9948",
        "source" : "9515",
        "target" : "9947",
        "shared_name" : "C15H17O8 (interacts with) C15H15O7",
        "family_id" : 51,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H17O8 (interacts with) C15H15O7",
        "interaction" : "interacts with",
        "SUID" : 9948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9776",
        "source" : "9515",
        "target" : "9757",
        "shared_name" : "C15H17O8 (interacts with) C14H17O6",
        "family_id" : 13,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H17O8 (interacts with) C14H17O6",
        "interaction" : "interacts with",
        "SUID" : 9776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9516",
        "source" : "9514",
        "target" : "9515",
        "shared_name" : "C16H17O10 (interacts with) C15H17O8",
        "family_id" : 82,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O10 (interacts with) C15H17O8",
        "interaction" : "interacts with",
        "SUID" : 9516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9866",
        "source" : "9512",
        "target" : "9538",
        "shared_name" : "C20H21O11 (interacts with) C19H21O9",
        "family_id" : 150,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O11 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 9866,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9766",
        "source" : "9512",
        "target" : "9538",
        "shared_name" : "C20H21O11 (interacts with) C19H21O9",
        "family_id" : 65,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O11 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 9766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9750",
        "source" : "9512",
        "target" : "9538",
        "shared_name" : "C20H21O11 (interacts with) C19H21O9",
        "family_id" : 99,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H21O11 (interacts with) C19H21O9",
        "interaction" : "interacts with",
        "SUID" : 9750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9933",
        "source" : "9511",
        "target" : "9512",
        "shared_name" : "C20H23O12 (interacts with) C20H21O11",
        "family_id" : 99,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O12 (interacts with) C20H21O11",
        "interaction" : "interacts with",
        "SUID" : 9933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9801",
        "source" : "9511",
        "target" : "9536",
        "shared_name" : "C20H23O12 (interacts with) C19H23O10",
        "family_id" : 4,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O12 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 9801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9775",
        "source" : "9511",
        "target" : "9536",
        "shared_name" : "C20H23O12 (interacts with) C19H23O10",
        "family_id" : 90,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O12 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 9775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9764",
        "source" : "9511",
        "target" : "9536",
        "shared_name" : "C20H23O12 (interacts with) C19H23O10",
        "family_id" : 131,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O12 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 9764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9664",
        "source" : "9511",
        "target" : "9512",
        "shared_name" : "C20H23O12 (interacts with) C20H21O11",
        "family_id" : 150,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O12 (interacts with) C20H21O11",
        "interaction" : "interacts with",
        "SUID" : 9664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9563",
        "source" : "9511",
        "target" : "9512",
        "shared_name" : "C20H23O12 (interacts with) C20H21O11",
        "family_id" : 143,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O12 (interacts with) C20H21O11",
        "interaction" : "interacts with",
        "SUID" : 9563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9559",
        "source" : "9511",
        "target" : "9536",
        "shared_name" : "C20H23O12 (interacts with) C19H23O10",
        "family_id" : 189,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O12 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 9559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9537",
        "source" : "9511",
        "target" : "9536",
        "shared_name" : "C20H23O12 (interacts with) C19H23O10",
        "family_id" : 159,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H23O12 (interacts with) C19H23O10",
        "interaction" : "interacts with",
        "SUID" : 9537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9513",
        "source" : "9511",
        "target" : "9512",
        "shared_name" : "C20H23O12 (interacts with) C20H21O11",
        "family_id" : 65,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H23O12 (interacts with) C20H21O11",
        "interaction" : "interacts with",
        "SUID" : 9513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9916",
        "source" : "9509",
        "target" : "9503",
        "shared_name" : "C19H23O12 (interacts with) C19H21O11",
        "family_id" : 97,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O12 (interacts with) C19H21O11",
        "interaction" : "interacts with",
        "SUID" : 9916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9830",
        "source" : "9509",
        "target" : "9503",
        "shared_name" : "C19H23O12 (interacts with) C19H21O11",
        "family_id" : 20,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O12 (interacts with) C19H21O11",
        "interaction" : "interacts with",
        "SUID" : 9830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9708",
        "source" : "9509",
        "target" : "9503",
        "shared_name" : "C19H23O12 (interacts with) C19H21O11",
        "family_id" : 140,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O12 (interacts with) C19H21O11",
        "interaction" : "interacts with",
        "SUID" : 9708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9634",
        "source" : "9509",
        "target" : "9503",
        "shared_name" : "C19H23O12 (interacts with) C19H21O11",
        "family_id" : 28,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O12 (interacts with) C19H21O11",
        "interaction" : "interacts with",
        "SUID" : 9634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9533",
        "source" : "9509",
        "target" : "9503",
        "shared_name" : "C19H23O12 (interacts with) C19H21O11",
        "family_id" : 53,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O12 (interacts with) C19H21O11",
        "interaction" : "interacts with",
        "SUID" : 9533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9510",
        "source" : "9509",
        "target" : "9503",
        "shared_name" : "C19H23O12 (interacts with) C19H21O11",
        "family_id" : 19,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H23O12 (interacts with) C19H21O11",
        "interaction" : "interacts with",
        "SUID" : 9510,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9955",
        "source" : "9506",
        "target" : "9507",
        "shared_name" : "C17H19O8 (interacts with) C16H19O6",
        "family_id" : 0,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O8 (interacts with) C16H19O6",
        "interaction" : "interacts with",
        "SUID" : 9955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9867",
        "source" : "9506",
        "target" : "9507",
        "shared_name" : "C17H19O8 (interacts with) C16H19O6",
        "family_id" : 192,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O8 (interacts with) C16H19O6",
        "interaction" : "interacts with",
        "SUID" : 9867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9508",
        "source" : "9506",
        "target" : "9507",
        "shared_name" : "C17H19O8 (interacts with) C16H19O6",
        "family_id" : 166,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C17H19O8 (interacts with) C16H19O6",
        "interaction" : "interacts with",
        "SUID" : 9508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9700",
        "source" : "9504",
        "target" : "9699",
        "shared_name" : "C18H21O9 (interacts with) C18H19O8",
        "family_id" : 20,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C18H21O9 (interacts with) C18H19O8",
        "interaction" : "interacts with",
        "SUID" : 9700,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10044",
        "source" : "9503",
        "target" : "9662",
        "shared_name" : "C19H21O11 (interacts with) C19H19O10",
        "family_id" : 53,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O11 (interacts with) C19H19O10",
        "interaction" : "interacts with",
        "SUID" : 10044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9995",
        "source" : "9503",
        "target" : "9504",
        "shared_name" : "C19H21O11 (interacts with) C18H21O9",
        "family_id" : 20,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O11 (interacts with) C18H21O9",
        "interaction" : "interacts with",
        "SUID" : 9995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9976",
        "source" : "9503",
        "target" : "9662",
        "shared_name" : "C19H21O11 (interacts with) C19H19O10",
        "family_id" : 28,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O11 (interacts with) C19H19O10",
        "interaction" : "interacts with",
        "SUID" : 9976,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9876",
        "source" : "9503",
        "target" : "9662",
        "shared_name" : "C19H21O11 (interacts with) C19H19O10",
        "family_id" : 19,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H21O11 (interacts with) C19H19O10",
        "interaction" : "interacts with",
        "SUID" : 9876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9873",
        "source" : "9503",
        "target" : "9504",
        "shared_name" : "C19H21O11 (interacts with) C18H21O9",
        "family_id" : 49,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O11 (interacts with) C18H21O9",
        "interaction" : "interacts with",
        "SUID" : 9873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9505",
        "source" : "9503",
        "target" : "9504",
        "shared_name" : "C19H21O11 (interacts with) C18H21O9",
        "family_id" : 97,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H21O11 (interacts with) C18H21O9",
        "interaction" : "interacts with",
        "SUID" : 9505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10003",
        "source" : "9500",
        "target" : "9501",
        "shared_name" : "C15H19O7 (interacts with) C14H19O5",
        "family_id" : 80,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H19O7 (interacts with) C14H19O5",
        "interaction" : "interacts with",
        "SUID" : 10003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9759",
        "source" : "9500",
        "target" : "9495",
        "shared_name" : "C15H19O7 (interacts with) C15H17O6",
        "family_id" : 190,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C15H19O7 (interacts with) C15H17O6",
        "interaction" : "interacts with",
        "SUID" : 9759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9502",
        "source" : "9500",
        "target" : "9501",
        "shared_name" : "C15H19O7 (interacts with) C14H19O5",
        "family_id" : 152,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C15H19O7 (interacts with) C14H19O5",
        "interaction" : "interacts with",
        "SUID" : 9502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9942",
        "source" : "9498",
        "target" : "9788",
        "shared_name" : "C19H17O10 (interacts with) C19H15O9",
        "family_id" : 137,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C19H17O10 (interacts with) C19H15O9",
        "interaction" : "interacts with",
        "SUID" : 9942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9818",
        "source" : "9498",
        "target" : "9817",
        "shared_name" : "C19H17O10 (interacts with) C18H17O8",
        "family_id" : 41,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C19H17O10 (interacts with) C18H17O8",
        "interaction" : "interacts with",
        "SUID" : 9818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10033",
        "source" : "9497",
        "target" : "9498",
        "shared_name" : "C20H17O12 (interacts with) C19H17O10",
        "family_id" : 41,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H17O12 (interacts with) C19H17O10",
        "interaction" : "interacts with",
        "SUID" : 10033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "10001",
        "source" : "9497",
        "target" : "9498",
        "shared_name" : "C20H17O12 (interacts with) C19H17O10",
        "family_id" : 137,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H17O12 (interacts with) C19H17O10",
        "interaction" : "interacts with",
        "SUID" : 10001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9989",
        "source" : "9497",
        "target" : "9623",
        "shared_name" : "C20H17O12 (interacts with) C20H15O11",
        "family_id" : 144,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H17O12 (interacts with) C20H15O11",
        "interaction" : "interacts with",
        "SUID" : 9989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9740",
        "source" : "9497",
        "target" : "9623",
        "shared_name" : "C20H17O12 (interacts with) C20H15O11",
        "family_id" : 127,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "H2O1",
        "name" : "C20H17O12 (interacts with) C20H15O11",
        "interaction" : "interacts with",
        "SUID" : 9740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9499",
        "source" : "9497",
        "target" : "9498",
        "shared_name" : "C20H17O12 (interacts with) C19H17O10",
        "family_id" : 146,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C20H17O12 (interacts with) C19H17O10",
        "interaction" : "interacts with",
        "SUID" : 9499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9639",
        "source" : "9494",
        "target" : "9495",
        "shared_name" : "C16H17O8 (interacts with) C15H17O6",
        "family_id" : 55,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O8 (interacts with) C15H17O6",
        "interaction" : "interacts with",
        "SUID" : 9639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9496",
        "source" : "9494",
        "target" : "9495",
        "shared_name" : "C16H17O8 (interacts with) C15H17O6",
        "family_id" : 58,
        "shared_interaction" : "interacts with",
        "neutral_loss" : "C1O2",
        "name" : "C16H17O8 (interacts with) C15H17O6",
        "interaction" : "interacts with",
        "SUID" : 9496,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}